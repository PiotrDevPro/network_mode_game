﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"



extern const RuntimeMethod* EncryptorNative_OnNativeLog_m093EEF0A12F4E92917B10950998C3B705BF1CD8C_RuntimeMethod_var;
extern const RuntimeMethod* SocketNative_DebugReturn_m3D36438056F5FD4B647AD3D732F52B028557B6C6_RuntimeMethod_var;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void ExitGames.Client.Photon.ByteArraySlice::.ctor(ExitGames.Client.Photon.ByteArraySlicePool,System.Int32)
extern void ByteArraySlice__ctor_m95E921AE77478309149A41A2B34EB4099DB6B693 (void);
// 0x00000002 System.Void ExitGames.Client.Photon.ByteArraySlice::.ctor(System.Byte[],System.Int32,System.Int32)
extern void ByteArraySlice__ctor_mCA1F121BC54CAD54356FF8E244FF982E7C9F4A0C (void);
// 0x00000003 System.Void ExitGames.Client.Photon.ByteArraySlice::.ctor()
extern void ByteArraySlice__ctor_m52E75007027C0D2206B592129520A6B8BF910971 (void);
// 0x00000004 System.Void ExitGames.Client.Photon.ByteArraySlice::Dispose()
extern void ByteArraySlice_Dispose_mD49ED18A23C465947805671BCC35397FAFF296B4 (void);
// 0x00000005 System.Boolean ExitGames.Client.Photon.ByteArraySlice::Release()
extern void ByteArraySlice_Release_m36763938B2E6D82E835210D8539D155E0DCB0358 (void);
// 0x00000006 System.Void ExitGames.Client.Photon.ByteArraySlice::Reset()
extern void ByteArraySlice_Reset_mDD7E41A520B6990FE03D61F4B1270BCAA0DFCBAC (void);
// 0x00000007 System.Int32 ExitGames.Client.Photon.ByteArraySlicePool::get_MinStackIndex()
extern void ByteArraySlicePool_get_MinStackIndex_m51B942226EA8AA807D181B9A46A4DD04CF17C479 (void);
// 0x00000008 System.Void ExitGames.Client.Photon.ByteArraySlicePool::set_MinStackIndex(System.Int32)
extern void ByteArraySlicePool_set_MinStackIndex_mB6847C0452EAA5DCE25D8F45AFD7C818A7DBEBD8 (void);
// 0x00000009 System.Int32 ExitGames.Client.Photon.ByteArraySlicePool::get_AllocationCounter()
extern void ByteArraySlicePool_get_AllocationCounter_mA563AF605FEE8D0FC4A149E33EC231017658B253 (void);
// 0x0000000A System.Void ExitGames.Client.Photon.ByteArraySlicePool::.ctor()
extern void ByteArraySlicePool__ctor_m45CA6BE6C2A8713064CDD3EC5EA5B5E84C7B1EF7 (void);
// 0x0000000B ExitGames.Client.Photon.ByteArraySlice ExitGames.Client.Photon.ByteArraySlicePool::Acquire(System.Byte[],System.Int32,System.Int32)
extern void ByteArraySlicePool_Acquire_m7D5BA7113E8BCAB2B00997EB700361DDB974455F (void);
// 0x0000000C ExitGames.Client.Photon.ByteArraySlice ExitGames.Client.Photon.ByteArraySlicePool::Acquire(System.Int32)
extern void ByteArraySlicePool_Acquire_m6C2FF6BD59562952E4172A910B70C0F61DB6ADA9 (void);
// 0x0000000D ExitGames.Client.Photon.ByteArraySlice ExitGames.Client.Photon.ByteArraySlicePool::Acquire(System.Collections.Generic.Stack`1<ExitGames.Client.Photon.ByteArraySlice>,System.Int32)
extern void ByteArraySlicePool_Acquire_mD0F964F307C39FEFD8EBDF8A7CC2B53295C1EAF4 (void);
// 0x0000000E System.Boolean ExitGames.Client.Photon.ByteArraySlicePool::Release(ExitGames.Client.Photon.ByteArraySlice)
extern void ByteArraySlicePool_Release_mA25ACFF5C6C708879983C733D73462279D03030D (void);
// 0x0000000F System.Void ExitGames.Client.Photon.ByteArraySlicePool::ClearPools(System.Int32,System.Int32)
extern void ByteArraySlicePool_ClearPools_m9BE9DDC19085D7CB3DB9034EDBDA364A9D66D341 (void);
// 0x00000010 ExitGames.Client.Photon.NonAllocDictionary`2_KeyIterator<K,V> ExitGames.Client.Photon.NonAllocDictionary`2::get_Keys()
// 0x00000011 System.Collections.Generic.ICollection`1<V> ExitGames.Client.Photon.NonAllocDictionary`2::System.Collections.Generic.IDictionary<K,V>.get_Values()
// 0x00000012 System.Collections.Generic.ICollection`1<K> ExitGames.Client.Photon.NonAllocDictionary`2::System.Collections.Generic.IDictionary<K,V>.get_Keys()
// 0x00000013 ExitGames.Client.Photon.NonAllocDictionary`2_ValueIterator<K,V> ExitGames.Client.Photon.NonAllocDictionary`2::get_Values()
// 0x00000014 System.Int32 ExitGames.Client.Photon.NonAllocDictionary`2::get_Count()
// 0x00000015 System.Boolean ExitGames.Client.Photon.NonAllocDictionary`2::get_IsReadOnly()
// 0x00000016 System.UInt32 ExitGames.Client.Photon.NonAllocDictionary`2::get_Capacity()
// 0x00000017 System.Void ExitGames.Client.Photon.NonAllocDictionary`2::.ctor(System.UInt32)
// 0x00000018 System.Boolean ExitGames.Client.Photon.NonAllocDictionary`2::ContainsKey(K)
// 0x00000019 System.Boolean ExitGames.Client.Photon.NonAllocDictionary`2::Contains(System.Collections.Generic.KeyValuePair`2<K,V>)
// 0x0000001A System.Boolean ExitGames.Client.Photon.NonAllocDictionary`2::TryGetValue(K,V&)
// 0x0000001B V ExitGames.Client.Photon.NonAllocDictionary`2::get_Item(K)
// 0x0000001C System.Void ExitGames.Client.Photon.NonAllocDictionary`2::set_Item(K,V)
// 0x0000001D System.Void ExitGames.Client.Photon.NonAllocDictionary`2::Set(K,V)
// 0x0000001E System.Void ExitGames.Client.Photon.NonAllocDictionary`2::Add(K,V)
// 0x0000001F System.Void ExitGames.Client.Photon.NonAllocDictionary`2::Add(System.Collections.Generic.KeyValuePair`2<K,V>)
// 0x00000020 System.Boolean ExitGames.Client.Photon.NonAllocDictionary`2::Remove(K)
// 0x00000021 System.Boolean ExitGames.Client.Photon.NonAllocDictionary`2::Remove(System.Collections.Generic.KeyValuePair`2<K,V>)
// 0x00000022 System.Collections.Generic.IEnumerator`1<System.Collections.Generic.KeyValuePair`2<K,V>> ExitGames.Client.Photon.NonAllocDictionary`2::System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<K,V>>.GetEnumerator()
// 0x00000023 ExitGames.Client.Photon.NonAllocDictionary`2_PairIterator<K,V> ExitGames.Client.Photon.NonAllocDictionary`2::GetEnumerator()
// 0x00000024 System.Collections.IEnumerator ExitGames.Client.Photon.NonAllocDictionary`2::System.Collections.IEnumerable.GetEnumerator()
// 0x00000025 System.Int32 ExitGames.Client.Photon.NonAllocDictionary`2::FindNode(K)
// 0x00000026 System.Void ExitGames.Client.Photon.NonAllocDictionary`2::Insert(K,V)
// 0x00000027 System.Void ExitGames.Client.Photon.NonAllocDictionary`2::Expand()
// 0x00000028 System.Void ExitGames.Client.Photon.NonAllocDictionary`2::Clear()
// 0x00000029 System.Void ExitGames.Client.Photon.NonAllocDictionary`2::System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<K,V>>.CopyTo(System.Collections.Generic.KeyValuePair`2<K,V>[],System.Int32)
// 0x0000002A System.Boolean ExitGames.Client.Photon.NonAllocDictionary`2::IsPrimeFromList(System.UInt32)
// 0x0000002B System.UInt32 ExitGames.Client.Photon.NonAllocDictionary`2::GetNextPrime(System.UInt32)
// 0x0000002C System.Void ExitGames.Client.Photon.NonAllocDictionary`2::Assert(System.Boolean)
// 0x0000002D System.Void ExitGames.Client.Photon.NonAllocDictionary`2::.cctor()
// 0x0000002E System.Void ExitGames.Client.Photon.NonAllocDictionary`2_KeyIterator::.ctor(ExitGames.Client.Photon.NonAllocDictionary`2<K,V>)
// 0x0000002F ExitGames.Client.Photon.NonAllocDictionary`2_KeyIterator<K,V> ExitGames.Client.Photon.NonAllocDictionary`2_KeyIterator::GetEnumerator()
// 0x00000030 System.Void ExitGames.Client.Photon.NonAllocDictionary`2_KeyIterator::Reset()
// 0x00000031 System.Object ExitGames.Client.Photon.NonAllocDictionary`2_KeyIterator::System.Collections.IEnumerator.get_Current()
// 0x00000032 K ExitGames.Client.Photon.NonAllocDictionary`2_KeyIterator::get_Current()
// 0x00000033 System.Boolean ExitGames.Client.Photon.NonAllocDictionary`2_KeyIterator::MoveNext()
// 0x00000034 System.Void ExitGames.Client.Photon.NonAllocDictionary`2_KeyIterator::Dispose()
// 0x00000035 System.Void ExitGames.Client.Photon.NonAllocDictionary`2_ValueIterator::.ctor(ExitGames.Client.Photon.NonAllocDictionary`2<K,V>)
// 0x00000036 ExitGames.Client.Photon.NonAllocDictionary`2_ValueIterator<K,V> ExitGames.Client.Photon.NonAllocDictionary`2_ValueIterator::GetEnumerator()
// 0x00000037 System.Void ExitGames.Client.Photon.NonAllocDictionary`2_ValueIterator::Reset()
// 0x00000038 V ExitGames.Client.Photon.NonAllocDictionary`2_ValueIterator::get_Current()
// 0x00000039 System.Object ExitGames.Client.Photon.NonAllocDictionary`2_ValueIterator::System.Collections.IEnumerator.get_Current()
// 0x0000003A System.Boolean ExitGames.Client.Photon.NonAllocDictionary`2_ValueIterator::MoveNext()
// 0x0000003B System.Void ExitGames.Client.Photon.NonAllocDictionary`2_ValueIterator::Dispose()
// 0x0000003C System.Void ExitGames.Client.Photon.NonAllocDictionary`2_PairIterator::.ctor(ExitGames.Client.Photon.NonAllocDictionary`2<K,V>)
// 0x0000003D System.Void ExitGames.Client.Photon.NonAllocDictionary`2_PairIterator::Reset()
// 0x0000003E System.Object ExitGames.Client.Photon.NonAllocDictionary`2_PairIterator::System.Collections.IEnumerator.get_Current()
// 0x0000003F System.Collections.Generic.KeyValuePair`2<K,V> ExitGames.Client.Photon.NonAllocDictionary`2_PairIterator::get_Current()
// 0x00000040 System.Boolean ExitGames.Client.Photon.NonAllocDictionary`2_PairIterator::MoveNext()
// 0x00000041 System.Void ExitGames.Client.Photon.NonAllocDictionary`2_PairIterator::Dispose()
// 0x00000042 System.Object ExitGames.Client.Photon.Hashtable::GetBoxedByte(System.Byte)
extern void Hashtable_GetBoxedByte_mF882A93166D1A48E0C1F7A7DF0310A096CFEEDED (void);
// 0x00000043 System.Void ExitGames.Client.Photon.Hashtable::.cctor()
extern void Hashtable__cctor_mCAA756BDCDCFBC823F7E43611D66DE7085196F25 (void);
// 0x00000044 System.Void ExitGames.Client.Photon.Hashtable::.ctor()
extern void Hashtable__ctor_mB089FC557FD6D697B39AFB4FF9D70E85DE37B088 (void);
// 0x00000045 System.Void ExitGames.Client.Photon.Hashtable::.ctor(System.Int32)
extern void Hashtable__ctor_mC0B2B8F1A232989295993C9B6C3DBB8F6482040F (void);
// 0x00000046 System.Object ExitGames.Client.Photon.Hashtable::get_Item(System.Object)
extern void Hashtable_get_Item_mC48FD527A6399AB799754650D4AAC398CB432EF9 (void);
// 0x00000047 System.Void ExitGames.Client.Photon.Hashtable::set_Item(System.Object,System.Object)
extern void Hashtable_set_Item_mF5FF682E1D19685B7451AABF5266291D2BCE9EC3 (void);
// 0x00000048 System.Object ExitGames.Client.Photon.Hashtable::get_Item(System.Byte)
extern void Hashtable_get_Item_mEBAA564FE8E5B5564818A64F6530F876BEB84658 (void);
// 0x00000049 System.Void ExitGames.Client.Photon.Hashtable::set_Item(System.Byte,System.Object)
extern void Hashtable_set_Item_mDAB28D1FDD5D4639E2CB89E3FDE428068FE40438 (void);
// 0x0000004A System.Void ExitGames.Client.Photon.Hashtable::Add(System.Byte,System.Object)
extern void Hashtable_Add_mF47F17AD082827648493398B7C98E8AE10743FA6 (void);
// 0x0000004B System.Void ExitGames.Client.Photon.Hashtable::Remove(System.Byte)
extern void Hashtable_Remove_mEC679EEEA51959549DDCDD55AAD1ED1BA55733DB (void);
// 0x0000004C System.Boolean ExitGames.Client.Photon.Hashtable::ContainsKey(System.Byte)
extern void Hashtable_ContainsKey_mDCA3BB08E0C2C4EA1477E7EF9FE9DCB187A39107 (void);
// 0x0000004D System.Collections.Generic.IEnumerator`1<System.Collections.DictionaryEntry> ExitGames.Client.Photon.Hashtable::GetEnumerator()
extern void Hashtable_GetEnumerator_m59F3AAA904C72C689B596BCFAC9C89FFC76C57A3 (void);
// 0x0000004E System.String ExitGames.Client.Photon.Hashtable::ToString()
extern void Hashtable_ToString_m9D89125CC08F6AAFD4722EB7E9939BA45D60A809 (void);
// 0x0000004F System.Object ExitGames.Client.Photon.Hashtable::Clone()
extern void Hashtable_Clone_mF4B598D0C782D589AFBBF675128412437219D343 (void);
// 0x00000050 System.Void ExitGames.Client.Photon.DictionaryEntryEnumerator::.ctor(System.Collections.IDictionaryEnumerator)
extern void DictionaryEntryEnumerator__ctor_m03C0784DFEAFC5E7A8D953C35F9CD0BC8B80CF03 (void);
// 0x00000051 System.Boolean ExitGames.Client.Photon.DictionaryEntryEnumerator::MoveNext()
extern void DictionaryEntryEnumerator_MoveNext_mF75DB872E5617670FC63AE8198D6CB99793561DF (void);
// 0x00000052 System.Void ExitGames.Client.Photon.DictionaryEntryEnumerator::Reset()
extern void DictionaryEntryEnumerator_Reset_m95E84677DABB7CEDE1CFC9335A43EED48FDC5E40 (void);
// 0x00000053 System.Object ExitGames.Client.Photon.DictionaryEntryEnumerator::System.Collections.IEnumerator.get_Current()
extern void DictionaryEntryEnumerator_System_Collections_IEnumerator_get_Current_m8D5744C762D8A17E735557DBC7BD6BE53FB2A7D3 (void);
// 0x00000054 System.Collections.DictionaryEntry ExitGames.Client.Photon.DictionaryEntryEnumerator::get_Current()
extern void DictionaryEntryEnumerator_get_Current_mC652CE08C853BAA299C02233F3B7D0B1F303AE66 (void);
// 0x00000055 System.Object ExitGames.Client.Photon.DictionaryEntryEnumerator::get_Key()
extern void DictionaryEntryEnumerator_get_Key_mC61AE0F4BA19098B0DDC0944764F9F2ACD2A250C (void);
// 0x00000056 System.Object ExitGames.Client.Photon.DictionaryEntryEnumerator::get_Value()
extern void DictionaryEntryEnumerator_get_Value_mA252F5A7AB9A3196DCC0FEEB6020643C7AF10961 (void);
// 0x00000057 System.Collections.DictionaryEntry ExitGames.Client.Photon.DictionaryEntryEnumerator::get_Entry()
extern void DictionaryEntryEnumerator_get_Entry_m269EE75BD5400BA8789620442EC43D647D9FBCCB (void);
// 0x00000058 System.Void ExitGames.Client.Photon.DictionaryEntryEnumerator::Dispose()
extern void DictionaryEntryEnumerator_Dispose_m8507E3836FBA32A62D3D509EEE8D41219096659C (void);
// 0x00000059 System.Void ExitGames.Client.Photon.EnetChannel::.ctor(System.Byte,System.Int32)
extern void EnetChannel__ctor_mDECAC92CC7EE30013B090D2DC8D344CA301580AA (void);
// 0x0000005A System.Boolean ExitGames.Client.Photon.EnetChannel::ContainsUnreliableSequenceNumber(System.Int32)
extern void EnetChannel_ContainsUnreliableSequenceNumber_m585106810BCFDFEAB262094F1041046C1E7E1C62 (void);
// 0x0000005B ExitGames.Client.Photon.NCommand ExitGames.Client.Photon.EnetChannel::FetchUnreliableSequenceNumber(System.Int32)
extern void EnetChannel_FetchUnreliableSequenceNumber_m9DF237427C09EF366DE13886614B5973AE9A0616 (void);
// 0x0000005C System.Boolean ExitGames.Client.Photon.EnetChannel::ContainsReliableSequenceNumber(System.Int32)
extern void EnetChannel_ContainsReliableSequenceNumber_mAB7BDEAD2C2A63BB5766F9FF424AA8C3F0D85C55 (void);
// 0x0000005D ExitGames.Client.Photon.NCommand ExitGames.Client.Photon.EnetChannel::FetchReliableSequenceNumber(System.Int32)
extern void EnetChannel_FetchReliableSequenceNumber_mC530521EFB7F63791B66221614E18272EE52B560 (void);
// 0x0000005E System.Boolean ExitGames.Client.Photon.EnetChannel::TryGetFragment(System.Int32,System.Boolean,ExitGames.Client.Photon.NCommand&)
extern void EnetChannel_TryGetFragment_m5DD7970BF21196715AF6F7B06B2F092A80EB718C (void);
// 0x0000005F System.Void ExitGames.Client.Photon.EnetChannel::RemoveFragment(System.Int32,System.Boolean)
extern void EnetChannel_RemoveFragment_m4B4E5F72BA0C07CBE745241B98D11C7B4BE4CB37 (void);
// 0x00000060 System.Void ExitGames.Client.Photon.EnetChannel::clearAll()
extern void EnetChannel_clearAll_mC663C97BD7286F18603A2C4AC6F8A3D71F9F0F0A (void);
// 0x00000061 System.Boolean ExitGames.Client.Photon.EnetChannel::QueueIncomingReliableUnsequenced(ExitGames.Client.Photon.NCommand)
extern void EnetChannel_QueueIncomingReliableUnsequenced_m62C9B1711DE9569EEB6A505D4F1CA6A02CDBACDD (void);
// 0x00000062 System.Int32 ExitGames.Client.Photon.EnetPeer::get_QueuedIncomingCommandsCount()
extern void EnetPeer_get_QueuedIncomingCommandsCount_m7A99149655C89D667086D647115E94B18E3650A6 (void);
// 0x00000063 System.Int32 ExitGames.Client.Photon.EnetPeer::get_QueuedOutgoingCommandsCount()
extern void EnetPeer_get_QueuedOutgoingCommandsCount_mF50AA08247746EA9ADF321B4E5004A14DF2A2518 (void);
// 0x00000064 System.Int32 ExitGames.Client.Photon.EnetPeer::get_SentReliableCommandsCount()
extern void EnetPeer_get_SentReliableCommandsCount_m933DB6A02FB27C3461B364DFC2DCCDE72FC57E4D (void);
// 0x00000065 System.Void ExitGames.Client.Photon.EnetPeer::.ctor()
extern void EnetPeer__ctor_m45A1D980D6A4499CFE49C8C755170C4DBA0F4B07 (void);
// 0x00000066 System.Boolean ExitGames.Client.Photon.EnetPeer::IsTransportEncrypted()
extern void EnetPeer_IsTransportEncrypted_m4A6F5E1FDE745DDDF596EC8076B8832E8D538EEA (void);
// 0x00000067 System.Void ExitGames.Client.Photon.EnetPeer::Reset()
extern void EnetPeer_Reset_m2069B81329E551B4C4C2494C8C0C017AA9378232 (void);
// 0x00000068 System.Void ExitGames.Client.Photon.EnetPeer::ApplyRandomizedSequenceNumbers()
extern void EnetPeer_ApplyRandomizedSequenceNumbers_mF1B2D0AF61EC5C69010C040EC8D534C0AE623095 (void);
// 0x00000069 ExitGames.Client.Photon.EnetChannel ExitGames.Client.Photon.EnetPeer::GetChannel(System.Byte)
extern void EnetPeer_GetChannel_m2E8BAF2BFEAC85BB7C337B070FECFCCB38016301 (void);
// 0x0000006A System.Boolean ExitGames.Client.Photon.EnetPeer::Connect(System.String,System.String,System.String,System.Object)
extern void EnetPeer_Connect_m709286589D9743EDEE81D8CC8F5B7C5A7DA1AC96 (void);
// 0x0000006B System.Void ExitGames.Client.Photon.EnetPeer::OnConnect()
extern void EnetPeer_OnConnect_mC434A403507850CC3195F3CD8AC5AD60B0C5A635 (void);
// 0x0000006C System.Void ExitGames.Client.Photon.EnetPeer::Disconnect()
extern void EnetPeer_Disconnect_mAB877BAC4105B93BD7E351BC258779B3BB7BB019 (void);
// 0x0000006D System.Void ExitGames.Client.Photon.EnetPeer::StopConnection()
extern void EnetPeer_StopConnection_mB29F7A4BE573D0D402C54A53062F2F530C37047D (void);
// 0x0000006E System.Void ExitGames.Client.Photon.EnetPeer::FetchServerTimestamp()
extern void EnetPeer_FetchServerTimestamp_m9B3A7F4A311323043424CFD7D19CC3C17F8D1DF7 (void);
// 0x0000006F System.Boolean ExitGames.Client.Photon.EnetPeer::DispatchIncomingCommands()
extern void EnetPeer_DispatchIncomingCommands_m77D0D5174F51EA8A1F337CD9FC9B1F28EF0B915A (void);
// 0x00000070 System.Int32 ExitGames.Client.Photon.EnetPeer::GetFragmentLength()
extern void EnetPeer_GetFragmentLength_mD3DD2ECE7CC2580CC985F819CEAAB5F01C622490 (void);
// 0x00000071 System.Int32 ExitGames.Client.Photon.EnetPeer::CalculatePacketSize(System.Int32)
extern void EnetPeer_CalculatePacketSize_mE5C5A2E9A2F72E8B164CCDE9AF483555121555F4 (void);
// 0x00000072 System.Int32 ExitGames.Client.Photon.EnetPeer::CalculateInitialOffset()
extern void EnetPeer_CalculateInitialOffset_m973B17063C88C11B231E3A39F045B89E01B3896F (void);
// 0x00000073 System.Boolean ExitGames.Client.Photon.EnetPeer::SendAcksOnly()
extern void EnetPeer_SendAcksOnly_m5037A4496FBEBFA5A23F539DC130684039F0F56F (void);
// 0x00000074 System.Boolean ExitGames.Client.Photon.EnetPeer::SendOutgoingCommands()
extern void EnetPeer_SendOutgoingCommands_m36CA883DEBFDDD2720037A9698333D8E8B73609C (void);
// 0x00000075 System.Boolean ExitGames.Client.Photon.EnetPeer::AreReliableCommandsInTransit()
extern void EnetPeer_AreReliableCommandsInTransit_m1902478CAAA80C6EA400159AFC25903B70B68B3C (void);
// 0x00000076 System.Boolean ExitGames.Client.Photon.EnetPeer::EnqueuePhotonMessage(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.SendOptions)
extern void EnetPeer_EnqueuePhotonMessage_mC6D5C00A8FEE316621C24E9BDEF0671FEF0D2BFE (void);
// 0x00000077 System.Boolean ExitGames.Client.Photon.EnetPeer::CreateAndEnqueueCommand(System.Byte,ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void EnetPeer_CreateAndEnqueueCommand_m7F95FE38B790BC4D88C6CE9CF359EB05ADB1BEBD (void);
// 0x00000078 System.Int32 ExitGames.Client.Photon.EnetPeer::SerializeAckToBuffer()
extern void EnetPeer_SerializeAckToBuffer_mB259D00A28AECF4E4C0F7CCBC15B7EBD08FC8D0A (void);
// 0x00000079 System.Int32 ExitGames.Client.Photon.EnetPeer::SerializeToBuffer(System.Collections.Generic.Queue`1<ExitGames.Client.Photon.NCommand>)
extern void EnetPeer_SerializeToBuffer_m9EFFAD52286BFDC225572E822CFEEC1CA8D86B25 (void);
// 0x0000007A System.Void ExitGames.Client.Photon.EnetPeer::SendData(System.Byte[],System.Int32)
extern void EnetPeer_SendData_mAD63B2BBDCE7C60F4F5C5902DA4A35C91EAB8E5A (void);
// 0x0000007B System.Void ExitGames.Client.Photon.EnetPeer::SendToSocket(System.Byte[],System.Int32)
extern void EnetPeer_SendToSocket_mCE7DF56445E13679699278C7785296584B297402 (void);
// 0x0000007C System.Void ExitGames.Client.Photon.EnetPeer::SendDataEncrypted(System.Byte[],System.Int32)
extern void EnetPeer_SendDataEncrypted_m403492FFA26E5A06C813C80359D7A22213516CD3 (void);
// 0x0000007D System.Void ExitGames.Client.Photon.EnetPeer::QueueSentCommand(ExitGames.Client.Photon.NCommand)
extern void EnetPeer_QueueSentCommand_m3BFB742ECC74B300B062F5085370D8C3D55F59A0 (void);
// 0x0000007E System.Void ExitGames.Client.Photon.EnetPeer::QueueOutgoingReliableCommand(ExitGames.Client.Photon.NCommand)
extern void EnetPeer_QueueOutgoingReliableCommand_m1EE185F0743F905FE912D08199B18CB4810059F5 (void);
// 0x0000007F System.Void ExitGames.Client.Photon.EnetPeer::QueueOutgoingUnreliableCommand(ExitGames.Client.Photon.NCommand)
extern void EnetPeer_QueueOutgoingUnreliableCommand_mAF7004F33D7063698D75E62BF0EF1C2E2DDE5B5F (void);
// 0x00000080 System.Void ExitGames.Client.Photon.EnetPeer::QueueOutgoingAcknowledgement(ExitGames.Client.Photon.NCommand,System.Int32)
extern void EnetPeer_QueueOutgoingAcknowledgement_m5AE05DD3B5708F09F63FB09AFB34555BEEC10DC9 (void);
// 0x00000081 System.Void ExitGames.Client.Photon.EnetPeer::ReceiveIncomingCommands(System.Byte[],System.Int32)
extern void EnetPeer_ReceiveIncomingCommands_m7AD36F532926FBB0BDD5276E76E06A7A56E0761D (void);
// 0x00000082 System.Void ExitGames.Client.Photon.EnetPeer::ExecuteCommand(ExitGames.Client.Photon.NCommand)
extern void EnetPeer_ExecuteCommand_m37713580633028964C2A5323AAF378C1027EE232 (void);
// 0x00000083 System.Boolean ExitGames.Client.Photon.EnetPeer::QueueIncomingCommand(ExitGames.Client.Photon.NCommand)
extern void EnetPeer_QueueIncomingCommand_m75F50B0FB77477EB30A1CCFCACBC3D98EA4463FF (void);
// 0x00000084 ExitGames.Client.Photon.NCommand ExitGames.Client.Photon.EnetPeer::RemoveSentReliableCommand(System.Int32,System.Int32,System.Boolean)
extern void EnetPeer_RemoveSentReliableCommand_mB54F4B84CAAFF96CE8EC830310E26B78052F3901 (void);
// 0x00000085 System.String ExitGames.Client.Photon.EnetPeer::CommandListToString(ExitGames.Client.Photon.NCommand[])
extern void EnetPeer_CommandListToString_m7A1DAD749BAD2BC17AE0C233FC1C814E568601D1 (void);
// 0x00000086 System.Void ExitGames.Client.Photon.EnetPeer::.cctor()
extern void EnetPeer__cctor_m6AFDD29A22CFC5E3454C757CCAEDD99FCD43EE84 (void);
// 0x00000087 System.Void ExitGames.Client.Photon.EnetPeer::<ExecuteCommand>b__66_0()
extern void EnetPeer_U3CExecuteCommandU3Eb__66_0_m448874D2AA4EDA6C3F9C428DF89D441B2B6E0F78 (void);
// 0x00000088 System.Void ExitGames.Client.Photon.IPhotonPeerListener::DebugReturn(ExitGames.Client.Photon.DebugLevel,System.String)
// 0x00000089 System.Void ExitGames.Client.Photon.IPhotonPeerListener::OnOperationResponse(ExitGames.Client.Photon.OperationResponse)
// 0x0000008A System.Void ExitGames.Client.Photon.IPhotonPeerListener::OnStatusChanged(ExitGames.Client.Photon.StatusCode)
// 0x0000008B System.Void ExitGames.Client.Photon.IPhotonPeerListener::OnEvent(ExitGames.Client.Photon.EventData)
// 0x0000008C ExitGames.Client.Photon.IPhotonPeerListener ExitGames.Client.Photon.IPhotonSocket::get_Listener()
extern void IPhotonSocket_get_Listener_m7CFA610DF796ED179ED62179509BFA5DE06ABC74 (void);
// 0x0000008D System.Int32 ExitGames.Client.Photon.IPhotonSocket::get_MTU()
extern void IPhotonSocket_get_MTU_mC44CA042574F0BC945782126B8C27125CBF755D0 (void);
// 0x0000008E ExitGames.Client.Photon.PhotonSocketState ExitGames.Client.Photon.IPhotonSocket::get_State()
extern void IPhotonSocket_get_State_mD9AB135F98DD72499F910819560E3A56669567E6 (void);
// 0x0000008F System.Void ExitGames.Client.Photon.IPhotonSocket::set_State(ExitGames.Client.Photon.PhotonSocketState)
extern void IPhotonSocket_set_State_mEF43882322161D6DF457B8888185A2E825583A99 (void);
// 0x00000090 System.Boolean ExitGames.Client.Photon.IPhotonSocket::get_Connected()
extern void IPhotonSocket_get_Connected_m356CE78036AF9A4618195937E5BEA0A9865A4F9B (void);
// 0x00000091 System.String ExitGames.Client.Photon.IPhotonSocket::get_ServerAddress()
extern void IPhotonSocket_get_ServerAddress_mA5AB6B7A162F657613FCA2783237DE147B041F3B (void);
// 0x00000092 System.Void ExitGames.Client.Photon.IPhotonSocket::set_ServerAddress(System.String)
extern void IPhotonSocket_set_ServerAddress_m7B1006418167CE1C679227AF7128D29259DE20FE (void);
// 0x00000093 System.String ExitGames.Client.Photon.IPhotonSocket::get_ProxyServerAddress()
extern void IPhotonSocket_get_ProxyServerAddress_mB1E62D31E7F91B7B04D8364E239FDF91A3078538 (void);
// 0x00000094 System.Void ExitGames.Client.Photon.IPhotonSocket::set_ProxyServerAddress(System.String)
extern void IPhotonSocket_set_ProxyServerAddress_m1400E408C64B9FDF925577FAF05E4C7869C280E1 (void);
// 0x00000095 System.String ExitGames.Client.Photon.IPhotonSocket::get_ServerIpAddress()
extern void IPhotonSocket_get_ServerIpAddress_m64742FBD4CA0C3105F9C323B2866AAEA281BDD96 (void);
// 0x00000096 System.Void ExitGames.Client.Photon.IPhotonSocket::set_ServerIpAddress(System.String)
extern void IPhotonSocket_set_ServerIpAddress_m0B6C227D9722E0E1D1A4EC7476357FE2B09B47BC (void);
// 0x00000097 System.Int32 ExitGames.Client.Photon.IPhotonSocket::get_ServerPort()
extern void IPhotonSocket_get_ServerPort_mD8B3BC1BB71CB40997C173C220EFCB241BDB8449 (void);
// 0x00000098 System.Void ExitGames.Client.Photon.IPhotonSocket::set_ServerPort(System.Int32)
extern void IPhotonSocket_set_ServerPort_m33DDD60B4056ED444AFE34AB059A125E3A46122E (void);
// 0x00000099 System.Boolean ExitGames.Client.Photon.IPhotonSocket::get_AddressResolvedAsIpv6()
extern void IPhotonSocket_get_AddressResolvedAsIpv6_mC9BDB92DF61BE495906070CE4B03C764F0245DC8 (void);
// 0x0000009A System.Void ExitGames.Client.Photon.IPhotonSocket::set_AddressResolvedAsIpv6(System.Boolean)
extern void IPhotonSocket_set_AddressResolvedAsIpv6_m2960FDE4B84F6907BFD0BCD940F4BB456F7412B3 (void);
// 0x0000009B System.String ExitGames.Client.Photon.IPhotonSocket::get_UrlProtocol()
extern void IPhotonSocket_get_UrlProtocol_m86E8F0FBBF0086C2D09ADF5D4E7DDD98D2004D88 (void);
// 0x0000009C System.Void ExitGames.Client.Photon.IPhotonSocket::set_UrlProtocol(System.String)
extern void IPhotonSocket_set_UrlProtocol_m3A7C82D2489C70707745274B84613913A6C06B9B (void);
// 0x0000009D System.String ExitGames.Client.Photon.IPhotonSocket::get_UrlPath()
extern void IPhotonSocket_get_UrlPath_m06F1C599E5CECECE1F9FE877A3C7DE0ECD7AE9E6 (void);
// 0x0000009E System.Void ExitGames.Client.Photon.IPhotonSocket::set_UrlPath(System.String)
extern void IPhotonSocket_set_UrlPath_m8DC227CD6A8CDD360850C35C856D9EDDA8B165F0 (void);
// 0x0000009F System.String ExitGames.Client.Photon.IPhotonSocket::get_SerializationProtocol()
extern void IPhotonSocket_get_SerializationProtocol_m7FBB47DA69A1A8F4929A1BF625D2CC58C9492083 (void);
// 0x000000A0 System.Void ExitGames.Client.Photon.IPhotonSocket::.ctor(ExitGames.Client.Photon.PeerBase)
extern void IPhotonSocket__ctor_mE056977E4ABF8D825769957097BF00FBF3B92127 (void);
// 0x000000A1 System.Boolean ExitGames.Client.Photon.IPhotonSocket::Connect()
extern void IPhotonSocket_Connect_mCAEA0DACFE4E2EA057BA9F0B6154823A4F4843A1 (void);
// 0x000000A2 System.Boolean ExitGames.Client.Photon.IPhotonSocket::Disconnect()
// 0x000000A3 ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.IPhotonSocket::Send(System.Byte[],System.Int32)
// 0x000000A4 ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.IPhotonSocket::Receive(System.Byte[]&)
// 0x000000A5 System.Void ExitGames.Client.Photon.IPhotonSocket::HandleReceivedDatagram(System.Byte[],System.Int32,System.Boolean)
extern void IPhotonSocket_HandleReceivedDatagram_m78ED899FE11D7AC121B55B6EF487E689729F388C (void);
// 0x000000A6 System.Boolean ExitGames.Client.Photon.IPhotonSocket::ReportDebugOfLevel(ExitGames.Client.Photon.DebugLevel)
extern void IPhotonSocket_ReportDebugOfLevel_m42B7A34B2A760CA559E48D9E22CB28B0E87DEB51 (void);
// 0x000000A7 System.Void ExitGames.Client.Photon.IPhotonSocket::EnqueueDebugReturn(ExitGames.Client.Photon.DebugLevel,System.String)
extern void IPhotonSocket_EnqueueDebugReturn_mF56E7F4758AFE8CED4C051C28D687754CE92E4BC (void);
// 0x000000A8 System.Void ExitGames.Client.Photon.IPhotonSocket::HandleException(ExitGames.Client.Photon.StatusCode)
extern void IPhotonSocket_HandleException_mBD5906834CA0860520827A30D71970F2F533F032 (void);
// 0x000000A9 System.Boolean ExitGames.Client.Photon.IPhotonSocket::TryParseAddress(System.String,System.String&,System.UInt16&,System.String&,System.String&)
extern void IPhotonSocket_TryParseAddress_mB8A55C8DF5A977D2C4539923C2A3185A7DF7EAC9 (void);
// 0x000000AA System.Boolean ExitGames.Client.Photon.IPhotonSocket::IpAddressTryParse(System.String,System.Net.IPAddress&)
extern void IPhotonSocket_IpAddressTryParse_m7FC012A2DBA260FF63376C6F5D400B9634BEA22A (void);
// 0x000000AB System.Net.IPAddress[] ExitGames.Client.Photon.IPhotonSocket::GetIpAddresses(System.String)
extern void IPhotonSocket_GetIpAddresses_mF9228DAE21109CFE4F12DEF27CA5629AFEE89AD7 (void);
// 0x000000AC System.Int32 ExitGames.Client.Photon.IPhotonSocket::AddressSortComparer(System.Net.IPAddress,System.Net.IPAddress)
extern void IPhotonSocket_AddressSortComparer_m001457474D03F9CC1B2E153E9E3AF54DBDA25A2C (void);
// 0x000000AD System.Net.IPAddress ExitGames.Client.Photon.IPhotonSocket::GetIpAddress(System.String)
extern void IPhotonSocket_GetIpAddress_mC2AFD505F79D4B491D4CC30F29EA415AC6143081 (void);
// 0x000000AE System.Void ExitGames.Client.Photon.IPhotonSocket::<HandleException>b__52_0()
extern void IPhotonSocket_U3CHandleExceptionU3Eb__52_0_mFCF52B8AB45CAFA6D699C75F76D1A04AE38E2CA5 (void);
// 0x000000AF System.Void ExitGames.Client.Photon.IPhotonSocket_<>c::.cctor()
extern void U3CU3Ec__cctor_m84A0AA5DEBEF55FF34678B8A25053F4356ECE5F6 (void);
// 0x000000B0 System.Void ExitGames.Client.Photon.IPhotonSocket_<>c::.ctor()
extern void U3CU3Ec__ctor_m2DC6E88857116A70E8BBE90D855EFC747D9513F0 (void);
// 0x000000B1 System.String ExitGames.Client.Photon.IPhotonSocket_<>c::<GetIpAddresses>b__55_0(System.Net.IPAddress)
extern void U3CU3Ec_U3CGetIpAddressesU3Eb__55_0_m2E72D50540242120DC5420B230CD2BC722C4E50A (void);
// 0x000000B2 ExitGames.Client.Photon.IProtocol ExitGames.Client.Photon.SerializationProtocolFactory::Create(ExitGames.Client.Photon.SerializationProtocol)
extern void SerializationProtocolFactory_Create_m828411AF46F8D23FA6992DCECECC19C71512F91A (void);
// 0x000000B3 System.String ExitGames.Client.Photon.IProtocol::get_ProtocolType()
// 0x000000B4 System.Byte[] ExitGames.Client.Photon.IProtocol::get_VersionBytes()
// 0x000000B5 System.Void ExitGames.Client.Photon.IProtocol::Serialize(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
// 0x000000B6 System.Void ExitGames.Client.Photon.IProtocol::SerializeShort(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.Boolean)
// 0x000000B7 System.Void ExitGames.Client.Photon.IProtocol::SerializeString(ExitGames.Client.Photon.StreamBuffer,System.String,System.Boolean)
// 0x000000B8 System.Void ExitGames.Client.Photon.IProtocol::SerializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData,System.Boolean)
// 0x000000B9 System.Void ExitGames.Client.Photon.IProtocol::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,System.Boolean)
// 0x000000BA System.Void ExitGames.Client.Photon.IProtocol::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,System.Byte,ExitGames.Client.Photon.ParameterDictionary,System.Boolean)
// 0x000000BB System.Void ExitGames.Client.Photon.IProtocol::SerializeOperationResponse(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.OperationResponse,System.Boolean)
// 0x000000BC System.Object ExitGames.Client.Photon.IProtocol::Deserialize(ExitGames.Client.Photon.StreamBuffer,System.Byte,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
// 0x000000BD System.Int16 ExitGames.Client.Photon.IProtocol::DeserializeShort(ExitGames.Client.Photon.StreamBuffer)
// 0x000000BE System.Byte ExitGames.Client.Photon.IProtocol::DeserializeByte(ExitGames.Client.Photon.StreamBuffer)
// 0x000000BF ExitGames.Client.Photon.EventData ExitGames.Client.Photon.IProtocol::DeserializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
// 0x000000C0 ExitGames.Client.Photon.OperationRequest ExitGames.Client.Photon.IProtocol::DeserializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
// 0x000000C1 ExitGames.Client.Photon.OperationResponse ExitGames.Client.Photon.IProtocol::DeserializeOperationResponse(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
// 0x000000C2 ExitGames.Client.Photon.DisconnectMessage ExitGames.Client.Photon.IProtocol::DeserializeDisconnectMessage(ExitGames.Client.Photon.StreamBuffer)
// 0x000000C3 System.Byte[] ExitGames.Client.Photon.IProtocol::Serialize(System.Object)
extern void IProtocol_Serialize_mE36283E280487E33758F993A98FD77E7444B3A7D (void);
// 0x000000C4 System.Object ExitGames.Client.Photon.IProtocol::Deserialize(ExitGames.Client.Photon.StreamBuffer)
extern void IProtocol_Deserialize_m421744AC949C962A7ED4FA51C5288A8FC7098CBC (void);
// 0x000000C5 System.Object ExitGames.Client.Photon.IProtocol::Deserialize(System.Byte[])
extern void IProtocol_Deserialize_m91D6DE9AD7F486D6EEA1CBDA60EA64C111678CA7 (void);
// 0x000000C6 System.Object ExitGames.Client.Photon.IProtocol::DeserializeMessage(ExitGames.Client.Photon.StreamBuffer)
extern void IProtocol_DeserializeMessage_m0FF19BA502FB23788851D24B449572E461574F8C (void);
// 0x000000C7 System.Void ExitGames.Client.Photon.IProtocol::SerializeMessage(ExitGames.Client.Photon.StreamBuffer,System.Object)
extern void IProtocol_SerializeMessage_mFCA6D708093FF14AE91F9719B18D5021902E837A (void);
// 0x000000C8 System.Void ExitGames.Client.Photon.IProtocol::.ctor()
extern void IProtocol__ctor_mC1A6763F4AC0FAD207A96EE314767E45CB35A2ED (void);
// 0x000000C9 System.Boolean ExitGames.Client.Photon.ITrafficRecorder::get_Enabled()
// 0x000000CA System.Void ExitGames.Client.Photon.ITrafficRecorder::set_Enabled(System.Boolean)
// 0x000000CB System.Void ExitGames.Client.Photon.ITrafficRecorder::Record(System.Byte[],System.Int32,System.Boolean,System.Int16,ExitGames.Client.Photon.IPhotonSocket)
// 0x000000CC ExitGames.Client.Photon.NCommand ExitGames.Client.Photon.NCommandPool::Acquire(ExitGames.Client.Photon.EnetPeer,System.Byte[],System.Int32&)
extern void NCommandPool_Acquire_m034BEAA7EEDAB0441235A095ECBE25E638647029 (void);
// 0x000000CD ExitGames.Client.Photon.NCommand ExitGames.Client.Photon.NCommandPool::Acquire(ExitGames.Client.Photon.EnetPeer,System.Byte,ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void NCommandPool_Acquire_mE3833B289E40184616ABD0F0AF6B7CDDB2216F01 (void);
// 0x000000CE System.Void ExitGames.Client.Photon.NCommandPool::Release(ExitGames.Client.Photon.NCommand)
extern void NCommandPool_Release_m50E5DD59ABBA5EAA06DD46EB6A15880F12FD8EFE (void);
// 0x000000CF System.Void ExitGames.Client.Photon.NCommandPool::.ctor()
extern void NCommandPool__ctor_m6D1F0DB9DA198E389FA0D2D09832F91D4A0663E1 (void);
// 0x000000D0 System.Int32 ExitGames.Client.Photon.NCommand::get_SizeOfPayload()
extern void NCommand_get_SizeOfPayload_mE715C222EF4476056DF1471B5DF9D6991B14A8ED (void);
// 0x000000D1 System.Boolean ExitGames.Client.Photon.NCommand::get_IsFlaggedUnsequenced()
extern void NCommand_get_IsFlaggedUnsequenced_m568A51F3AFC3B6FE78BD5BF7B640BD05DB9E2B90 (void);
// 0x000000D2 System.Boolean ExitGames.Client.Photon.NCommand::get_IsFlaggedReliable()
extern void NCommand_get_IsFlaggedReliable_m7F4045E61D3C3FA6925BC7FE5D742EB329858525 (void);
// 0x000000D3 System.Void ExitGames.Client.Photon.NCommand::CreateAck(System.Byte[],System.Int32,ExitGames.Client.Photon.NCommand,System.Int32)
extern void NCommand_CreateAck_m2ADE0341B41E7E14E578E0E61D4A4C77EF034E0A (void);
// 0x000000D4 System.Void ExitGames.Client.Photon.NCommand::.ctor(ExitGames.Client.Photon.EnetPeer,System.Byte,ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void NCommand__ctor_mA134B38B05DA8E71D6E9E3A5D81DAE2EB04CAC88 (void);
// 0x000000D5 System.Void ExitGames.Client.Photon.NCommand::Initialize(ExitGames.Client.Photon.EnetPeer,System.Byte,ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void NCommand_Initialize_m7EB458A2A7EC2EB0599D38E1320E1B1AF8F3C5BA (void);
// 0x000000D6 System.Void ExitGames.Client.Photon.NCommand::.ctor(ExitGames.Client.Photon.EnetPeer,System.Byte[],System.Int32&)
extern void NCommand__ctor_mCCF2652E29B7C3A0B5A530BE08CB5B6D3CD38B50 (void);
// 0x000000D7 System.Void ExitGames.Client.Photon.NCommand::Initialize(ExitGames.Client.Photon.EnetPeer,System.Byte[],System.Int32&)
extern void NCommand_Initialize_m30F530D6A6E57B4A413761BAA814039542E277EB (void);
// 0x000000D8 System.Void ExitGames.Client.Photon.NCommand::Reset()
extern void NCommand_Reset_mBC61BFE8E57D782D72726A1461822CE2B4407E80 (void);
// 0x000000D9 System.Void ExitGames.Client.Photon.NCommand::SerializeHeader(System.Byte[],System.Int32&)
extern void NCommand_SerializeHeader_mA5E87B8D648794E0AF8D0CE8C6C88F403A484B82 (void);
// 0x000000DA System.Byte[] ExitGames.Client.Photon.NCommand::Serialize()
extern void NCommand_Serialize_mA5B2F00F5474AE4F4A1E06D71559BACC9AF5624C (void);
// 0x000000DB System.Void ExitGames.Client.Photon.NCommand::FreePayload()
extern void NCommand_FreePayload_mA5F75525FD735957EB941B508AFDB078A903AC6E (void);
// 0x000000DC System.Void ExitGames.Client.Photon.NCommand::Release()
extern void NCommand_Release_m9F4BDC65F40BEB47847E7F2A9F2DCE71D498D2F7 (void);
// 0x000000DD System.Int32 ExitGames.Client.Photon.NCommand::CompareTo(ExitGames.Client.Photon.NCommand)
extern void NCommand_CompareTo_m25236EF216DBCED568899B9FADE1C839ECC966EF (void);
// 0x000000DE System.String ExitGames.Client.Photon.NCommand::ToString()
extern void NCommand_ToString_m4F8538A56BCD5008746DD85F7932D627D45AC034 (void);
// 0x000000DF System.Void ExitGames.Client.Photon.SimulationItem::.ctor()
extern void SimulationItem__ctor_mB8D0480360EB2B0AE2A6E0B00B3ED82061966998 (void);
// 0x000000E0 System.Int32 ExitGames.Client.Photon.SimulationItem::get_Delay()
extern void SimulationItem_get_Delay_m992E38FB5B1CE1CED810A3600507EBF256B3F941 (void);
// 0x000000E1 System.Void ExitGames.Client.Photon.SimulationItem::set_Delay(System.Int32)
extern void SimulationItem_set_Delay_m20FFD2B127A1CACACE7E0211A42BB43C909B592B (void);
// 0x000000E2 System.Boolean ExitGames.Client.Photon.NetworkSimulationSet::get_IsSimulationEnabled()
extern void NetworkSimulationSet_get_IsSimulationEnabled_m47618A34244193AE829DE9B8E858CE328EE472A4 (void);
// 0x000000E3 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_IsSimulationEnabled(System.Boolean)
extern void NetworkSimulationSet_set_IsSimulationEnabled_mF0B2D88CA13EBBD72783E6FEA6906069B5DE87E2 (void);
// 0x000000E4 System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_OutgoingLag()
extern void NetworkSimulationSet_get_OutgoingLag_m1D497FC0EC1D765A929804EBA791A057DCD985C9 (void);
// 0x000000E5 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_OutgoingLag(System.Int32)
extern void NetworkSimulationSet_set_OutgoingLag_m115104A9606EFD6C1AC71DA697EA91BDA8356728 (void);
// 0x000000E6 System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_OutgoingJitter()
extern void NetworkSimulationSet_get_OutgoingJitter_mF78EF15C69B1B0197AC359A9299955061480A166 (void);
// 0x000000E7 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_OutgoingJitter(System.Int32)
extern void NetworkSimulationSet_set_OutgoingJitter_mADBCB529A1F67F9CF10B779AF01B3191455F0A97 (void);
// 0x000000E8 System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_OutgoingLossPercentage()
extern void NetworkSimulationSet_get_OutgoingLossPercentage_mC93121324017E776937D3107C88D49C1E842A938 (void);
// 0x000000E9 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_OutgoingLossPercentage(System.Int32)
extern void NetworkSimulationSet_set_OutgoingLossPercentage_m276DD42229AA08EFC4AC089C62EDCB1ADAD2CC4E (void);
// 0x000000EA System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_IncomingLag()
extern void NetworkSimulationSet_get_IncomingLag_mCF5C3C95B9BF351C082614516F9BCDC9F5C9E593 (void);
// 0x000000EB System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_IncomingLag(System.Int32)
extern void NetworkSimulationSet_set_IncomingLag_mD8A8C824A65DCA9999464B52FDB816A89966BBCF (void);
// 0x000000EC System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_IncomingJitter()
extern void NetworkSimulationSet_get_IncomingJitter_mA8D155C61FF951A0ADC0D898B26173D87C515C27 (void);
// 0x000000ED System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_IncomingJitter(System.Int32)
extern void NetworkSimulationSet_set_IncomingJitter_m7A102D778F9A7D02E7B69FF6C29632478CE3DFB5 (void);
// 0x000000EE System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_IncomingLossPercentage()
extern void NetworkSimulationSet_get_IncomingLossPercentage_m42AF5F432276068AA7B4BF4DE9F9E0D00B8CFA3A (void);
// 0x000000EF System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_IncomingLossPercentage(System.Int32)
extern void NetworkSimulationSet_set_IncomingLossPercentage_m53495F0DB5FDF95281F15A597CADE01D2D3274D5 (void);
// 0x000000F0 System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_LostPackagesOut()
extern void NetworkSimulationSet_get_LostPackagesOut_m76460DE18DD3CA7D7F143655A391AEF1A5B0993B (void);
// 0x000000F1 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_LostPackagesOut(System.Int32)
extern void NetworkSimulationSet_set_LostPackagesOut_m2B350E2F46E65E7F3E2727C1658C5DF522FC0D22 (void);
// 0x000000F2 System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_LostPackagesIn()
extern void NetworkSimulationSet_get_LostPackagesIn_mF9BE67E3A3C2D7B1046CA2D7E51C3B80D2B65DFC (void);
// 0x000000F3 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_LostPackagesIn(System.Int32)
extern void NetworkSimulationSet_set_LostPackagesIn_m2E37ECD65D991774806793C6D1BAE9B06FF79A3F (void);
// 0x000000F4 System.String ExitGames.Client.Photon.NetworkSimulationSet::ToString()
extern void NetworkSimulationSet_ToString_mFFAF45B81FEEF35C48269E525F292F677F1D2733 (void);
// 0x000000F5 System.Void ExitGames.Client.Photon.NetworkSimulationSet::.ctor()
extern void NetworkSimulationSet__ctor_mAA4F85C0AEB7213D220F4A24F90F134E71B214BC (void);
// 0x000000F6 System.Void ExitGames.Client.Photon.ParameterDictionary::.ctor()
extern void ParameterDictionary__ctor_m8B49AB5AEB9C55CE7185C69BA6C59ECE68CB61DF (void);
// 0x000000F7 System.Void ExitGames.Client.Photon.ParameterDictionary::.ctor(System.Int32)
extern void ParameterDictionary__ctor_m6900EE93057F3DF22FCE07CFF157E57D36512423 (void);
// 0x000000F8 ExitGames.Client.Photon.NonAllocDictionary`2<System.Byte,System.Object> ExitGames.Client.Photon.ParameterDictionary::op_Implicit(ExitGames.Client.Photon.ParameterDictionary)
extern void ParameterDictionary_op_Implicit_m1B42BEC6E2D2CE44E2BBFF21006B0B7EB9815EB9 (void);
// 0x000000F9 System.Object ExitGames.Client.Photon.ParameterDictionary::get_Item(System.Byte)
extern void ParameterDictionary_get_Item_m1D37EB387177C5154937E23B8BEBF97FC1B72F71 (void);
// 0x000000FA System.Void ExitGames.Client.Photon.ParameterDictionary::set_Item(System.Byte,System.Object)
extern void ParameterDictionary_set_Item_mF07CA6A013F2881B79E3B2115214589087741BEF (void);
// 0x000000FB System.Int32 ExitGames.Client.Photon.ParameterDictionary::get_Count()
extern void ParameterDictionary_get_Count_m488B3EBF29B916257B82BDF42DC9344A161EFFDF (void);
// 0x000000FC System.Void ExitGames.Client.Photon.ParameterDictionary::Clear()
extern void ParameterDictionary_Clear_m13B7A2459B37EC6BEB16D8772DC3F420C9F278A4 (void);
// 0x000000FD System.Void ExitGames.Client.Photon.ParameterDictionary::Add(System.Byte,System.String)
extern void ParameterDictionary_Add_mF03F5FAA71BC7F0BD89C706964592C09EF18B31E (void);
// 0x000000FE System.Void ExitGames.Client.Photon.ParameterDictionary::Add(System.Byte,ExitGames.Client.Photon.Hashtable)
extern void ParameterDictionary_Add_mBAB093D7885A2E18269ABD1132B39A2743CC9B4C (void);
// 0x000000FF System.Void ExitGames.Client.Photon.ParameterDictionary::Add(System.Byte,System.Byte)
extern void ParameterDictionary_Add_m6ED0FBED94C1D912678D23AABA40EDE7D6B26A49 (void);
// 0x00000100 System.Void ExitGames.Client.Photon.ParameterDictionary::Add(System.Byte,System.Boolean)
extern void ParameterDictionary_Add_mF03786DF05797C61052CDC5E9E2E9A1D6C7A3AA6 (void);
// 0x00000101 System.Void ExitGames.Client.Photon.ParameterDictionary::Add(System.Byte,System.Int16)
extern void ParameterDictionary_Add_mFDD4FCCB62F4B75E781C96E5BA2B5AAF64A5337D (void);
// 0x00000102 System.Void ExitGames.Client.Photon.ParameterDictionary::Add(System.Byte,System.Int32)
extern void ParameterDictionary_Add_m20EA3893BFC308C70A07390B90A379EC0323BED7 (void);
// 0x00000103 System.Void ExitGames.Client.Photon.ParameterDictionary::Add(System.Byte,System.Int64)
extern void ParameterDictionary_Add_m2BBF93B32D483E2CB6D4D0EBC9832A45A7122C75 (void);
// 0x00000104 System.Void ExitGames.Client.Photon.ParameterDictionary::Add(System.Byte,System.Object)
extern void ParameterDictionary_Add_m3F1A06F00F20F42C3B87ED370B4B57C2205EE2A0 (void);
// 0x00000105 T ExitGames.Client.Photon.ParameterDictionary::Unwrap(System.Byte)
// 0x00000106 T ExitGames.Client.Photon.ParameterDictionary::Get(System.Byte)
// 0x00000107 System.Boolean ExitGames.Client.Photon.ParameterDictionary::ContainsKey(System.Byte)
extern void ParameterDictionary_ContainsKey_m7FF5DC8A8B0A97143B303A195EDBA8AFC634B4C4 (void);
// 0x00000108 System.Object ExitGames.Client.Photon.ParameterDictionary::TryGetObject(System.Byte)
extern void ParameterDictionary_TryGetObject_mAF0C3E9ACFFAFF7384DDDE581A7C06C94FA87E49 (void);
// 0x00000109 System.Boolean ExitGames.Client.Photon.ParameterDictionary::TryGetValue(System.Byte,System.Object&)
extern void ParameterDictionary_TryGetValue_mFF3D9727D9763C52EC1784956D3F96A36F06819E (void);
// 0x0000010A System.Boolean ExitGames.Client.Photon.ParameterDictionary::TryGetValue(System.Byte,T&)
// 0x0000010B ExitGames.Client.Photon.ParameterDictionary_KeyValuePair ExitGames.Client.Photon.ParameterDictionary::GetEnumerator()
extern void ParameterDictionary_GetEnumerator_m23B3039379C809BD0D6CF9AA24EEC6A29E9EC143 (void);
// 0x0000010C System.String ExitGames.Client.Photon.ParameterDictionary::ToStringFull(System.Boolean)
extern void ParameterDictionary_ToStringFull_mBC9D3ACAC94C11789840F08F7F683A906F0D75D6 (void);
// 0x0000010D System.Void ExitGames.Client.Photon.ParameterDictionary_KeyValuePair::.ctor(ExitGames.Client.Photon.ParameterDictionary)
extern void KeyValuePair__ctor_m4E445DB86086ABB6508DBA097900C06CBEEF4D11_AdjustorThunk (void);
// 0x0000010E System.Collections.Generic.KeyValuePair`2<System.Byte,System.Object> ExitGames.Client.Photon.ParameterDictionary_KeyValuePair::get_Current()
extern void KeyValuePair_get_Current_m6EBA06DEDA08F64CAF4B8796AB901A9D4C8ED947_AdjustorThunk (void);
// 0x0000010F System.Boolean ExitGames.Client.Photon.ParameterDictionary_KeyValuePair::MoveNext()
extern void KeyValuePair_MoveNext_mB9769FAF69400820D54D2A5C590DD1C02E71A66E_AdjustorThunk (void);
// 0x00000110 System.Void ExitGames.Client.Photon.PhotonCodes::.cctor()
extern void PhotonCodes__cctor_mBBD974B4BC67C38543F4FE015484FF0E8A8694B3 (void);
// 0x00000111 System.String ExitGames.Client.Photon.PeerBase::get_ServerAddress()
extern void PeerBase_get_ServerAddress_m10944D189D17F5DCA7F729BCC5C9157C1560309E (void);
// 0x00000112 System.Void ExitGames.Client.Photon.PeerBase::set_ServerAddress(System.String)
extern void PeerBase_set_ServerAddress_m24011D39B9330A075D6A3E44240B73E5222ABD6A (void);
// 0x00000113 System.String ExitGames.Client.Photon.PeerBase::get_ProxyServerAddress()
extern void PeerBase_get_ProxyServerAddress_mBE0574FE50C191F0866A35B6776813EC95EE4919 (void);
// 0x00000114 System.Void ExitGames.Client.Photon.PeerBase::set_ProxyServerAddress(System.String)
extern void PeerBase_set_ProxyServerAddress_m264AFBC59E0F679449B38D7649874594EF3F123F (void);
// 0x00000115 ExitGames.Client.Photon.IPhotonPeerListener ExitGames.Client.Photon.PeerBase::get_Listener()
extern void PeerBase_get_Listener_m03954E24EFA4ABCBB26DA56FAE7053F2393428A5 (void);
// 0x00000116 ExitGames.Client.Photon.DebugLevel ExitGames.Client.Photon.PeerBase::get_debugOut()
extern void PeerBase_get_debugOut_m67D7BD3029FBE9AD23445226209BD39358CE3B4C (void);
// 0x00000117 System.Int32 ExitGames.Client.Photon.PeerBase::get_DisconnectTimeout()
extern void PeerBase_get_DisconnectTimeout_m09FBDA78FE60E6BBD9B385693C36C9EF4F78A3B4 (void);
// 0x00000118 System.Int32 ExitGames.Client.Photon.PeerBase::get_timePingInterval()
extern void PeerBase_get_timePingInterval_m96D5A38D056163C1E669CFC6A4287A339B7D8E32 (void);
// 0x00000119 System.Byte ExitGames.Client.Photon.PeerBase::get_ChannelCount()
extern void PeerBase_get_ChannelCount_m78B93310192C9A1C91E8F4C1462E30EF6718AA0D (void);
// 0x0000011A System.Int64 ExitGames.Client.Photon.PeerBase::get_BytesOut()
extern void PeerBase_get_BytesOut_m80A5C32F5F907925ED4B3ED82CA27424390452BE (void);
// 0x0000011B System.Int64 ExitGames.Client.Photon.PeerBase::get_BytesIn()
extern void PeerBase_get_BytesIn_mB0ACED6C6DFC04C4B2746D26A617BEACDFCEBEB2 (void);
// 0x0000011C System.Int32 ExitGames.Client.Photon.PeerBase::get_QueuedIncomingCommandsCount()
// 0x0000011D System.Int32 ExitGames.Client.Photon.PeerBase::get_QueuedOutgoingCommandsCount()
// 0x0000011E System.Int32 ExitGames.Client.Photon.PeerBase::get_SentReliableCommandsCount()
extern void PeerBase_get_SentReliableCommandsCount_m59964C176DA84948D163F485743C3DBDED5B0530 (void);
// 0x0000011F System.String ExitGames.Client.Photon.PeerBase::get_PeerID()
extern void PeerBase_get_PeerID_mC90660C0DB65BFF3A934E4D9DAECFEF692665DA8 (void);
// 0x00000120 System.Int32 ExitGames.Client.Photon.PeerBase::get_timeInt()
extern void PeerBase_get_timeInt_m684602318BEA8E6EBF19C0CAA720DDD52B4262CD (void);
// 0x00000121 System.Int32 ExitGames.Client.Photon.PeerBase::get_outgoingStreamBufferSize()
extern void PeerBase_get_outgoingStreamBufferSize_m64B6618D5B7A1844F7443D3CADEF0FA8DB0A65F7 (void);
// 0x00000122 System.Boolean ExitGames.Client.Photon.PeerBase::get_IsSendingOnlyAcks()
extern void PeerBase_get_IsSendingOnlyAcks_mC8DE21F87D58AB7887D6F342A0DF59C4932855F2 (void);
// 0x00000123 System.Int32 ExitGames.Client.Photon.PeerBase::get_mtu()
extern void PeerBase_get_mtu_m7E93C9FB411EAD89E47739FA4ACE00AA953418E5 (void);
// 0x00000124 System.Boolean ExitGames.Client.Photon.PeerBase::get_IsIpv6()
extern void PeerBase_get_IsIpv6_m489A5BDC9E0D5C66AC03AE6894A23CB8FBBB8171 (void);
// 0x00000125 System.Void ExitGames.Client.Photon.PeerBase::.ctor()
extern void PeerBase__ctor_m8E3B20C66C5220AA2B22CFC69A1F4EC4692194FF (void);
// 0x00000126 ExitGames.Client.Photon.StreamBuffer ExitGames.Client.Photon.PeerBase::MessageBufferPoolGet()
extern void PeerBase_MessageBufferPoolGet_m29E0E9ED1F3F90AD695A68274405C657476D6554 (void);
// 0x00000127 System.Void ExitGames.Client.Photon.PeerBase::MessageBufferPoolPut(ExitGames.Client.Photon.StreamBuffer)
extern void PeerBase_MessageBufferPoolPut_m68F6EDE4E589B82EC35EC47535D38F17C7D4A729 (void);
// 0x00000128 System.Void ExitGames.Client.Photon.PeerBase::Reset()
extern void PeerBase_Reset_m9E55CF5689C3B69E1E96DAC91F5B20761349F844 (void);
// 0x00000129 System.Boolean ExitGames.Client.Photon.PeerBase::Connect(System.String,System.String,System.String,System.Object)
// 0x0000012A System.String ExitGames.Client.Photon.PeerBase::GetHttpKeyValueString(System.Collections.Generic.Dictionary`2<System.String,System.String>)
extern void PeerBase_GetHttpKeyValueString_mFED3D50AB334A1C7925C3D000F902DC6E486A0AB (void);
// 0x0000012B System.Byte[] ExitGames.Client.Photon.PeerBase::WriteInitRequest()
extern void PeerBase_WriteInitRequest_m93B6B8C2D27A36A220016568A1CBC06CED1AC150 (void);
// 0x0000012C System.Byte[] ExitGames.Client.Photon.PeerBase::WriteInitV3()
extern void PeerBase_WriteInitV3_m6EA0C9832C7DE0D063F99FE6545236FCF4D2932F (void);
// 0x0000012D System.String ExitGames.Client.Photon.PeerBase::PepareWebSocketUrl(System.String,System.String,System.Object)
extern void PeerBase_PepareWebSocketUrl_m412ED80EB0138A636EC1801EE09AB65D7198DA25 (void);
// 0x0000012E System.Void ExitGames.Client.Photon.PeerBase::OnConnect()
// 0x0000012F System.Void ExitGames.Client.Photon.PeerBase::InitCallback()
extern void PeerBase_InitCallback_m38983153A5ADCC639181C20ED0114FB9239780B7 (void);
// 0x00000130 System.Void ExitGames.Client.Photon.PeerBase::Disconnect()
// 0x00000131 System.Void ExitGames.Client.Photon.PeerBase::StopConnection()
// 0x00000132 System.Void ExitGames.Client.Photon.PeerBase::FetchServerTimestamp()
// 0x00000133 System.Boolean ExitGames.Client.Photon.PeerBase::IsTransportEncrypted()
// 0x00000134 System.Boolean ExitGames.Client.Photon.PeerBase::EnqueuePhotonMessage(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.SendOptions)
// 0x00000135 ExitGames.Client.Photon.StreamBuffer ExitGames.Client.Photon.PeerBase::SerializeOperationToMessage(System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,ExitGames.Client.Photon.EgMessageType,System.Boolean)
extern void PeerBase_SerializeOperationToMessage_mEC78C0876E869EA1E9A2A34DF32FAD4A24C33AC4 (void);
// 0x00000136 ExitGames.Client.Photon.StreamBuffer ExitGames.Client.Photon.PeerBase::SerializeOperationToMessage(System.Byte,ExitGames.Client.Photon.ParameterDictionary,ExitGames.Client.Photon.EgMessageType,System.Boolean)
extern void PeerBase_SerializeOperationToMessage_mF9561C10973B6FAD518A88DB27585309512E6A5A (void);
// 0x00000137 ExitGames.Client.Photon.StreamBuffer ExitGames.Client.Photon.PeerBase::SerializeMessageToMessage(System.Object,System.Boolean)
extern void PeerBase_SerializeMessageToMessage_mF0EEF67E965C3C78DAA22E9A02CEC4560798F668 (void);
// 0x00000138 System.Boolean ExitGames.Client.Photon.PeerBase::SendOutgoingCommands()
// 0x00000139 System.Boolean ExitGames.Client.Photon.PeerBase::SendAcksOnly()
extern void PeerBase_SendAcksOnly_m2A12BBBD2B890A60755FD90E3CFAAA90D45C3B41 (void);
// 0x0000013A System.Void ExitGames.Client.Photon.PeerBase::ReceiveIncomingCommands(System.Byte[],System.Int32)
// 0x0000013B System.Boolean ExitGames.Client.Photon.PeerBase::DispatchIncomingCommands()
// 0x0000013C System.Boolean ExitGames.Client.Photon.PeerBase::DeserializeMessageAndCallback(ExitGames.Client.Photon.StreamBuffer)
extern void PeerBase_DeserializeMessageAndCallback_m6E85A9674C09080C61D8B364F46136EB43D000EE (void);
// 0x0000013D System.Void ExitGames.Client.Photon.PeerBase::UpdateRoundTripTimeAndVariance(System.Int32)
extern void PeerBase_UpdateRoundTripTimeAndVariance_m951EC733736AB9475EE334DB283A32C6543FB3A0 (void);
// 0x0000013E System.Boolean ExitGames.Client.Photon.PeerBase::ExchangeKeysForEncryption(System.Object)
extern void PeerBase_ExchangeKeysForEncryption_mFE32BAAF2F73B9707F7C0164B5CE7259C0C5A8AE (void);
// 0x0000013F System.Void ExitGames.Client.Photon.PeerBase::DeriveSharedKey(ExitGames.Client.Photon.OperationResponse)
extern void PeerBase_DeriveSharedKey_m22D58A8EB38AD5BBDF8891EAA1ED1AC9FA3D0FF4 (void);
// 0x00000140 System.Void ExitGames.Client.Photon.PeerBase::InitEncryption(System.Byte[])
extern void PeerBase_InitEncryption_mB71FBA3A0A599F67FDE4DA3634BD676D8210481A (void);
// 0x00000141 System.Void ExitGames.Client.Photon.PeerBase::EnqueueActionForDispatch(ExitGames.Client.Photon.PeerBase_MyAction)
extern void PeerBase_EnqueueActionForDispatch_mC79508D2BA63A62A2E052D9C48B7A5C71B8DD84B (void);
// 0x00000142 System.Void ExitGames.Client.Photon.PeerBase::EnqueueDebugReturn(ExitGames.Client.Photon.DebugLevel,System.String)
extern void PeerBase_EnqueueDebugReturn_mA970CB09DF2811F5A9678470B73573670C3C4025 (void);
// 0x00000143 System.Void ExitGames.Client.Photon.PeerBase::EnqueueStatusCallback(ExitGames.Client.Photon.StatusCode)
extern void PeerBase_EnqueueStatusCallback_mD7222780DC33EB9871C8C7628A5EF8509027B2A6 (void);
// 0x00000144 ExitGames.Client.Photon.NetworkSimulationSet ExitGames.Client.Photon.PeerBase::get_NetworkSimulationSettings()
extern void PeerBase_get_NetworkSimulationSettings_m5AF79B90A13BCA5BE4C3A1BCB9B7AE4BA8FF11CC (void);
// 0x00000145 System.Void ExitGames.Client.Photon.PeerBase::SendNetworkSimulated(System.Byte[])
extern void PeerBase_SendNetworkSimulated_m419DC4EAFC08D5B49737E8A2EE62DBEA1C23C505 (void);
// 0x00000146 System.Void ExitGames.Client.Photon.PeerBase::ReceiveNetworkSimulated(System.Byte[])
extern void PeerBase_ReceiveNetworkSimulated_mA600DD4B96F273F83E1637CC7BB4FBFD67053DAE (void);
// 0x00000147 System.Void ExitGames.Client.Photon.PeerBase::NetworkSimRun()
extern void PeerBase_NetworkSimRun_m584DA041044DBDFC2349FC4F70B9C06F4BB40FFF (void);
// 0x00000148 System.Boolean ExitGames.Client.Photon.PeerBase::get_TrafficStatsEnabled()
extern void PeerBase_get_TrafficStatsEnabled_mCEB79F943EED0CF4EABE5FBD706829E685B26D84 (void);
// 0x00000149 ExitGames.Client.Photon.TrafficStats ExitGames.Client.Photon.PeerBase::get_TrafficStatsIncoming()
extern void PeerBase_get_TrafficStatsIncoming_m7EA752B6B8C63E370775F0D6DD1A90BB9671F07C (void);
// 0x0000014A ExitGames.Client.Photon.TrafficStats ExitGames.Client.Photon.PeerBase::get_TrafficStatsOutgoing()
extern void PeerBase_get_TrafficStatsOutgoing_m796734FDA942AD0B88124CA19D209F9849B2F04C (void);
// 0x0000014B ExitGames.Client.Photon.TrafficStatsGameLevel ExitGames.Client.Photon.PeerBase::get_TrafficStatsGameLevel()
extern void PeerBase_get_TrafficStatsGameLevel_m4047DD71E6DDAA793A48AF43CD35B71872CDFA83 (void);
// 0x0000014C System.Void ExitGames.Client.Photon.PeerBase::.cctor()
extern void PeerBase__cctor_m43DFD5487B66142A8F8D42F5E57874E071DC28F3 (void);
// 0x0000014D System.Void ExitGames.Client.Photon.PeerBase_MyAction::.ctor(System.Object,System.IntPtr)
extern void MyAction__ctor_mA4E45068C583C9A36D57A62DD11313423F6D660E (void);
// 0x0000014E System.Void ExitGames.Client.Photon.PeerBase_MyAction::Invoke()
extern void MyAction_Invoke_m8ED616F18FBC1F97985ABADD10C44653D0E8D689 (void);
// 0x0000014F System.IAsyncResult ExitGames.Client.Photon.PeerBase_MyAction::BeginInvoke(System.AsyncCallback,System.Object)
extern void MyAction_BeginInvoke_mA7C62E36147456BB8EF51AEC520CCB52805DF43E (void);
// 0x00000150 System.Void ExitGames.Client.Photon.PeerBase_MyAction::EndInvoke(System.IAsyncResult)
extern void MyAction_EndInvoke_mED909E72E34A1303A3BC8DEDE6E4B8924A518889 (void);
// 0x00000151 System.Void ExitGames.Client.Photon.PeerBase_<>c__DisplayClass110_0::.ctor()
extern void U3CU3Ec__DisplayClass110_0__ctor_mE0B26BCE8BE0B33BB719278BC4F28DD05AB8AABB (void);
// 0x00000152 System.Void ExitGames.Client.Photon.PeerBase_<>c__DisplayClass110_0::<EnqueueDebugReturn>b__0()
extern void U3CU3Ec__DisplayClass110_0_U3CEnqueueDebugReturnU3Eb__0_mDA77118CE7115DE46F0769C76318F5DFB7790F46 (void);
// 0x00000153 System.Void ExitGames.Client.Photon.PeerBase_<>c__DisplayClass111_0::.ctor()
extern void U3CU3Ec__DisplayClass111_0__ctor_m10987EAEB786E1E1318F4F3ED9D1C06081B1354F (void);
// 0x00000154 System.Void ExitGames.Client.Photon.PeerBase_<>c__DisplayClass111_0::<EnqueueStatusCallback>b__0()
extern void U3CU3Ec__DisplayClass111_0_U3CEnqueueStatusCallbackU3Eb__0_m0ECC377EE1B7C6B72BB7DEB3CE58C29B879AAD3B (void);
// 0x00000155 System.Void ExitGames.Client.Photon.PhotonClientWebSocket::.ctor(ExitGames.Client.Photon.PeerBase)
extern void PhotonClientWebSocket__ctor_m3B182E99BF52CFB3ACFCFAFB353F7784F59ABFA6 (void);
// 0x00000156 System.Boolean ExitGames.Client.Photon.PhotonClientWebSocket::Connect()
extern void PhotonClientWebSocket_Connect_m40CAD7964783313850390D7D3F1033C5D7098D2A (void);
// 0x00000157 System.Void ExitGames.Client.Photon.PhotonClientWebSocket::AsyncConnectAndReceive()
extern void PhotonClientWebSocket_AsyncConnectAndReceive_mBA69B40E95B4C83FFA1DFC0143D771AFB4CD15C9 (void);
// 0x00000158 System.Boolean ExitGames.Client.Photon.PhotonClientWebSocket::Disconnect()
extern void PhotonClientWebSocket_Disconnect_m38BD261C5551EC438787AD47AFCFA4909514FFE3 (void);
// 0x00000159 ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.PhotonClientWebSocket::Send(System.Byte[],System.Int32)
extern void PhotonClientWebSocket_Send_mAEE5EB5A2FE9BA01610BFFE9095C0A1B651F1110 (void);
// 0x0000015A ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.PhotonClientWebSocket::Receive(System.Byte[]&)
extern void PhotonClientWebSocket_Receive_m4ABE9F7F789099E55D8325EA0DB6988D32C4E3FF (void);
// 0x0000015B System.Int32 ExitGames.Client.Photon.PhotonPeer::get_CommandBufferSize()
extern void PhotonPeer_get_CommandBufferSize_m443228DB7FE2194797798162B25AA05CEEF4582C (void);
// 0x0000015C System.Void ExitGames.Client.Photon.PhotonPeer::set_CommandBufferSize(System.Int32)
extern void PhotonPeer_set_CommandBufferSize_mB86FA5959011D5529F87F6A356D07DAE87DAEB54 (void);
// 0x0000015D System.Int32 ExitGames.Client.Photon.PhotonPeer::get_LimitOfUnreliableCommands()
extern void PhotonPeer_get_LimitOfUnreliableCommands_mD0FCB02B8DB2B0123E445678B94830FD883ACE93 (void);
// 0x0000015E System.Void ExitGames.Client.Photon.PhotonPeer::set_LimitOfUnreliableCommands(System.Int32)
extern void PhotonPeer_set_LimitOfUnreliableCommands_mB7994DDBF3E868DB57BDF00696E75A469B98B070 (void);
// 0x0000015F System.Int32 ExitGames.Client.Photon.PhotonPeer::get_LocalTimeInMilliSeconds()
extern void PhotonPeer_get_LocalTimeInMilliSeconds_m0625AC365852EAF0CAB2E368E8348ECB1F345C46 (void);
// 0x00000160 System.String ExitGames.Client.Photon.PhotonPeer::CommandLogToString()
extern void PhotonPeer_CommandLogToString_m5383F9093DF320E726EC6FB6C84D3C2FE6986A12 (void);
// 0x00000161 System.Byte ExitGames.Client.Photon.PhotonPeer::get_ClientSdkIdShifted()
extern void PhotonPeer_get_ClientSdkIdShifted_m9DB2F195BE27630E51359D1933180351A86AD121 (void);
// 0x00000162 System.String ExitGames.Client.Photon.PhotonPeer::get_ClientVersion()
extern void PhotonPeer_get_ClientVersion_m2A40E299025E03015641C18B33FA8BA33F740318 (void);
// 0x00000163 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_NativeSocketLibAvailable()
extern void PhotonPeer_get_NativeSocketLibAvailable_m98A0EF479F65080CA9AAD1E19E0DDAF0A6E22974 (void);
// 0x00000164 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_NativePayloadEncryptionLibAvailable()
extern void PhotonPeer_get_NativePayloadEncryptionLibAvailable_mAEC6A41A26C2ADB9A0D3385B217CA1F9B92676F4 (void);
// 0x00000165 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_NativeDatagramEncryptionLibAvailable()
extern void PhotonPeer_get_NativeDatagramEncryptionLibAvailable_mEA9CF5032B974ED8BCA45AB45F99D85DDCB6EC7C (void);
// 0x00000166 System.Void ExitGames.Client.Photon.PhotonPeer::CheckNativeLibsAvailability()
extern void PhotonPeer_CheckNativeLibsAvailability_m8A3871A8DB5FEB2C731E29EB87DF724A03D1D870 (void);
// 0x00000167 ExitGames.Client.Photon.SerializationProtocol ExitGames.Client.Photon.PhotonPeer::get_SerializationProtocolType()
extern void PhotonPeer_get_SerializationProtocolType_m3E0FE394D65FD240003DA72F52AE43F2019AF8B1 (void);
// 0x00000168 System.Void ExitGames.Client.Photon.PhotonPeer::set_SerializationProtocolType(ExitGames.Client.Photon.SerializationProtocol)
extern void PhotonPeer_set_SerializationProtocolType_m02676498FE60666B33768152B5CA30C4F8FC6EFD (void);
// 0x00000169 System.Type ExitGames.Client.Photon.PhotonPeer::get_SocketImplementation()
extern void PhotonPeer_get_SocketImplementation_m4CFE54CA5FCF0BB5820A1B42914AD7484D3A5198 (void);
// 0x0000016A System.Void ExitGames.Client.Photon.PhotonPeer::set_SocketImplementation(System.Type)
extern void PhotonPeer_set_SocketImplementation_m289CFBA0718087875BB453C66E3ADDD36757C613 (void);
// 0x0000016B ExitGames.Client.Photon.IPhotonPeerListener ExitGames.Client.Photon.PhotonPeer::get_Listener()
extern void PhotonPeer_get_Listener_m887BECA64658F676E50480D559D3E133A62F159A (void);
// 0x0000016C System.Void ExitGames.Client.Photon.PhotonPeer::set_Listener(ExitGames.Client.Photon.IPhotonPeerListener)
extern void PhotonPeer_set_Listener_m853BE7848FA55AB832A8BAE561EBA746F1E4CA28 (void);
// 0x0000016D System.Void ExitGames.Client.Photon.PhotonPeer::add_OnDisconnectMessage(System.Action`1<ExitGames.Client.Photon.DisconnectMessage>)
extern void PhotonPeer_add_OnDisconnectMessage_m22463EFDD6DA0A060DE27EE4E4D79D2516A77ACE (void);
// 0x0000016E System.Void ExitGames.Client.Photon.PhotonPeer::remove_OnDisconnectMessage(System.Action`1<ExitGames.Client.Photon.DisconnectMessage>)
extern void PhotonPeer_remove_OnDisconnectMessage_mD61C68CAEE2E7C63BF549F818896287AD0DFA749 (void);
// 0x0000016F System.Boolean ExitGames.Client.Photon.PhotonPeer::get_ReuseEventInstance()
extern void PhotonPeer_get_ReuseEventInstance_mC082E5735B38E8287F1CA3303618015F07C8C8B0 (void);
// 0x00000170 System.Void ExitGames.Client.Photon.PhotonPeer::set_ReuseEventInstance(System.Boolean)
extern void PhotonPeer_set_ReuseEventInstance_mC8F8073785CA0C6176F425841B210847B46B0F30 (void);
// 0x00000171 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_UseByteArraySlicePoolForEvents()
extern void PhotonPeer_get_UseByteArraySlicePoolForEvents_mDA3D712BAE30E8C4C348A4299081BA29A63E2240 (void);
// 0x00000172 System.Void ExitGames.Client.Photon.PhotonPeer::set_UseByteArraySlicePoolForEvents(System.Boolean)
extern void PhotonPeer_set_UseByteArraySlicePoolForEvents_m2434369DFFFFC80B9F8265681ED52EF00E5345F9 (void);
// 0x00000173 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_WrapIncomingStructs()
extern void PhotonPeer_get_WrapIncomingStructs_m1B2D926E56FC89C31334BFDEB022C76A2C3E53E6 (void);
// 0x00000174 System.Void ExitGames.Client.Photon.PhotonPeer::set_WrapIncomingStructs(System.Boolean)
extern void PhotonPeer_set_WrapIncomingStructs_mE9E151AFDE44C3B88505BA25DCE1693C77D2FFB5 (void);
// 0x00000175 ExitGames.Client.Photon.ByteArraySlicePool ExitGames.Client.Photon.PhotonPeer::get_ByteArraySlicePool()
extern void PhotonPeer_get_ByteArraySlicePool_mBE19F601AF8244E1B1414FBCD1E032D1EC22C420 (void);
// 0x00000176 System.Int64 ExitGames.Client.Photon.PhotonPeer::get_BytesIn()
extern void PhotonPeer_get_BytesIn_m54215BB6A8B9BD05A38F60ED10EE954F6E32424E (void);
// 0x00000177 System.Int64 ExitGames.Client.Photon.PhotonPeer::get_BytesOut()
extern void PhotonPeer_get_BytesOut_m96964D14F0B1B2CA944C4E5CFBA7EEFBEE3DF26A (void);
// 0x00000178 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_ByteCountCurrentDispatch()
extern void PhotonPeer_get_ByteCountCurrentDispatch_m88E3B1AD5C53FDF1C12C410BFA76965533836F82 (void);
// 0x00000179 System.String ExitGames.Client.Photon.PhotonPeer::get_CommandInfoCurrentDispatch()
extern void PhotonPeer_get_CommandInfoCurrentDispatch_mAB17A3465956B1FAE7EE283B74DBB00A4A1E855E (void);
// 0x0000017A System.Int32 ExitGames.Client.Photon.PhotonPeer::get_ByteCountLastOperation()
extern void PhotonPeer_get_ByteCountLastOperation_mBE8D1B8DD6265682CAE46CAB03B8B47346105E0B (void);
// 0x0000017B System.Boolean ExitGames.Client.Photon.PhotonPeer::get_EnableServerTracing()
extern void PhotonPeer_get_EnableServerTracing_m18A1ACFEA37C05184F857D1C5D87EF05F306A595 (void);
// 0x0000017C System.Void ExitGames.Client.Photon.PhotonPeer::set_EnableServerTracing(System.Boolean)
extern void PhotonPeer_set_EnableServerTracing_m8814641772F47AD400C956A7B223ECD4D9C9F0D9 (void);
// 0x0000017D System.Byte ExitGames.Client.Photon.PhotonPeer::get_QuickResendAttempts()
extern void PhotonPeer_get_QuickResendAttempts_mD01A6A47AFDFA919B74966F65AEB4A6C5288EAED (void);
// 0x0000017E System.Void ExitGames.Client.Photon.PhotonPeer::set_QuickResendAttempts(System.Byte)
extern void PhotonPeer_set_QuickResendAttempts_mF1A6AF63A324442A7D3DDD07794D7071C50E8BDB (void);
// 0x0000017F ExitGames.Client.Photon.PeerStateValue ExitGames.Client.Photon.PhotonPeer::get_PeerState()
extern void PhotonPeer_get_PeerState_m88FD264346AFB1D75762E4B2FF0385258EC3BB99 (void);
// 0x00000180 System.String ExitGames.Client.Photon.PhotonPeer::get_PeerID()
extern void PhotonPeer_get_PeerID_mCFE1D8A04860C907EB895FB4888E2572E6E6FEE8 (void);
// 0x00000181 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_QueuedIncomingCommands()
extern void PhotonPeer_get_QueuedIncomingCommands_m089990B31608CBEA27CA06E1B878D330F0438C98 (void);
// 0x00000182 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_QueuedOutgoingCommands()
extern void PhotonPeer_get_QueuedOutgoingCommands_mDC1937F3C7BD71F911AE6004C275CA8525844FD2 (void);
// 0x00000183 System.Void ExitGames.Client.Photon.PhotonPeer::MessageBufferPoolTrim(System.Int32)
extern void PhotonPeer_MessageBufferPoolTrim_m667A1F4C30747022F01A9165618587BF5A346C36 (void);
// 0x00000184 System.Int32 ExitGames.Client.Photon.PhotonPeer::MessageBufferPoolSize()
extern void PhotonPeer_MessageBufferPoolSize_m2FE0BCC9CA61FCAAAE77C68C4551C8B0F0306E4D (void);
// 0x00000185 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_CrcEnabled()
extern void PhotonPeer_get_CrcEnabled_m9C938E3DD435390BF289EC04C0716D83B8401479 (void);
// 0x00000186 System.Void ExitGames.Client.Photon.PhotonPeer::set_CrcEnabled(System.Boolean)
extern void PhotonPeer_set_CrcEnabled_mC35D5639838B6BBD01803F39752E7B5B193FF861 (void);
// 0x00000187 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_PacketLossByCrc()
extern void PhotonPeer_get_PacketLossByCrc_m1E076970BB46019F6AE17000B94C177028E97010 (void);
// 0x00000188 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_PacketLossByChallenge()
extern void PhotonPeer_get_PacketLossByChallenge_m42310BDC5191DAF7845C0619AE74E2B74132E715 (void);
// 0x00000189 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_SentReliableCommandsCount()
extern void PhotonPeer_get_SentReliableCommandsCount_m465F3D79D36D7F28A68FB0DAECEA35EC1EA26D93 (void);
// 0x0000018A System.Int32 ExitGames.Client.Photon.PhotonPeer::get_ResentReliableCommands()
extern void PhotonPeer_get_ResentReliableCommands_m574A9F8EE1BCF083FDBE81E5160113AC5071DDC9 (void);
// 0x0000018B System.Int32 ExitGames.Client.Photon.PhotonPeer::get_DisconnectTimeout()
extern void PhotonPeer_get_DisconnectTimeout_mA10F0BBD2136B75EADE9844D7A50283D9C84E7CD (void);
// 0x0000018C System.Void ExitGames.Client.Photon.PhotonPeer::set_DisconnectTimeout(System.Int32)
extern void PhotonPeer_set_DisconnectTimeout_m1A09FFC6C6EF02A2D29254CA90752ED94B023FF0 (void);
// 0x0000018D System.Int32 ExitGames.Client.Photon.PhotonPeer::get_ServerTimeInMilliSeconds()
extern void PhotonPeer_get_ServerTimeInMilliSeconds_m48B4E6E2E4A19C14BA99AC57FC04D56CC913A7D8 (void);
// 0x0000018E System.Void ExitGames.Client.Photon.PhotonPeer::set_LocalMsTimestampDelegate(ExitGames.Client.Photon.SupportClass_IntegerMillisecondsDelegate)
extern void PhotonPeer_set_LocalMsTimestampDelegate_m9E33B0166FC28A1F6ACC6D0AFFF8722DC516CEEA (void);
// 0x0000018F System.Int32 ExitGames.Client.Photon.PhotonPeer::get_ConnectionTime()
extern void PhotonPeer_get_ConnectionTime_m9F70BA6979E294FFF1E9FB021F2A7BC06F3A62F1 (void);
// 0x00000190 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_LastSendAckTime()
extern void PhotonPeer_get_LastSendAckTime_m1B0DE46390708644D9D4A7B29D73873A92A9804D (void);
// 0x00000191 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_LastSendOutgoingTime()
extern void PhotonPeer_get_LastSendOutgoingTime_m473D5BD8F686EA19A30140876891DA260453A5A9 (void);
// 0x00000192 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_LongestSentCall()
extern void PhotonPeer_get_LongestSentCall_m6D28545D14718EDBCF8C329AE90C540E3CFFE0EE (void);
// 0x00000193 System.Void ExitGames.Client.Photon.PhotonPeer::set_LongestSentCall(System.Int32)
extern void PhotonPeer_set_LongestSentCall_m031D6BDCA4901F3CA36BFA562D4B1BD82CA90EEC (void);
// 0x00000194 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_RoundTripTime()
extern void PhotonPeer_get_RoundTripTime_m74BE6E225C1F4EAC9F98A479A5283E6F8137E0A5 (void);
// 0x00000195 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_RoundTripTimeVariance()
extern void PhotonPeer_get_RoundTripTimeVariance_m606C1E46FD35CC9BCD3EBD9B4A7DB86578320836 (void);
// 0x00000196 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_LastRoundTripTime()
extern void PhotonPeer_get_LastRoundTripTime_m0C03E59517A6FDA26BD69E7572CED948D0A78114 (void);
// 0x00000197 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_TimestampOfLastSocketReceive()
extern void PhotonPeer_get_TimestampOfLastSocketReceive_m1C0B76D764835D829C8F07FC483DCF9EB79A68D9 (void);
// 0x00000198 System.String ExitGames.Client.Photon.PhotonPeer::get_ServerAddress()
extern void PhotonPeer_get_ServerAddress_mA78ED5E85749B747D7130E710A174555C134C6A3 (void);
// 0x00000199 System.String ExitGames.Client.Photon.PhotonPeer::get_ServerIpAddress()
extern void PhotonPeer_get_ServerIpAddress_m4666717F31CA5968B11172E63A30E0470EC725EA (void);
// 0x0000019A ExitGames.Client.Photon.ConnectionProtocol ExitGames.Client.Photon.PhotonPeer::get_UsedProtocol()
extern void PhotonPeer_get_UsedProtocol_m4686906F6D5052926E68229C645155F0832628F6 (void);
// 0x0000019B ExitGames.Client.Photon.ConnectionProtocol ExitGames.Client.Photon.PhotonPeer::get_TransportProtocol()
extern void PhotonPeer_get_TransportProtocol_m767D7E412A9F27CD9689630891F5506575307C4E (void);
// 0x0000019C System.Void ExitGames.Client.Photon.PhotonPeer::set_TransportProtocol(ExitGames.Client.Photon.ConnectionProtocol)
extern void PhotonPeer_set_TransportProtocol_m80F1A37AC3F8CA8715B4C94B5CCABA6F2212725B (void);
// 0x0000019D System.Boolean ExitGames.Client.Photon.PhotonPeer::get_IsSimulationEnabled()
extern void PhotonPeer_get_IsSimulationEnabled_mD035CB4485897813D96CB3C4C1A84AA483912D20 (void);
// 0x0000019E System.Void ExitGames.Client.Photon.PhotonPeer::set_IsSimulationEnabled(System.Boolean)
extern void PhotonPeer_set_IsSimulationEnabled_m3C059BDECC55B176170F3CD84A76C84A581E5092 (void);
// 0x0000019F ExitGames.Client.Photon.NetworkSimulationSet ExitGames.Client.Photon.PhotonPeer::get_NetworkSimulationSettings()
extern void PhotonPeer_get_NetworkSimulationSettings_m43D3DC8846AC3B792260E24D964156B0CC0830BD (void);
// 0x000001A0 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_MaximumTransferUnit()
extern void PhotonPeer_get_MaximumTransferUnit_m904843DF7767EB6EFE82DEB8DF6116A56D4BD494 (void);
// 0x000001A1 System.Void ExitGames.Client.Photon.PhotonPeer::set_MaximumTransferUnit(System.Int32)
extern void PhotonPeer_set_MaximumTransferUnit_mEE070FE799743B331CA83FCC89AD7380174564DA (void);
// 0x000001A2 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_IsEncryptionAvailable()
extern void PhotonPeer_get_IsEncryptionAvailable_mB1AD5EA055403463741C7B76F387DB022AD8B4A5 (void);
// 0x000001A3 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_IsSendingOnlyAcks()
extern void PhotonPeer_get_IsSendingOnlyAcks_mFA3DB1A7DB77E3E521DE863F8A2270DE8836AD87 (void);
// 0x000001A4 System.Void ExitGames.Client.Photon.PhotonPeer::set_IsSendingOnlyAcks(System.Boolean)
extern void PhotonPeer_set_IsSendingOnlyAcks_m62B51C5659FE0D9DE7A4F9BB487F6A3E320F65CC (void);
// 0x000001A5 ExitGames.Client.Photon.TrafficStats ExitGames.Client.Photon.PhotonPeer::get_TrafficStatsIncoming()
extern void PhotonPeer_get_TrafficStatsIncoming_mB5B5418A73812C70E12DEEFAE8D613B960A609D5 (void);
// 0x000001A6 System.Void ExitGames.Client.Photon.PhotonPeer::set_TrafficStatsIncoming(ExitGames.Client.Photon.TrafficStats)
extern void PhotonPeer_set_TrafficStatsIncoming_mD8B9ED647CA95A2B9466B0D8CD8D8D1A6E17092F (void);
// 0x000001A7 ExitGames.Client.Photon.TrafficStats ExitGames.Client.Photon.PhotonPeer::get_TrafficStatsOutgoing()
extern void PhotonPeer_get_TrafficStatsOutgoing_m39F4B4571628D143BC9DD0C35E51A75A21BD1839 (void);
// 0x000001A8 System.Void ExitGames.Client.Photon.PhotonPeer::set_TrafficStatsOutgoing(ExitGames.Client.Photon.TrafficStats)
extern void PhotonPeer_set_TrafficStatsOutgoing_m0C2F85D63AD3232D4351E0019C87096B93B8927A (void);
// 0x000001A9 ExitGames.Client.Photon.TrafficStatsGameLevel ExitGames.Client.Photon.PhotonPeer::get_TrafficStatsGameLevel()
extern void PhotonPeer_get_TrafficStatsGameLevel_m9D614C0C28437757DD44F328955AC9D91C23BB96 (void);
// 0x000001AA System.Void ExitGames.Client.Photon.PhotonPeer::set_TrafficStatsGameLevel(ExitGames.Client.Photon.TrafficStatsGameLevel)
extern void PhotonPeer_set_TrafficStatsGameLevel_m52E56118408A5F4CB070589626A9F9B44FF4BCC0 (void);
// 0x000001AB System.Int64 ExitGames.Client.Photon.PhotonPeer::get_TrafficStatsElapsedMs()
extern void PhotonPeer_get_TrafficStatsElapsedMs_mA4409826A3847436D7035D66CC25ACF6270E2D58 (void);
// 0x000001AC System.Boolean ExitGames.Client.Photon.PhotonPeer::get_TrafficStatsEnabled()
extern void PhotonPeer_get_TrafficStatsEnabled_mF6968A3F13443FB9D5CAD342375E6DF03C452066 (void);
// 0x000001AD System.Void ExitGames.Client.Photon.PhotonPeer::set_TrafficStatsEnabled(System.Boolean)
extern void PhotonPeer_set_TrafficStatsEnabled_m63D18A4834D74787ACF4C57FCA3B8CA3C74D285E (void);
// 0x000001AE System.Void ExitGames.Client.Photon.PhotonPeer::TrafficStatsReset()
extern void PhotonPeer_TrafficStatsReset_mA2FB3E7703F48B830B7D481A0BD9DC7717F21721 (void);
// 0x000001AF System.Void ExitGames.Client.Photon.PhotonPeer::InitializeTrafficStats()
extern void PhotonPeer_InitializeTrafficStats_m69E72037D3EC9D51588233C148FA0289FFB7302A (void);
// 0x000001B0 System.String ExitGames.Client.Photon.PhotonPeer::VitalStatsToString(System.Boolean)
extern void PhotonPeer_VitalStatsToString_mDF9D5301AB2D91C6CD64AE76B488ADC595EFB518 (void);
// 0x000001B1 System.Type ExitGames.Client.Photon.PhotonPeer::get_EncryptorType()
extern void PhotonPeer_get_EncryptorType_mA75C4423E584B68BAA3B096966E692AA906F14CF (void);
// 0x000001B2 System.Void ExitGames.Client.Photon.PhotonPeer::set_EncryptorType(System.Type)
extern void PhotonPeer_set_EncryptorType_m14753F3B50F3061F071716A0FCBFA3CCB97C6BF8 (void);
// 0x000001B3 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_CountDiscarded()
extern void PhotonPeer_get_CountDiscarded_m30387BE17BD0EAEC093BCC5507F4820FB8FE881B (void);
// 0x000001B4 System.Void ExitGames.Client.Photon.PhotonPeer::set_CountDiscarded(System.Int32)
extern void PhotonPeer_set_CountDiscarded_m4D744BD16E9D4C5D55A2818730734D6385878DB7 (void);
// 0x000001B5 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_DeltaUnreliableNumber()
extern void PhotonPeer_get_DeltaUnreliableNumber_m8BEE3C8070A562FC8D6E8BB20DBB787F67E2A304 (void);
// 0x000001B6 System.Void ExitGames.Client.Photon.PhotonPeer::set_DeltaUnreliableNumber(System.Int32)
extern void PhotonPeer_set_DeltaUnreliableNumber_mC2A0228B74216C80460D3E4960A427D6F2A28EB7 (void);
// 0x000001B7 System.Void ExitGames.Client.Photon.PhotonPeer::.ctor(ExitGames.Client.Photon.ConnectionProtocol)
extern void PhotonPeer__ctor_m38515A3E371289E1132751051AE6236909114FCB (void);
// 0x000001B8 System.Void ExitGames.Client.Photon.PhotonPeer::.ctor(ExitGames.Client.Photon.IPhotonPeerListener,ExitGames.Client.Photon.ConnectionProtocol)
extern void PhotonPeer__ctor_m501CF8AB2D93EA3190BBE0F3DCFCBE5FC7A6AEE3 (void);
// 0x000001B9 System.Boolean ExitGames.Client.Photon.PhotonPeer::Connect(System.String,System.String,System.Object,System.Object)
extern void PhotonPeer_Connect_m72984A500910B5A55D2D54AD87DCB3FA0EAC3F3B (void);
// 0x000001BA System.Boolean ExitGames.Client.Photon.PhotonPeer::Connect(System.String,System.String,System.String,System.Object,System.Object)
extern void PhotonPeer_Connect_mB73B289096309A4E15185A0BE6FEE82A523D39EE (void);
// 0x000001BB System.Void ExitGames.Client.Photon.PhotonPeer::CreatePeerBase()
extern void PhotonPeer_CreatePeerBase_mD24BFF1814A065BBB52D0DD6B373F0D407CEC74B (void);
// 0x000001BC System.Void ExitGames.Client.Photon.PhotonPeer::Disconnect()
extern void PhotonPeer_Disconnect_m863D6F91AEB5E18EB704BC80985B6B9EB5597655 (void);
// 0x000001BD System.Void ExitGames.Client.Photon.PhotonPeer::OnDisconnectMessageCall(ExitGames.Client.Photon.DisconnectMessage)
extern void PhotonPeer_OnDisconnectMessageCall_mCAB30DD61D1D545353ADCEAB2BA3FB3794F060DB (void);
// 0x000001BE System.Void ExitGames.Client.Photon.PhotonPeer::StopThread()
extern void PhotonPeer_StopThread_m07FC3E2D5650A262179C87DD305FF0C56CA31E4C (void);
// 0x000001BF System.Void ExitGames.Client.Photon.PhotonPeer::FetchServerTimestamp()
extern void PhotonPeer_FetchServerTimestamp_mB57D30DE42227BA44DC85C051BA457F16220BB92 (void);
// 0x000001C0 System.Boolean ExitGames.Client.Photon.PhotonPeer::EstablishEncryption()
extern void PhotonPeer_EstablishEncryption_m8635FA2B26F476C22D3152B3734ADE787955AE5B (void);
// 0x000001C1 System.Boolean ExitGames.Client.Photon.PhotonPeer::InitDatagramEncryption(System.Byte[],System.Byte[],System.Boolean,System.Boolean)
extern void PhotonPeer_InitDatagramEncryption_m5763710F8FFE525CFAF94DC71C2EFE1DDAE590DD (void);
// 0x000001C2 System.Void ExitGames.Client.Photon.PhotonPeer::InitPayloadEncryption(System.Byte[])
extern void PhotonPeer_InitPayloadEncryption_m2ABC4A9C97D901C1EC9BBE5157C1200098632B4C (void);
// 0x000001C3 System.Void ExitGames.Client.Photon.PhotonPeer::Service()
extern void PhotonPeer_Service_mCB6FC0D9496BF709A5AFDC2673D9FC50426692FA (void);
// 0x000001C4 System.Boolean ExitGames.Client.Photon.PhotonPeer::SendOutgoingCommands()
extern void PhotonPeer_SendOutgoingCommands_mF3104B861AA48A5A3AB330C5D452C9941856312C (void);
// 0x000001C5 System.Boolean ExitGames.Client.Photon.PhotonPeer::SendAcksOnly()
extern void PhotonPeer_SendAcksOnly_m437CA459431F629F76FBEB7F9ACFEB02674881AC (void);
// 0x000001C6 System.Boolean ExitGames.Client.Photon.PhotonPeer::DispatchIncomingCommands()
extern void PhotonPeer_DispatchIncomingCommands_mCAF078435CB2ECBDD69CC0B45B12DC82E79F4833 (void);
// 0x000001C7 System.Boolean ExitGames.Client.Photon.PhotonPeer::SendOperation(System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,ExitGames.Client.Photon.SendOptions)
extern void PhotonPeer_SendOperation_m871717EC9305F011A482BF52037F44B9FFE230D8 (void);
// 0x000001C8 System.Boolean ExitGames.Client.Photon.PhotonPeer::SendOperation(System.Byte,ExitGames.Client.Photon.ParameterDictionary,ExitGames.Client.Photon.SendOptions)
extern void PhotonPeer_SendOperation_mC22D66512298CF37D07D4BBC86B121D283E89723 (void);
// 0x000001C9 System.Boolean ExitGames.Client.Photon.PhotonPeer::RegisterType(System.Type,System.Byte,ExitGames.Client.Photon.SerializeMethod,ExitGames.Client.Photon.DeserializeMethod)
extern void PhotonPeer_RegisterType_m0B7FF218BB0C55EF27A2A78147C0E9A78940914B (void);
// 0x000001CA System.Boolean ExitGames.Client.Photon.PhotonPeer::RegisterType(System.Type,System.Byte,ExitGames.Client.Photon.SerializeStreamMethod,ExitGames.Client.Photon.DeserializeStreamMethod)
extern void PhotonPeer_RegisterType_m0ECEC15A8AE97F0751B29A791C22897A6ABCBFC0 (void);
// 0x000001CB System.Void ExitGames.Client.Photon.PhotonPeer::.cctor()
extern void PhotonPeer__cctor_mF490B1497039DECE97B95B1A36E0F0DA80586EE5 (void);
// 0x000001CC System.Boolean ExitGames.Client.Photon.PhotonPeer::<EstablishEncryption>b__220_0()
extern void PhotonPeer_U3CEstablishEncryptionU3Eb__220_0_m8A34D437798A9DBACF6FC45B055D8C767760E9E1 (void);
// 0x000001CD System.Void ExitGames.Client.Photon.OperationRequest::.ctor()
extern void OperationRequest__ctor_mA8E4F8C6EE9E0949EB7B02A063DEEFC9DC743B5F (void);
// 0x000001CE System.Object ExitGames.Client.Photon.OperationResponse::get_Item(System.Byte)
extern void OperationResponse_get_Item_m0129E7DF764B87113A443CEA9537478C4040D0BC (void);
// 0x000001CF System.Void ExitGames.Client.Photon.OperationResponse::set_Item(System.Byte,System.Object)
extern void OperationResponse_set_Item_m4493B35BAA19F6A52E70F1F562B42BE8B05C1104 (void);
// 0x000001D0 System.String ExitGames.Client.Photon.OperationResponse::ToString()
extern void OperationResponse_ToString_m284F3715502CE797867432477ED2A6ED201C0752 (void);
// 0x000001D1 System.String ExitGames.Client.Photon.OperationResponse::ToStringFull()
extern void OperationResponse_ToStringFull_m3199D448BDD773C8652EF7E3C9ABF422D33FB5EE (void);
// 0x000001D2 System.Void ExitGames.Client.Photon.OperationResponse::.ctor()
extern void OperationResponse__ctor_mA876E3701ED5CF5428D4379AE3324574508A1DBF (void);
// 0x000001D3 System.Void ExitGames.Client.Photon.DisconnectMessage::.ctor()
extern void DisconnectMessage__ctor_m932DE568123A243B0166705D82CADBBDA7EE4EB6 (void);
// 0x000001D4 System.Void ExitGames.Client.Photon.EventData::.ctor()
extern void EventData__ctor_m972A9C95F3874A0CE1E4204BB92293E60D5C80F0 (void);
// 0x000001D5 System.Object ExitGames.Client.Photon.EventData::get_Item(System.Byte)
extern void EventData_get_Item_m0B6DECAC5E4E913E0B9C2229ABF41797A46E840C (void);
// 0x000001D6 System.Void ExitGames.Client.Photon.EventData::set_Item(System.Byte,System.Object)
extern void EventData_set_Item_mB7DD2CBF2BB7FE9DD04B9FFA9257D3A7BA86EAF3 (void);
// 0x000001D7 System.Int32 ExitGames.Client.Photon.EventData::get_Sender()
extern void EventData_get_Sender_mE0F9AFE67C414CEF769B982C8FA299E0A6C41269 (void);
// 0x000001D8 System.Void ExitGames.Client.Photon.EventData::set_Sender(System.Int32)
extern void EventData_set_Sender_mCB8B03028382D08CF624BF25E66BDB94BD86461B (void);
// 0x000001D9 System.Object ExitGames.Client.Photon.EventData::get_CustomData()
extern void EventData_get_CustomData_m4D0A5928FCF5AB90A20BF79A980C43F88F098434 (void);
// 0x000001DA System.Void ExitGames.Client.Photon.EventData::set_CustomData(System.Object)
extern void EventData_set_CustomData_mDB4DF0DBFBD09830FA509F35E443956A8C2FDC05 (void);
// 0x000001DB System.Void ExitGames.Client.Photon.EventData::Reset()
extern void EventData_Reset_mD146DABD3B11F677BA45689B2B504080BE569DD0 (void);
// 0x000001DC System.String ExitGames.Client.Photon.EventData::ToString()
extern void EventData_ToString_m4A3E644B01E58EC22CFBEFD77027561857595768 (void);
// 0x000001DD System.String ExitGames.Client.Photon.EventData::ToStringFull()
extern void EventData_ToStringFull_m278564F21BDC0596EABB1781F868054261986E52 (void);
// 0x000001DE System.Void ExitGames.Client.Photon.SerializeMethod::.ctor(System.Object,System.IntPtr)
extern void SerializeMethod__ctor_m96BC348674809A197BC5DCC3A9E1E2AADDD39DAD (void);
// 0x000001DF System.Byte[] ExitGames.Client.Photon.SerializeMethod::Invoke(System.Object)
extern void SerializeMethod_Invoke_m2A26A185AE91964A251119037A553C6E86D349E1 (void);
// 0x000001E0 System.IAsyncResult ExitGames.Client.Photon.SerializeMethod::BeginInvoke(System.Object,System.AsyncCallback,System.Object)
extern void SerializeMethod_BeginInvoke_mE0169B293A31A693DD1A04BA4AC4463BA6B3F456 (void);
// 0x000001E1 System.Byte[] ExitGames.Client.Photon.SerializeMethod::EndInvoke(System.IAsyncResult)
extern void SerializeMethod_EndInvoke_mA508A823D40AFEE88169D2A041D5E469F0376842 (void);
// 0x000001E2 System.Void ExitGames.Client.Photon.SerializeStreamMethod::.ctor(System.Object,System.IntPtr)
extern void SerializeStreamMethod__ctor_m5727105B26DE58354DA5B13EFFFD77434B70DEBF (void);
// 0x000001E3 System.Int16 ExitGames.Client.Photon.SerializeStreamMethod::Invoke(ExitGames.Client.Photon.StreamBuffer,System.Object)
extern void SerializeStreamMethod_Invoke_m1D00168E642A230A7E8AAA7DE07ED03B728DC03E (void);
// 0x000001E4 System.IAsyncResult ExitGames.Client.Photon.SerializeStreamMethod::BeginInvoke(ExitGames.Client.Photon.StreamBuffer,System.Object,System.AsyncCallback,System.Object)
extern void SerializeStreamMethod_BeginInvoke_mE43378F00EDD1F95520418F6F614EBE8669AFD72 (void);
// 0x000001E5 System.Int16 ExitGames.Client.Photon.SerializeStreamMethod::EndInvoke(System.IAsyncResult)
extern void SerializeStreamMethod_EndInvoke_mDCB34CA93CA5719CBF7719762984A18C088FC26B (void);
// 0x000001E6 System.Void ExitGames.Client.Photon.DeserializeMethod::.ctor(System.Object,System.IntPtr)
extern void DeserializeMethod__ctor_m3AC517B570D77033065EF138A30672CC1C9DB9C0 (void);
// 0x000001E7 System.Object ExitGames.Client.Photon.DeserializeMethod::Invoke(System.Byte[])
extern void DeserializeMethod_Invoke_mCC5F7D5A8C00B74D8217C86B2A0BF85430F3A791 (void);
// 0x000001E8 System.IAsyncResult ExitGames.Client.Photon.DeserializeMethod::BeginInvoke(System.Byte[],System.AsyncCallback,System.Object)
extern void DeserializeMethod_BeginInvoke_m0C5601E36806A7835A92D1F6ECAF2F65FE318E2E (void);
// 0x000001E9 System.Object ExitGames.Client.Photon.DeserializeMethod::EndInvoke(System.IAsyncResult)
extern void DeserializeMethod_EndInvoke_m8C7E512975D5D4792185F217E22B9DA9C495A392 (void);
// 0x000001EA System.Void ExitGames.Client.Photon.DeserializeStreamMethod::.ctor(System.Object,System.IntPtr)
extern void DeserializeStreamMethod__ctor_mF8F3783D7EF3114059BDF53CFB0238559135E346 (void);
// 0x000001EB System.Object ExitGames.Client.Photon.DeserializeStreamMethod::Invoke(ExitGames.Client.Photon.StreamBuffer,System.Int16)
extern void DeserializeStreamMethod_Invoke_m7D9A79222D4C7287C6ACB335B49FE7D3A4273E46 (void);
// 0x000001EC System.IAsyncResult ExitGames.Client.Photon.DeserializeStreamMethod::BeginInvoke(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.AsyncCallback,System.Object)
extern void DeserializeStreamMethod_BeginInvoke_mA8C68FFD6586822857072182430A4542992DF27A (void);
// 0x000001ED System.Object ExitGames.Client.Photon.DeserializeStreamMethod::EndInvoke(System.IAsyncResult)
extern void DeserializeStreamMethod_EndInvoke_m201B80499B982FC2EC4B0E5C398ACA06FA083A4F (void);
// 0x000001EE System.Void ExitGames.Client.Photon.CustomType::.ctor(System.Type,System.Byte,ExitGames.Client.Photon.SerializeMethod,ExitGames.Client.Photon.DeserializeMethod)
extern void CustomType__ctor_m60AF973AEEA38FF2983E72D442F949E65F8AA753 (void);
// 0x000001EF System.Void ExitGames.Client.Photon.CustomType::.ctor(System.Type,System.Byte,ExitGames.Client.Photon.SerializeStreamMethod,ExitGames.Client.Photon.DeserializeStreamMethod)
extern void CustomType__ctor_mEFCC4B2772EF2D0C48881A5EEABE73BAE70A92A3 (void);
// 0x000001F0 System.Boolean ExitGames.Client.Photon.Protocol::TryRegisterType(System.Type,System.Byte,ExitGames.Client.Photon.SerializeMethod,ExitGames.Client.Photon.DeserializeMethod)
extern void Protocol_TryRegisterType_m8255302EEB4258D52247EB1755C185BDE7289DEB (void);
// 0x000001F1 System.Boolean ExitGames.Client.Photon.Protocol::TryRegisterType(System.Type,System.Byte,ExitGames.Client.Photon.SerializeStreamMethod,ExitGames.Client.Photon.DeserializeStreamMethod)
extern void Protocol_TryRegisterType_m5CF4AC809FD0A168658B1625675354A504BFB55D (void);
// 0x000001F2 System.Byte[] ExitGames.Client.Photon.Protocol::Serialize(System.Object)
extern void Protocol_Serialize_m06033A4D0AD53A023906C528FC0E9D4103847509 (void);
// 0x000001F3 System.Object ExitGames.Client.Photon.Protocol::Deserialize(System.Byte[])
extern void Protocol_Deserialize_m412DA38040DEF51F1DA42B804936ABAF254A8BB0 (void);
// 0x000001F4 System.Void ExitGames.Client.Photon.Protocol::Serialize(System.Int16,System.Byte[],System.Int32&)
extern void Protocol_Serialize_mD54B54F99D80A391A02160F4F949A3561C236F82 (void);
// 0x000001F5 System.Void ExitGames.Client.Photon.Protocol::Serialize(System.Int32,System.Byte[],System.Int32&)
extern void Protocol_Serialize_m27E2692AE673B1810ACA6011A7F861A0E18F6D81 (void);
// 0x000001F6 System.Void ExitGames.Client.Photon.Protocol::Serialize(System.Single,System.Byte[],System.Int32&)
extern void Protocol_Serialize_mFA5F2139A75516B7B781ADCB40B7FC766857DD99 (void);
// 0x000001F7 System.Void ExitGames.Client.Photon.Protocol::Deserialize(System.Int32&,System.Byte[],System.Int32&)
extern void Protocol_Deserialize_m1C09A03E55AF5D8C561DBC47B4CCA6773101A705 (void);
// 0x000001F8 System.Void ExitGames.Client.Photon.Protocol::Deserialize(System.Int16&,System.Byte[],System.Int32&)
extern void Protocol_Deserialize_m180D4E319855AAE9AB99769218D4E1ACD84B9EEB (void);
// 0x000001F9 System.Void ExitGames.Client.Photon.Protocol::Deserialize(System.Single&,System.Byte[],System.Int32&)
extern void Protocol_Deserialize_m6E12343C3EF275E24F20CF6F143DE1247B29C87C (void);
// 0x000001FA System.Void ExitGames.Client.Photon.Protocol::.ctor()
extern void Protocol__ctor_m1BDA97874B5B4F9F9376F49C305A08A70237BB91 (void);
// 0x000001FB System.Void ExitGames.Client.Photon.Protocol::.cctor()
extern void Protocol__cctor_m9E76C52B6F18ADC90B79BDE7DBF72222D58CE223 (void);
// 0x000001FC System.String ExitGames.Client.Photon.Protocol16::get_ProtocolType()
extern void Protocol16_get_ProtocolType_mD438E25ABC22D7CCD6398905557EE6CEE92E695A (void);
// 0x000001FD System.Byte[] ExitGames.Client.Photon.Protocol16::get_VersionBytes()
extern void Protocol16_get_VersionBytes_m98E3ACB96E587331D35A63A5E69AE88F11A55978 (void);
// 0x000001FE System.Boolean ExitGames.Client.Photon.Protocol16::SerializeCustom(ExitGames.Client.Photon.StreamBuffer,System.Object)
extern void Protocol16_SerializeCustom_m59CD45B021D66B0DA6C505067C8BE4918A949880 (void);
// 0x000001FF System.Object ExitGames.Client.Photon.Protocol16::DeserializeCustom(ExitGames.Client.Photon.StreamBuffer,System.Byte,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol16_DeserializeCustom_m0863DEB302D41DC1E2ADA0D2EB34865746117A21 (void);
// 0x00000200 System.Type ExitGames.Client.Photon.Protocol16::GetTypeOfCode(System.Byte)
extern void Protocol16_GetTypeOfCode_mDE3A7EBBBA57480E19546202FE8547609FA4A3A7 (void);
// 0x00000201 ExitGames.Client.Photon.Protocol16_GpType ExitGames.Client.Photon.Protocol16::GetCodeOfType(System.Type)
extern void Protocol16_GetCodeOfType_mA89A00BB10307CEC476076FBDE2A382B2DD5878E (void);
// 0x00000202 System.Array ExitGames.Client.Photon.Protocol16::CreateArrayByType(System.Byte,System.Int16)
extern void Protocol16_CreateArrayByType_mC615C831BF33993E8C671C20DB773E7BDD6F5640 (void);
// 0x00000203 System.Void ExitGames.Client.Photon.Protocol16::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.OperationRequest,System.Boolean)
extern void Protocol16_SerializeOperationRequest_mC4522D1203BE1CFDD78207CADC978CAC5745EAF4 (void);
// 0x00000204 System.Void ExitGames.Client.Photon.Protocol16::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,System.Boolean)
extern void Protocol16_SerializeOperationRequest_mBA7C02DD74F7B9BEEAFD8E50F012644C25911482 (void);
// 0x00000205 System.Void ExitGames.Client.Photon.Protocol16::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,System.Byte,ExitGames.Client.Photon.ParameterDictionary,System.Boolean)
extern void Protocol16_SerializeOperationRequest_m2A78110D8E406A66882FEAA9D14098992599BA29 (void);
// 0x00000206 ExitGames.Client.Photon.OperationRequest ExitGames.Client.Photon.Protocol16::DeserializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol16_DeserializeOperationRequest_m924BAAB16BB4B0F16E6E4B1C1B218FD1E30E9A3C (void);
// 0x00000207 System.Void ExitGames.Client.Photon.Protocol16::SerializeOperationResponse(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.OperationResponse,System.Boolean)
extern void Protocol16_SerializeOperationResponse_mC49488819DCF7F9561C2F044183B2BDBF812DAB9 (void);
// 0x00000208 ExitGames.Client.Photon.DisconnectMessage ExitGames.Client.Photon.Protocol16::DeserializeDisconnectMessage(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeDisconnectMessage_m8DF5E920924E7EE4BE3A47C132B6F542AF188C4A (void);
// 0x00000209 ExitGames.Client.Photon.OperationResponse ExitGames.Client.Photon.Protocol16::DeserializeOperationResponse(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol16_DeserializeOperationResponse_m2291F3A386E136CCD0000D7D74FEED2F131117F0 (void);
// 0x0000020A System.Void ExitGames.Client.Photon.Protocol16::SerializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData,System.Boolean)
extern void Protocol16_SerializeEventData_m521DC5143BB32874492CB70BEC576AE4E67777DE (void);
// 0x0000020B ExitGames.Client.Photon.EventData ExitGames.Client.Photon.Protocol16::DeserializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol16_DeserializeEventData_mE2D54E13A0011EF5F6BE72BA0DA6A6B65493C250 (void);
// 0x0000020C System.Void ExitGames.Client.Photon.Protocol16::SerializeParameterTable(ExitGames.Client.Photon.StreamBuffer,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>)
extern void Protocol16_SerializeParameterTable_m8F32540D8293403C4249222538C87205957A3F4C (void);
// 0x0000020D System.Void ExitGames.Client.Photon.Protocol16::SerializeParameterTable(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol16_SerializeParameterTable_mDC5182DDFAACD02BCBB8F133A025D7C38C6F0F16 (void);
// 0x0000020E System.Collections.Generic.Dictionary`2<System.Byte,System.Object> ExitGames.Client.Photon.Protocol16::DeserializeParameterTable(ExitGames.Client.Photon.StreamBuffer,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>)
extern void Protocol16_DeserializeParameterTable_mC8CF132C52541033797C333ED3F3B765F587FA9A (void);
// 0x0000020F ExitGames.Client.Photon.ParameterDictionary ExitGames.Client.Photon.Protocol16::DeserializeParameterDictionary(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.ParameterDictionary,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol16_DeserializeParameterDictionary_m902A290589C30ED34686607E23E1AE83CABB6347 (void);
// 0x00000210 System.Void ExitGames.Client.Photon.Protocol16::Serialize(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol16_Serialize_m54D16B40372962422496A7E8BCB70F83D1AA0539 (void);
// 0x00000211 System.Void ExitGames.Client.Photon.Protocol16::SerializeByte(ExitGames.Client.Photon.StreamBuffer,System.Byte,System.Boolean)
extern void Protocol16_SerializeByte_m434EA5ECDB0B1DF13628D48C2B6A22451835F318 (void);
// 0x00000212 System.Void ExitGames.Client.Photon.Protocol16::SerializeBoolean(ExitGames.Client.Photon.StreamBuffer,System.Boolean,System.Boolean)
extern void Protocol16_SerializeBoolean_m1140814EB4953795837AC31A4F3F1685FC85D1FC (void);
// 0x00000213 System.Void ExitGames.Client.Photon.Protocol16::SerializeShort(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.Boolean)
extern void Protocol16_SerializeShort_mE31C720721710309730D86CF5FEE1830CD142796 (void);
// 0x00000214 System.Void ExitGames.Client.Photon.Protocol16::SerializeInteger(ExitGames.Client.Photon.StreamBuffer,System.Int32,System.Boolean)
extern void Protocol16_SerializeInteger_m623B201CFF5EFF4C37E384DB94A4885FF65C126D (void);
// 0x00000215 System.Void ExitGames.Client.Photon.Protocol16::SerializeLong(ExitGames.Client.Photon.StreamBuffer,System.Int64,System.Boolean)
extern void Protocol16_SerializeLong_m71359451ACA304469F78C6482A1DB51DAB9C95B7 (void);
// 0x00000216 System.Void ExitGames.Client.Photon.Protocol16::SerializeFloat(ExitGames.Client.Photon.StreamBuffer,System.Single,System.Boolean)
extern void Protocol16_SerializeFloat_mCCC5EA6FF0A9EA140012E68F2DAD366CE9064C12 (void);
// 0x00000217 System.Void ExitGames.Client.Photon.Protocol16::SerializeDouble(ExitGames.Client.Photon.StreamBuffer,System.Double,System.Boolean)
extern void Protocol16_SerializeDouble_m80642E2CF99AF881673A9806A9ED6EC0D47ADF45 (void);
// 0x00000218 System.Void ExitGames.Client.Photon.Protocol16::SerializeString(ExitGames.Client.Photon.StreamBuffer,System.String,System.Boolean)
extern void Protocol16_SerializeString_m49FFBEF21BB10ED64CF2392C27FA14BFEA4268BB (void);
// 0x00000219 System.Void ExitGames.Client.Photon.Protocol16::SerializeArray(ExitGames.Client.Photon.StreamBuffer,System.Array,System.Boolean)
extern void Protocol16_SerializeArray_m931FF4BCAA5EF5DEAE745D432B9F298B7BDBD538 (void);
// 0x0000021A System.Void ExitGames.Client.Photon.Protocol16::SerializeByteArray(ExitGames.Client.Photon.StreamBuffer,System.Byte[],System.Boolean)
extern void Protocol16_SerializeByteArray_mBD537757E9CA7298E466CABA9DA6BB4F3A671414 (void);
// 0x0000021B System.Void ExitGames.Client.Photon.Protocol16::SerializeByteArraySegment(ExitGames.Client.Photon.StreamBuffer,System.Byte[],System.Int32,System.Int32,System.Boolean)
extern void Protocol16_SerializeByteArraySegment_m8AD08CE6CBCB253BDF43966A22FCB2A91D7EFCF0 (void);
// 0x0000021C System.Void ExitGames.Client.Photon.Protocol16::SerializeIntArrayOptimized(ExitGames.Client.Photon.StreamBuffer,System.Int32[],System.Boolean)
extern void Protocol16_SerializeIntArrayOptimized_m51242157A146677E03A6AA59DB71793D97FF47F8 (void);
// 0x0000021D System.Void ExitGames.Client.Photon.Protocol16::SerializeStringArray(ExitGames.Client.Photon.StreamBuffer,System.String[],System.Boolean)
extern void Protocol16_SerializeStringArray_m300DB80F6FC47106DDBB4B8A1881F1685350D324 (void);
// 0x0000021E System.Void ExitGames.Client.Photon.Protocol16::SerializeObjectArray(ExitGames.Client.Photon.StreamBuffer,System.Collections.IList,System.Boolean)
extern void Protocol16_SerializeObjectArray_mB659BA13D94C160C51270854A5222AE186AA310B (void);
// 0x0000021F System.Void ExitGames.Client.Photon.Protocol16::SerializeHashTable(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.Hashtable,System.Boolean)
extern void Protocol16_SerializeHashTable_m250CE58BF19D2FFFA9DB89AC054FB87796FB5E93 (void);
// 0x00000220 System.Void ExitGames.Client.Photon.Protocol16::SerializeDictionary(ExitGames.Client.Photon.StreamBuffer,System.Collections.IDictionary,System.Boolean)
extern void Protocol16_SerializeDictionary_mEA0C5D5C9576DAAD2EDB370CE474EB3A6C788451 (void);
// 0x00000221 System.Void ExitGames.Client.Photon.Protocol16::SerializeDictionaryHeader(ExitGames.Client.Photon.StreamBuffer,System.Type)
extern void Protocol16_SerializeDictionaryHeader_mAC60D2188B6AFB7373F2C2EE3FB4F678DB95CE5F (void);
// 0x00000222 System.Void ExitGames.Client.Photon.Protocol16::SerializeDictionaryHeader(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean&,System.Boolean&)
extern void Protocol16_SerializeDictionaryHeader_mEADDFC9231764982EB25F869811FE7350CA697CD (void);
// 0x00000223 System.Void ExitGames.Client.Photon.Protocol16::SerializeDictionaryElements(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean,System.Boolean)
extern void Protocol16_SerializeDictionaryElements_m627241133D5F77E2B09C8ABF2BC36E27AB55BCFB (void);
// 0x00000224 System.Object ExitGames.Client.Photon.Protocol16::Deserialize(ExitGames.Client.Photon.StreamBuffer,System.Byte,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol16_Deserialize_m2E78539B08BE2D296D1D90AE0039F6FD9BCDE55C (void);
// 0x00000225 System.Byte ExitGames.Client.Photon.Protocol16::DeserializeByte(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeByte_m27500E61762018A0E4C4DE3209EC20AF16DFACC8 (void);
// 0x00000226 System.Boolean ExitGames.Client.Photon.Protocol16::DeserializeBoolean(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeBoolean_mA0D0A5693A755401ED13C214773D9F3830FBA5FE (void);
// 0x00000227 System.Int16 ExitGames.Client.Photon.Protocol16::DeserializeShort(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeShort_mF7485DFE5051F4CE47BE6E68ADB54B006B38403D (void);
// 0x00000228 System.Int32 ExitGames.Client.Photon.Protocol16::DeserializeInteger(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeInteger_m1F49250A65209E8ED50E2DA29049213918BE3D92 (void);
// 0x00000229 System.Int64 ExitGames.Client.Photon.Protocol16::DeserializeLong(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeLong_m86327A051C9C1FD8AEE2E9FE7248B5A48D598A2B (void);
// 0x0000022A System.Single ExitGames.Client.Photon.Protocol16::DeserializeFloat(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeFloat_m4B62FF8C63207DF266B930303941CACEF80D4588 (void);
// 0x0000022B System.Double ExitGames.Client.Photon.Protocol16::DeserializeDouble(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeDouble_mE37562ABE997B47A4BC42F2A24F75069E9C16B02 (void);
// 0x0000022C System.String ExitGames.Client.Photon.Protocol16::DeserializeString(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeString_m5B7220E906B4A65B1E35C4480DAECCF7A604B528 (void);
// 0x0000022D System.Array ExitGames.Client.Photon.Protocol16::DeserializeArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeArray_m638BA0C8F43F015F3354376CDAD2764149EB3FFA (void);
// 0x0000022E System.Byte[] ExitGames.Client.Photon.Protocol16::DeserializeByteArray(ExitGames.Client.Photon.StreamBuffer,System.Int32)
extern void Protocol16_DeserializeByteArray_mA96762CDD41EB483194826E629F6A35552A161D4 (void);
// 0x0000022F System.Int32[] ExitGames.Client.Photon.Protocol16::DeserializeIntArray(ExitGames.Client.Photon.StreamBuffer,System.Int32)
extern void Protocol16_DeserializeIntArray_mF2C069FDFD1156FB08648ECE379EFC7DF282906C (void);
// 0x00000230 System.String[] ExitGames.Client.Photon.Protocol16::DeserializeStringArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeStringArray_mF0A18AAFDD22DE57017DF9394FCCA7E89B000CB7 (void);
// 0x00000231 System.Object[] ExitGames.Client.Photon.Protocol16::DeserializeObjectArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeObjectArray_mCF37B12D9B5D4301268503BBCA9A460241D0F25C (void);
// 0x00000232 ExitGames.Client.Photon.Hashtable ExitGames.Client.Photon.Protocol16::DeserializeHashTable(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeHashTable_m988DBD14203EE4D91E2B82EB8EC54D42DDA1BA1F (void);
// 0x00000233 System.Collections.IDictionary ExitGames.Client.Photon.Protocol16::DeserializeDictionary(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeDictionary_m2F102FA2CF9D1AB02A26AE1EBDA87A38DFE9B527 (void);
// 0x00000234 System.Boolean ExitGames.Client.Photon.Protocol16::DeserializeDictionaryArray(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.Array&)
extern void Protocol16_DeserializeDictionaryArray_m76C13696C0B2A0ED3B0F52D661AD7DE7FF18E47B (void);
// 0x00000235 System.Type ExitGames.Client.Photon.Protocol16::DeserializeDictionaryType(ExitGames.Client.Photon.StreamBuffer,System.Byte&,System.Byte&)
extern void Protocol16_DeserializeDictionaryType_m1F020B4D887856178943BC3A5A0578DE6C0A64E6 (void);
// 0x00000236 System.Void ExitGames.Client.Photon.Protocol16::.ctor()
extern void Protocol16__ctor_mF057AE2E519093202ECCD64863A2F96C33512E31 (void);
// 0x00000237 System.Void ExitGames.Client.Photon.Protocol16::.cctor()
extern void Protocol16__cctor_m9BC5BE7AB1F93F8986DB505F874FE349EA15D934 (void);
// 0x00000238 System.Void ExitGames.Client.Photon.InvalidDataException::.ctor(System.String)
extern void InvalidDataException__ctor_mF58EF21176D7A7967191E8366FE029F70E3DBAD2 (void);
// 0x00000239 System.String ExitGames.Client.Photon.Protocol18::get_ProtocolType()
extern void Protocol18_get_ProtocolType_m4D601C5463B6E966798714B2948D3BB9D914388B (void);
// 0x0000023A System.Byte[] ExitGames.Client.Photon.Protocol18::get_VersionBytes()
extern void Protocol18_get_VersionBytes_m8992AF836BA06DAEB5A8F776307F3B5B56278F5E (void);
// 0x0000023B System.Void ExitGames.Client.Photon.Protocol18::Serialize(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_Serialize_m5AF3A118526180C5F9C5C50BE01EF978C6A4115E (void);
// 0x0000023C System.Void ExitGames.Client.Photon.Protocol18::SerializeShort(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.Boolean)
extern void Protocol18_SerializeShort_m8BF8D507CB1F281274D3AB12FCF005F0CF2A7C06 (void);
// 0x0000023D System.Void ExitGames.Client.Photon.Protocol18::SerializeString(ExitGames.Client.Photon.StreamBuffer,System.String,System.Boolean)
extern void Protocol18_SerializeString_m069E84195462BC9030B57051D2C6FB73816A5B09 (void);
// 0x0000023E System.Object ExitGames.Client.Photon.Protocol18::Deserialize(ExitGames.Client.Photon.StreamBuffer,System.Byte,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol18_Deserialize_mD50E46C3EF112ECE195E4A55155E5432CAC0C676 (void);
// 0x0000023F System.Int16 ExitGames.Client.Photon.Protocol18::DeserializeShort(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_DeserializeShort_m1CE243C8558F696882534D918E9F1A6DB9BF79FE (void);
// 0x00000240 System.Byte ExitGames.Client.Photon.Protocol18::DeserializeByte(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_DeserializeByte_mDD6E9495D4D5310716C01A37AA17900D76960F47 (void);
// 0x00000241 System.Type ExitGames.Client.Photon.Protocol18::GetAllowedDictionaryKeyTypes(ExitGames.Client.Photon.Protocol18_GpType)
extern void Protocol18_GetAllowedDictionaryKeyTypes_m35B12853C4567346FA295DFD4189066959F65815 (void);
// 0x00000242 System.Type ExitGames.Client.Photon.Protocol18::GetClrArrayType(ExitGames.Client.Photon.Protocol18_GpType)
extern void Protocol18_GetClrArrayType_mEF02327BD24D846456DF3C6C47705189BC651EEA (void);
// 0x00000243 ExitGames.Client.Photon.Protocol18_GpType ExitGames.Client.Photon.Protocol18::GetCodeOfType(System.Type)
extern void Protocol18_GetCodeOfType_m79E179F34BC05A60F7F2274BEF54148302B259DC (void);
// 0x00000244 ExitGames.Client.Photon.Protocol18_GpType ExitGames.Client.Photon.Protocol18::GetCodeOfTypeCode(System.TypeCode)
extern void Protocol18_GetCodeOfTypeCode_mEF6F68A3D06CF32A1BD4E51879811F7ECAE45E36 (void);
// 0x00000245 System.Object ExitGames.Client.Photon.Protocol18::Read(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_Read_m2F993F195161CA6803C2FF392B28DA2DCD808815 (void);
// 0x00000246 System.Object ExitGames.Client.Photon.Protocol18::Read(ExitGames.Client.Photon.StreamBuffer,System.Byte,ExitGames.Client.Photon.IProtocol_DeserializationFlags,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_Read_m09D79564B117D8678ED56EBBF67A74AA12B9FC21 (void);
// 0x00000247 System.Boolean ExitGames.Client.Photon.Protocol18::ReadBoolean(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadBoolean_mD3E77C1567BD5440F4DCEC4BA66E81C445CE5946 (void);
// 0x00000248 System.Byte ExitGames.Client.Photon.Protocol18::ReadByte(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadByte_m3A2E41414A3B9ED13C2564B0EFD354E974E9CB22 (void);
// 0x00000249 System.Int16 ExitGames.Client.Photon.Protocol18::ReadInt16(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadInt16_m3C680275F34C6574C58FAEA4EA384E8970377712 (void);
// 0x0000024A System.UInt16 ExitGames.Client.Photon.Protocol18::ReadUShort(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadUShort_m442DA2616C8CF5CD7126F272B68A78EF9055DAD1 (void);
// 0x0000024B System.Int32 ExitGames.Client.Photon.Protocol18::ReadInt32(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadInt32_mD59026398ECCBDC0381CD69E2E866BFF107E20D8 (void);
// 0x0000024C System.Int64 ExitGames.Client.Photon.Protocol18::ReadInt64(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadInt64_mE8888751930F29535356F853B7B694694DA43A5E (void);
// 0x0000024D System.Single ExitGames.Client.Photon.Protocol18::ReadSingle(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadSingle_m98136AC94743FA6E6F06CF87895B1CB5714582BE (void);
// 0x0000024E System.Double ExitGames.Client.Photon.Protocol18::ReadDouble(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadDouble_mE5B8E203EA512CD77A32E73D3FF4C4D044E48B07 (void);
// 0x0000024F ExitGames.Client.Photon.ByteArraySlice ExitGames.Client.Photon.Protocol18::ReadNonAllocByteArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadNonAllocByteArray_mCDCA9986C4D5C495E6E4106A8BF3ED1DE34ED5BA (void);
// 0x00000250 System.Byte[] ExitGames.Client.Photon.Protocol18::ReadByteArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadByteArray_m64888E3710D21110F53B0877F3CF873CB22EFDA1 (void);
// 0x00000251 System.Object ExitGames.Client.Photon.Protocol18::ReadCustomType(ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void Protocol18_ReadCustomType_mD210A247BE40D402B9994FCF2FDAA814EB3A6F81 (void);
// 0x00000252 ExitGames.Client.Photon.EventData ExitGames.Client.Photon.Protocol18::DeserializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol18_DeserializeEventData_m8D4FB7860B3E1C053D76078603A00FF1BC053950 (void);
// 0x00000253 System.Collections.Generic.Dictionary`2<System.Byte,System.Object> ExitGames.Client.Photon.Protocol18::ReadParameterTable(ExitGames.Client.Photon.StreamBuffer,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol18_ReadParameterTable_m79A00541CCAFBFF89C4D823801A21A026A901992 (void);
// 0x00000254 ExitGames.Client.Photon.ParameterDictionary ExitGames.Client.Photon.Protocol18::ReadParameterDictionary(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.ParameterDictionary,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol18_ReadParameterDictionary_m619A90D8D1E6CEC2A7686B51A3F0F501F3ACBD49 (void);
// 0x00000255 ExitGames.Client.Photon.Hashtable ExitGames.Client.Photon.Protocol18::ReadHashtable(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_ReadHashtable_mB22E5871CC37A9C75927379BA2F5B70C87E586D9 (void);
// 0x00000256 System.Int32[] ExitGames.Client.Photon.Protocol18::ReadIntArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadIntArray_m3B343CF26249C5AAC197242D06CE39A3C4CCE60C (void);
// 0x00000257 ExitGames.Client.Photon.OperationRequest ExitGames.Client.Photon.Protocol18::DeserializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol18_DeserializeOperationRequest_mBA04093A752535C776B38203F40F69B3033711E0 (void);
// 0x00000258 ExitGames.Client.Photon.OperationResponse ExitGames.Client.Photon.Protocol18::DeserializeOperationResponse(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags)
extern void Protocol18_DeserializeOperationResponse_m33E867327C730F3E0FC4DCC21CE33B3B3267C0B5 (void);
// 0x00000259 ExitGames.Client.Photon.DisconnectMessage ExitGames.Client.Photon.Protocol18::DeserializeDisconnectMessage(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_DeserializeDisconnectMessage_mFCFB449842D41FC5AF013ABE5C97768CFD0FA47A (void);
// 0x0000025A System.String ExitGames.Client.Photon.Protocol18::ReadString(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadString_mF16FE2D7A57FF2E8FACE33944A86162C07D47BC4 (void);
// 0x0000025B System.Object ExitGames.Client.Photon.Protocol18::ReadCustomTypeArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCustomTypeArray_m71E3645610B21DB7CBC4BE5122C18912B1D61689 (void);
// 0x0000025C System.Type ExitGames.Client.Photon.Protocol18::ReadDictionaryType(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.Protocol18_GpType&,ExitGames.Client.Photon.Protocol18_GpType&)
extern void Protocol18_ReadDictionaryType_m6FCAA15F2B9F0D9E24C077623085A38EF0B5609A (void);
// 0x0000025D System.Type ExitGames.Client.Photon.Protocol18::ReadDictionaryType(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadDictionaryType_mA179C7203D3C62DD25AD6292E95DC89F20773BDF (void);
// 0x0000025E System.Type ExitGames.Client.Photon.Protocol18::GetDictArrayType(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_GetDictArrayType_mA1E792172A5B4C5BCFCF1E19BD9CF5F459F659AF (void);
// 0x0000025F System.Collections.IDictionary ExitGames.Client.Photon.Protocol18::ReadDictionary(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_ReadDictionary_m92ED8996EE2C263227200362C8DCE6336C823908 (void);
// 0x00000260 System.Boolean ExitGames.Client.Photon.Protocol18::ReadDictionaryElements(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.Protocol18_GpType,ExitGames.Client.Photon.Protocol18_GpType,System.Collections.IDictionary,ExitGames.Client.Photon.IProtocol_DeserializationFlags,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_ReadDictionaryElements_mBCE55F96C3A41A5A409B09BAD6FB5D8B4F4A48CC (void);
// 0x00000261 System.Object[] ExitGames.Client.Photon.Protocol18::ReadObjectArray(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_ReadObjectArray_m0DDD95C4C4B317C5D9A314E2D59F429D59BB4BCD (void);
// 0x00000262 ExitGames.Client.Photon.StructWrapping.StructWrapper[] ExitGames.Client.Photon.Protocol18::ReadWrapperArray(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_ReadWrapperArray_mF5B843E73615653074CE2CDFF0E9105210D32A0A (void);
// 0x00000263 System.Boolean[] ExitGames.Client.Photon.Protocol18::ReadBooleanArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadBooleanArray_m85A0489F16D59CB193CD4205202C02A3739F0515 (void);
// 0x00000264 System.Int16[] ExitGames.Client.Photon.Protocol18::ReadInt16Array(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadInt16Array_m4F058F1C87B5C1839E3EAA792A73908F9960078A (void);
// 0x00000265 System.Single[] ExitGames.Client.Photon.Protocol18::ReadSingleArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadSingleArray_m7FE62D3211B463F5BAD4FA36536D528BB0E8442D (void);
// 0x00000266 System.Double[] ExitGames.Client.Photon.Protocol18::ReadDoubleArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadDoubleArray_m02E56ECD6DC63074A58A5D2813E0C6BF263C4EAD (void);
// 0x00000267 System.String[] ExitGames.Client.Photon.Protocol18::ReadStringArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadStringArray_m2B5C1B56BEA5EE25F1484933456AA525402E404C (void);
// 0x00000268 ExitGames.Client.Photon.Hashtable[] ExitGames.Client.Photon.Protocol18::ReadHashtableArray(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_ReadHashtableArray_mE30AFB6D375CB558D164AD759C55B4F2221E4826 (void);
// 0x00000269 System.Collections.IDictionary[] ExitGames.Client.Photon.Protocol18::ReadDictionaryArray(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_ReadDictionaryArray_m3B2B76720AD64D1645AF5E1B63280C65E391AF79 (void);
// 0x0000026A System.Array ExitGames.Client.Photon.Protocol18::ReadArrayInArray(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.IProtocol_DeserializationFlags,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_ReadArrayInArray_m9753F27A394BDBF161952EFCC3A0A5F64144D64C (void);
// 0x0000026B System.Int32 ExitGames.Client.Photon.Protocol18::ReadInt1(ExitGames.Client.Photon.StreamBuffer,System.Boolean)
extern void Protocol18_ReadInt1_m365F861F96014A7393AAD7CEA5E3EF95D7008A01 (void);
// 0x0000026C System.Int32 ExitGames.Client.Photon.Protocol18::ReadInt2(ExitGames.Client.Photon.StreamBuffer,System.Boolean)
extern void Protocol18_ReadInt2_mD7790185AA89E4C3D67F6392F738A5D9B26A322C (void);
// 0x0000026D System.Int32 ExitGames.Client.Photon.Protocol18::ReadCompressedInt32(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedInt32_mD1EB2A16A7217DFEDCF16DF30DF8DCFD1A7992DA (void);
// 0x0000026E System.UInt32 ExitGames.Client.Photon.Protocol18::ReadCompressedUInt32(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedUInt32_m17057086842E42718F09DA3A903D63750F87A50F (void);
// 0x0000026F System.Int64 ExitGames.Client.Photon.Protocol18::ReadCompressedInt64(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedInt64_m2FFF6CFFE5CD1544683E0BF78DAE87CE75F6767C (void);
// 0x00000270 System.UInt64 ExitGames.Client.Photon.Protocol18::ReadCompressedUInt64(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedUInt64_m9B7F063484F938E4F240BA002B67F338250A9483 (void);
// 0x00000271 System.Int32[] ExitGames.Client.Photon.Protocol18::ReadCompressedInt32Array(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedInt32Array_mB7F5D2B618F1061766D66D947EB64C63D291F8D9 (void);
// 0x00000272 System.Int64[] ExitGames.Client.Photon.Protocol18::ReadCompressedInt64Array(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedInt64Array_m120C88D9BCFF624E2FD978A66675607FC154DD58 (void);
// 0x00000273 System.Int32 ExitGames.Client.Photon.Protocol18::DecodeZigZag32(System.UInt32)
extern void Protocol18_DecodeZigZag32_mACEEA9051FC1AFFEB8429B8BEF592310B7DA1116 (void);
// 0x00000274 System.Int64 ExitGames.Client.Photon.Protocol18::DecodeZigZag64(System.UInt64)
extern void Protocol18_DecodeZigZag64_mA4BC3625A35BE928E09A3218588FEE85341D2453 (void);
// 0x00000275 System.Void ExitGames.Client.Photon.Protocol18::Write(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_Write_mF7C37DDD5DDDE1CE617B58DB04F4302EF590EA42 (void);
// 0x00000276 System.Void ExitGames.Client.Photon.Protocol18::Write(ExitGames.Client.Photon.StreamBuffer,System.Object,ExitGames.Client.Photon.Protocol18_GpType,System.Boolean)
extern void Protocol18_Write_m9BC32ACCE1E26B31E516B4E3073D7A95DF21F351 (void);
// 0x00000277 System.Void ExitGames.Client.Photon.Protocol18::SerializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData,System.Boolean)
extern void Protocol18_SerializeEventData_m39E5951CE427081C3A8DBF9F97D701AEF45EB3CE (void);
// 0x00000278 System.Void ExitGames.Client.Photon.Protocol18::WriteParameterTable(ExitGames.Client.Photon.StreamBuffer,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>)
extern void Protocol18_WriteParameterTable_m8C35A8A50438B5AEBEA3595DE849DBC7FF13A6F6 (void);
// 0x00000279 System.Void ExitGames.Client.Photon.Protocol18::WriteParameterTable(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.ParameterDictionary)
extern void Protocol18_WriteParameterTable_m32EF7D045788EDE51B9B9846DDEA0DB721425992 (void);
// 0x0000027A System.Void ExitGames.Client.Photon.Protocol18::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.OperationRequest,System.Boolean)
extern void Protocol18_SerializeOperationRequest_m9077C7AE7E6F7D9188034220A3AB39CA9504AD9F (void);
// 0x0000027B System.Void ExitGames.Client.Photon.Protocol18::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,System.Boolean)
extern void Protocol18_SerializeOperationRequest_mF49A0ACE7567A86F2F6A227E3BDB7DAA7EBCA672 (void);
// 0x0000027C System.Void ExitGames.Client.Photon.Protocol18::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,System.Byte,ExitGames.Client.Photon.ParameterDictionary,System.Boolean)
extern void Protocol18_SerializeOperationRequest_m8BA0E9475E3924D5322A9F527F4E33364B436760 (void);
// 0x0000027D System.Void ExitGames.Client.Photon.Protocol18::SerializeOperationResponse(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.OperationResponse,System.Boolean)
extern void Protocol18_SerializeOperationResponse_m36D6E5989F064BACBD8F6EB1DC2B12E8F39EFDA2 (void);
// 0x0000027E System.Void ExitGames.Client.Photon.Protocol18::WriteByte(ExitGames.Client.Photon.StreamBuffer,System.Byte,System.Boolean)
extern void Protocol18_WriteByte_m09AF71165F0200B2646F6804C4A5C85A4CD7BACB (void);
// 0x0000027F System.Void ExitGames.Client.Photon.Protocol18::WriteBoolean(ExitGames.Client.Photon.StreamBuffer,System.Boolean,System.Boolean)
extern void Protocol18_WriteBoolean_m0769B46175746D07F2977B89C0572F1612006757 (void);
// 0x00000280 System.Void ExitGames.Client.Photon.Protocol18::WriteUShort(ExitGames.Client.Photon.StreamBuffer,System.UInt16)
extern void Protocol18_WriteUShort_m8D45AAFAB5254DE317600BD5B515A8EFBC7A2A4F (void);
// 0x00000281 System.Void ExitGames.Client.Photon.Protocol18::WriteInt16(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.Boolean)
extern void Protocol18_WriteInt16_m8491308A0FFDDD4707E10DDE7ACF0CD5AFC0B76C (void);
// 0x00000282 System.Void ExitGames.Client.Photon.Protocol18::WriteDouble(ExitGames.Client.Photon.StreamBuffer,System.Double,System.Boolean)
extern void Protocol18_WriteDouble_mF35491A348EE9254188C8D872A243D3D922AFFD5 (void);
// 0x00000283 System.Void ExitGames.Client.Photon.Protocol18::WriteSingle(ExitGames.Client.Photon.StreamBuffer,System.Single,System.Boolean)
extern void Protocol18_WriteSingle_m8DDF6C197F96E072539452AF1CA9E06C8DB4493A (void);
// 0x00000284 System.Void ExitGames.Client.Photon.Protocol18::WriteString(ExitGames.Client.Photon.StreamBuffer,System.String,System.Boolean)
extern void Protocol18_WriteString_m7DAB4B13ECCF933C34C890B74C79D5D9EC654E1D (void);
// 0x00000285 System.Void ExitGames.Client.Photon.Protocol18::WriteHashtable(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteHashtable_m3049CA1849694F40E4D5416EC2F5DEA4C366259B (void);
// 0x00000286 System.Void ExitGames.Client.Photon.Protocol18::WriteByteArray(ExitGames.Client.Photon.StreamBuffer,System.Byte[],System.Boolean)
extern void Protocol18_WriteByteArray_mA29066A57F922C59FBDC0D2A613F7D0058F6C582 (void);
// 0x00000287 System.Void ExitGames.Client.Photon.Protocol18::WriteArraySegmentByte(ExitGames.Client.Photon.StreamBuffer,System.ArraySegment`1<System.Byte>,System.Boolean)
extern void Protocol18_WriteArraySegmentByte_m850F64E20D6D5C70BC0864ED1E4C103934F0C987 (void);
// 0x00000288 System.Void ExitGames.Client.Photon.Protocol18::WriteByteArraySlice(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.ByteArraySlice,System.Boolean)
extern void Protocol18_WriteByteArraySlice_m8561C7F465CB7824029EFB7BD558679B777A10CC (void);
// 0x00000289 System.Void ExitGames.Client.Photon.Protocol18::WriteInt32ArrayCompressed(ExitGames.Client.Photon.StreamBuffer,System.Int32[],System.Boolean)
extern void Protocol18_WriteInt32ArrayCompressed_m36418993D473E2308BF03DD8265A0ED46522BCB6 (void);
// 0x0000028A System.Void ExitGames.Client.Photon.Protocol18::WriteInt64ArrayCompressed(ExitGames.Client.Photon.StreamBuffer,System.Int64[],System.Boolean)
extern void Protocol18_WriteInt64ArrayCompressed_m6EF1B8668BDB155E31FCDADE9E78A80D5707BA70 (void);
// 0x0000028B System.Void ExitGames.Client.Photon.Protocol18::WriteBoolArray(ExitGames.Client.Photon.StreamBuffer,System.Boolean[],System.Boolean)
extern void Protocol18_WriteBoolArray_m5E390996A6A50C3F372E71022777E8FE56EFA5A0 (void);
// 0x0000028C System.Void ExitGames.Client.Photon.Protocol18::WriteInt16Array(ExitGames.Client.Photon.StreamBuffer,System.Int16[],System.Boolean)
extern void Protocol18_WriteInt16Array_m0B6B162DC1C956540EDAC316DD4B6D9B70E524DC (void);
// 0x0000028D System.Void ExitGames.Client.Photon.Protocol18::WriteSingleArray(ExitGames.Client.Photon.StreamBuffer,System.Single[],System.Boolean)
extern void Protocol18_WriteSingleArray_m573081EB19FAB3E13660A2312242A361A358AEBE (void);
// 0x0000028E System.Void ExitGames.Client.Photon.Protocol18::WriteDoubleArray(ExitGames.Client.Photon.StreamBuffer,System.Double[],System.Boolean)
extern void Protocol18_WriteDoubleArray_mD2620072C5D98BA7B990D4C5673129823AFCA9C9 (void);
// 0x0000028F System.Void ExitGames.Client.Photon.Protocol18::WriteStringArray(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteStringArray_m1152C424C3ACF23FF7A16B8A5BD1A2694E9E938D (void);
// 0x00000290 System.Void ExitGames.Client.Photon.Protocol18::WriteObjectArray(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteObjectArray_mB6F7ADE913EFD4D39007AE12AE8B0457976B8D44 (void);
// 0x00000291 System.Void ExitGames.Client.Photon.Protocol18::WriteObjectArray(ExitGames.Client.Photon.StreamBuffer,System.Collections.IList,System.Boolean)
extern void Protocol18_WriteObjectArray_m3366E5C482B5E3AFF93570D35F3D0B66CEF10576 (void);
// 0x00000292 System.Void ExitGames.Client.Photon.Protocol18::WriteArrayInArray(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteArrayInArray_mDB7CF18A498261F79E910C6E3E9329C30A54C0F1 (void);
// 0x00000293 System.Void ExitGames.Client.Photon.Protocol18::WriteCustomTypeBody(ExitGames.Client.Photon.CustomType,ExitGames.Client.Photon.StreamBuffer,System.Object)
extern void Protocol18_WriteCustomTypeBody_m93B798CB5F8E3A6EF026F4050E55521EFEC19001 (void);
// 0x00000294 System.Void ExitGames.Client.Photon.Protocol18::WriteCustomType(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteCustomType_m1C8B98F817EF3300F3AE2718363E154CD0C548B9 (void);
// 0x00000295 System.Void ExitGames.Client.Photon.Protocol18::WriteCustomTypeArray(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteCustomTypeArray_mB8F4EA8B7EF63A5B0B1950F522F6200CC7DBDEB6 (void);
// 0x00000296 System.Boolean ExitGames.Client.Photon.Protocol18::WriteArrayHeader(ExitGames.Client.Photon.StreamBuffer,System.Type)
extern void Protocol18_WriteArrayHeader_mFD3EF867E30605F1C7E202ABE9C262317A5E0A5F (void);
// 0x00000297 System.Void ExitGames.Client.Photon.Protocol18::WriteDictionaryElements(ExitGames.Client.Photon.StreamBuffer,System.Collections.IDictionary,ExitGames.Client.Photon.Protocol18_GpType,ExitGames.Client.Photon.Protocol18_GpType)
extern void Protocol18_WriteDictionaryElements_m0BA00C62C65E8AE638298A6723D26D0807B504E5 (void);
// 0x00000298 System.Void ExitGames.Client.Photon.Protocol18::WriteDictionary(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteDictionary_mB2251C0C08D240514A0C85A36C25E0F385219070 (void);
// 0x00000299 System.Void ExitGames.Client.Photon.Protocol18::WriteDictionaryHeader(ExitGames.Client.Photon.StreamBuffer,System.Type,ExitGames.Client.Photon.Protocol18_GpType&,ExitGames.Client.Photon.Protocol18_GpType&)
extern void Protocol18_WriteDictionaryHeader_m17F347CC6010BD4A290112DCA5B0F5EEBB0908C9 (void);
// 0x0000029A System.Boolean ExitGames.Client.Photon.Protocol18::WriteArrayType(ExitGames.Client.Photon.StreamBuffer,System.Type,ExitGames.Client.Photon.Protocol18_GpType&)
extern void Protocol18_WriteArrayType_m0F062BA8DC79325022D5139101BE6D403590FFF2 (void);
// 0x0000029B System.Void ExitGames.Client.Photon.Protocol18::WriteHashtableArray(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteHashtableArray_m71A34C4A5116A147C460A6CB58F1C25B1CCD6ACD (void);
// 0x0000029C System.Void ExitGames.Client.Photon.Protocol18::WriteDictionaryArray(ExitGames.Client.Photon.StreamBuffer,System.Collections.IDictionary[],System.Boolean)
extern void Protocol18_WriteDictionaryArray_m21B482D391C88C70810F4573C1A84E58446F39F5 (void);
// 0x0000029D System.Void ExitGames.Client.Photon.Protocol18::WriteIntLength(ExitGames.Client.Photon.StreamBuffer,System.Int32)
extern void Protocol18_WriteIntLength_m08FC5AE95B2ABFB77AF31EF0A45D7518BA54C6F9 (void);
// 0x0000029E System.Void ExitGames.Client.Photon.Protocol18::WriteVarInt32(ExitGames.Client.Photon.StreamBuffer,System.Int32,System.Boolean)
extern void Protocol18_WriteVarInt32_m9B26A239DFABE2A1EBF4641CC19C65CB716B17C9 (void);
// 0x0000029F System.Void ExitGames.Client.Photon.Protocol18::WriteCompressedInt32(ExitGames.Client.Photon.StreamBuffer,System.Int32,System.Boolean)
extern void Protocol18_WriteCompressedInt32_mD3A5BF3430F53D75E7502C8288514BEA4B1E2EC8 (void);
// 0x000002A0 System.Void ExitGames.Client.Photon.Protocol18::WriteCompressedInt64(ExitGames.Client.Photon.StreamBuffer,System.Int64,System.Boolean)
extern void Protocol18_WriteCompressedInt64_m743E019C394294E2F2FE0838BEE1ECCE98F0F063 (void);
// 0x000002A1 System.Void ExitGames.Client.Photon.Protocol18::WriteCompressedUInt32(ExitGames.Client.Photon.StreamBuffer,System.UInt32)
extern void Protocol18_WriteCompressedUInt32_mBCCAFF4517A9250DFD1D84351FA07BC8C43D2AF2 (void);
// 0x000002A2 System.Int32 ExitGames.Client.Photon.Protocol18::WriteCompressedUInt32(System.Byte[],System.UInt32)
extern void Protocol18_WriteCompressedUInt32_mEFE4A8C0A0E8710F2A7A4F04DC070A39E9CAE757 (void);
// 0x000002A3 System.Void ExitGames.Client.Photon.Protocol18::WriteCompressedUInt64(ExitGames.Client.Photon.StreamBuffer,System.UInt64)
extern void Protocol18_WriteCompressedUInt64_mD349352229DF670BBFF340C2A32A67F063625933 (void);
// 0x000002A4 System.UInt32 ExitGames.Client.Photon.Protocol18::EncodeZigZag32(System.Int32)
extern void Protocol18_EncodeZigZag32_m986834D9F95CB41469A7AFE41BB5E3583487D8B1 (void);
// 0x000002A5 System.UInt64 ExitGames.Client.Photon.Protocol18::EncodeZigZag64(System.Int64)
extern void Protocol18_EncodeZigZag64_mFEC1878B0B7684B9DEB5A867F3CD10EAA5E2D7E6 (void);
// 0x000002A6 System.Void ExitGames.Client.Photon.Protocol18::.ctor()
extern void Protocol18__ctor_m22A7FC9394BEC0B9033B6816D5561B33139D15EE (void);
// 0x000002A7 System.Void ExitGames.Client.Photon.Protocol18::.cctor()
extern void Protocol18__cctor_m08035FE03A369339AA8B8F5944DC76C26F035139 (void);
// 0x000002A8 System.Boolean ExitGames.Client.Photon.SendOptions::get_Reliability()
extern void SendOptions_get_Reliability_mB59F1C863C7D1F054C004F11E7320CD7F94B55C4_AdjustorThunk (void);
// 0x000002A9 System.Void ExitGames.Client.Photon.SendOptions::set_Reliability(System.Boolean)
extern void SendOptions_set_Reliability_mC77446E8524CA786BE18E235B7857357F1EF12A0_AdjustorThunk (void);
// 0x000002AA System.Void ExitGames.Client.Photon.SendOptions::.cctor()
extern void SendOptions__cctor_mDC55D7C2228550A15240DC3BDF99322552906D16 (void);
// 0x000002AB System.IntPtr ExitGames.Client.Photon.SocketNative::egconnect(System.String)
extern void SocketNative_egconnect_m5176E005A047310FBAD3925093430D655B30ECB4 (void);
// 0x000002AC System.IntPtr ExitGames.Client.Photon.SocketNative::egconnectWithProtocol(System.String,System.Byte)
extern void SocketNative_egconnectWithProtocol_m806F08EDDBCC87E91BEA0B4B5C6DD20CD6537FD9 (void);
// 0x000002AD System.IntPtr ExitGames.Client.Photon.SocketNative::egconnectWithProtocols(System.String,System.Byte,System.String,System.String,System.Byte,System.Byte)
extern void SocketNative_egconnectWithProtocols_m78D90C2E20B316FF5E3A7A5B04929CF0C2D92C59 (void);
// 0x000002AE System.Byte ExitGames.Client.Photon.SocketNative::eggetState(System.IntPtr)
extern void SocketNative_eggetState_m4AD208DAA5A2980AAABBECA1019DD30E6AE8D688 (void);
// 0x000002AF System.Void ExitGames.Client.Photon.SocketNative::egdisconnect(System.IntPtr)
extern void SocketNative_egdisconnect_m750D6BDB5D814582523F0BB0FA1144AB7496FCAA (void);
// 0x000002B0 System.UInt32 ExitGames.Client.Photon.SocketNative::egservice(System.IntPtr)
extern void SocketNative_egservice_m4C88B9F394F0CE2964250AD66450D59E2500339B (void);
// 0x000002B1 System.Boolean ExitGames.Client.Photon.SocketNative::egsend(System.IntPtr,System.Byte[],System.UInt32)
extern void SocketNative_egsend_mA60863CC2B6F230B0BC1403D4B95E5FA6EE9C1C4 (void);
// 0x000002B2 System.UInt32 ExitGames.Client.Photon.SocketNative::egread(System.IntPtr,System.Byte[],System.UInt32&)
extern void SocketNative_egread_m2D60605B078002752445D93C4AB748617547EAE4 (void);
// 0x000002B3 System.Void ExitGames.Client.Photon.SocketNative::egsetSocketLoggingCallback(System.IntPtr,System.IntPtr,ExitGames.Client.Photon.SocketNative_LogCallbackDelegate)
extern void SocketNative_egsetSocketLoggingCallback_mE8AF39979206D829B16AB4DA422A728A977F77D4 (void);
// 0x000002B4 System.Boolean ExitGames.Client.Photon.SocketNative::egsetSocketLoggingLevel(System.IntPtr,System.Int32)
extern void SocketNative_egsetSocketLoggingLevel_m38053AEE63633BF17868B53F3EF79C66F4104389 (void);
// 0x000002B5 System.Boolean ExitGames.Client.Photon.SocketNative::eggetUsingIPv6(System.IntPtr)
extern void SocketNative_eggetUsingIPv6_m83C9849BFFBA18E8DD7DDEF9962217B05E6259FD (void);
// 0x000002B6 System.Void ExitGames.Client.Photon.SocketNative::.ctor(ExitGames.Client.Photon.PeerBase)
extern void SocketNative__ctor_m3AEEE22ACF3E30F3F21E3837283C91E48A16857A (void);
// 0x000002B7 System.Void ExitGames.Client.Photon.SocketNative::Finalize()
extern void SocketNative_Finalize_m1337197EC8A39DA301ACDDC621AE3F3A8AF7C93E (void);
// 0x000002B8 System.Void ExitGames.Client.Photon.SocketNative::Dispose()
extern void SocketNative_Dispose_mEEB96AE00BB25794615051FD3CB9394BD23C21AB (void);
// 0x000002B9 System.Boolean ExitGames.Client.Photon.SocketNative::Connect()
extern void SocketNative_Connect_m26D14B23A416C1531F0CB7D48D166334635A0771 (void);
// 0x000002BA System.Void ExitGames.Client.Photon.SocketNative::DebugReturn(System.IntPtr,System.Int32,System.String)
extern void SocketNative_DebugReturn_m3D36438056F5FD4B647AD3D732F52B028557B6C6 (void);
// 0x000002BB System.Void ExitGames.Client.Photon.SocketNative::DnsAndConnect()
extern void SocketNative_DnsAndConnect_m7D5858BF00FC7D1E1116C6D44D551DA8FDB8699D (void);
// 0x000002BC System.Boolean ExitGames.Client.Photon.SocketNative::Disconnect()
extern void SocketNative_Disconnect_mCCD2CFE2EB69256C268ECCD434A822CACE5E937C (void);
// 0x000002BD ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketNative::Send(System.Byte[],System.Int32)
extern void SocketNative_Send_mFE6D1CF3180FD67421AC1AD40E103F5E8B26A8F9 (void);
// 0x000002BE ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketNative::Receive(System.Byte[]&)
extern void SocketNative_Receive_mECB59C242FD2A3D79449F28A6BA871796D82F928 (void);
// 0x000002BF System.Void ExitGames.Client.Photon.SocketNative::ReceiveLoop()
extern void SocketNative_ReceiveLoop_m5571BF0BDF112DF5E0969BFD99A84721F9659CE3 (void);
// 0x000002C0 System.Void ExitGames.Client.Photon.SocketNative_LogCallbackDelegate::.ctor(System.Object,System.IntPtr)
extern void LogCallbackDelegate__ctor_m044E69D655ECA9BC09132D1CCA84B0789C3B90FC (void);
// 0x000002C1 System.Void ExitGames.Client.Photon.SocketNative_LogCallbackDelegate::Invoke(System.IntPtr,System.Int32,System.String)
extern void LogCallbackDelegate_Invoke_mCA190F9A5AD687AF46634DDF8B9194B9360DCBE5 (void);
// 0x000002C2 System.IAsyncResult ExitGames.Client.Photon.SocketNative_LogCallbackDelegate::BeginInvoke(System.IntPtr,System.Int32,System.String,System.AsyncCallback,System.Object)
extern void LogCallbackDelegate_BeginInvoke_mE37C748185236AB26F63FBEAF08BB1A9B307D990 (void);
// 0x000002C3 System.Void ExitGames.Client.Photon.SocketNative_LogCallbackDelegate::EndInvoke(System.IAsyncResult)
extern void LogCallbackDelegate_EndInvoke_mD10D6BB783DA08E522A6A680F2B8F25CF6C8F015 (void);
// 0x000002C4 System.Void ExitGames.Client.Photon.SocketTcp::.ctor(ExitGames.Client.Photon.PeerBase)
extern void SocketTcp__ctor_m13C724CC217A6A4AC3C9BBE826F6800F9C773F14 (void);
// 0x000002C5 System.Void ExitGames.Client.Photon.SocketTcp::Finalize()
extern void SocketTcp_Finalize_m50FEC8060A6E0574F554A8592E1B419CD550C135 (void);
// 0x000002C6 System.Void ExitGames.Client.Photon.SocketTcp::Dispose()
extern void SocketTcp_Dispose_mE3FC268156D1A60E36AF823EA2BDB95A5EBDDA31 (void);
// 0x000002C7 System.Boolean ExitGames.Client.Photon.SocketTcp::Connect()
extern void SocketTcp_Connect_mF685C8B52ABD9664927A42034F39750B85EF1AE4 (void);
// 0x000002C8 System.Boolean ExitGames.Client.Photon.SocketTcp::Disconnect()
extern void SocketTcp_Disconnect_m274104C3EAB2A82D40EAAF5347AC7B3056EC7CF5 (void);
// 0x000002C9 ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketTcp::Send(System.Byte[],System.Int32)
extern void SocketTcp_Send_m3D571D4C1438B575D6DDE2C0443B4EF6E22D7AB0 (void);
// 0x000002CA ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketTcp::Receive(System.Byte[]&)
extern void SocketTcp_Receive_m3DD9B3246B73FC16E968A6821E2D75946C0CD583 (void);
// 0x000002CB System.Void ExitGames.Client.Photon.SocketTcp::DnsAndConnect()
extern void SocketTcp_DnsAndConnect_mB027C1D044836E47C565057AFDF8E0D43B4D5AC3 (void);
// 0x000002CC System.Void ExitGames.Client.Photon.SocketTcp::ReceiveLoop()
extern void SocketTcp_ReceiveLoop_m8CEF82CD3E0268C9A1529B6E60E30343E11DE25F (void);
// 0x000002CD System.Void ExitGames.Client.Photon.SocketTcpAsync::.ctor(ExitGames.Client.Photon.PeerBase)
extern void SocketTcpAsync__ctor_mF0DD3CA73B04F5685B3A5F55BCBD6F6BF5727D32 (void);
// 0x000002CE System.Void ExitGames.Client.Photon.SocketTcpAsync::Finalize()
extern void SocketTcpAsync_Finalize_m782644322B409F031DEEBBA425F98632C1CC15FD (void);
// 0x000002CF System.Void ExitGames.Client.Photon.SocketTcpAsync::Dispose()
extern void SocketTcpAsync_Dispose_m9D8910FA9790D2A4865927A8FC2EBCC3E23183A0 (void);
// 0x000002D0 System.Boolean ExitGames.Client.Photon.SocketTcpAsync::Connect()
extern void SocketTcpAsync_Connect_mE2DC1317A00792C6E6332E2B5E2487EC2AEEA62A (void);
// 0x000002D1 System.Boolean ExitGames.Client.Photon.SocketTcpAsync::Disconnect()
extern void SocketTcpAsync_Disconnect_mBDDB27A6311764679211DFBFDC82E4EDFD4133AC (void);
// 0x000002D2 ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketTcpAsync::Send(System.Byte[],System.Int32)
extern void SocketTcpAsync_Send_mE9BE56BDA956FBF91E16E8D4048064DE9A542E50 (void);
// 0x000002D3 ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketTcpAsync::Receive(System.Byte[]&)
extern void SocketTcpAsync_Receive_mE2F9F9698E66A99A4A033C14DCB08EA18D3397FB (void);
// 0x000002D4 System.Void ExitGames.Client.Photon.SocketTcpAsync::DnsAndConnect()
extern void SocketTcpAsync_DnsAndConnect_m74F7F2053F81C40B4F4DA336512734D618349FCE (void);
// 0x000002D5 System.Void ExitGames.Client.Photon.SocketTcpAsync::ReceiveAsync(ExitGames.Client.Photon.SocketTcpAsync_ReceiveContext)
extern void SocketTcpAsync_ReceiveAsync_m236ADD7C52953B6F11E9B315021A00CAA62F28D7 (void);
// 0x000002D6 System.Void ExitGames.Client.Photon.SocketTcpAsync::ReceiveAsync(System.IAsyncResult)
extern void SocketTcpAsync_ReceiveAsync_m47212B002D7A0395407BDF641559C7FD1FC5783C (void);
// 0x000002D7 System.Void ExitGames.Client.Photon.SocketTcpAsync_ReceiveContext::.ctor(System.Net.Sockets.Socket,System.Byte[],System.Byte[])
extern void ReceiveContext__ctor_m5A7B0DE7FA6B305890A16936B93C6B581478BDF5 (void);
// 0x000002D8 System.Boolean ExitGames.Client.Photon.SocketTcpAsync_ReceiveContext::get_ReadingHeader()
extern void ReceiveContext_get_ReadingHeader_m35F07F0FA8823F3FC69D751A76A0BB4E369906D5 (void);
// 0x000002D9 System.Boolean ExitGames.Client.Photon.SocketTcpAsync_ReceiveContext::get_ReadingMessage()
extern void ReceiveContext_get_ReadingMessage_m28DF43B11B6BB645FFE71644B84274E06AF90A8C (void);
// 0x000002DA System.Byte[] ExitGames.Client.Photon.SocketTcpAsync_ReceiveContext::get_CurrentBuffer()
extern void ReceiveContext_get_CurrentBuffer_m6B5498715FE8F542D87D48FFC327B60CAC37448D (void);
// 0x000002DB System.Int32 ExitGames.Client.Photon.SocketTcpAsync_ReceiveContext::get_CurrentOffset()
extern void ReceiveContext_get_CurrentOffset_m2E40691FCD9BD5A4609C3965D6F22D2A34CD0C8B (void);
// 0x000002DC System.Int32 ExitGames.Client.Photon.SocketTcpAsync_ReceiveContext::get_CurrentExpected()
extern void ReceiveContext_get_CurrentExpected_m6C6CD2F8A4AAE9BA96F8F3BE296119E4DC890104 (void);
// 0x000002DD System.Void ExitGames.Client.Photon.SocketTcpAsync_ReceiveContext::Reset()
extern void ReceiveContext_Reset_mECAA41521CAA2D5953C06BB1173F92EC2B6E8536 (void);
// 0x000002DE System.Void ExitGames.Client.Photon.SocketUdp::.ctor(ExitGames.Client.Photon.PeerBase)
extern void SocketUdp__ctor_mEFC2826611898FB056BBF00920762C63FDF836DE (void);
// 0x000002DF System.Void ExitGames.Client.Photon.SocketUdp::Finalize()
extern void SocketUdp_Finalize_mF8DE0107AC42D9C95F08FBCE7172EA33C4833651 (void);
// 0x000002E0 System.Void ExitGames.Client.Photon.SocketUdp::Dispose()
extern void SocketUdp_Dispose_m77D90E62CFAAF49E80206C37F125E21E6394EBBB (void);
// 0x000002E1 System.Boolean ExitGames.Client.Photon.SocketUdp::Connect()
extern void SocketUdp_Connect_mD14776A9DB51520BE90E1AC2D4CB0B560933DC70 (void);
// 0x000002E2 System.Boolean ExitGames.Client.Photon.SocketUdp::Disconnect()
extern void SocketUdp_Disconnect_mA8AE69A876F2F09B96BDFF6462680B01931CD377 (void);
// 0x000002E3 ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketUdp::Send(System.Byte[],System.Int32)
extern void SocketUdp_Send_mF494761D40C5D32D4CA21F37D2788B4A27873158 (void);
// 0x000002E4 ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketUdp::Receive(System.Byte[]&)
extern void SocketUdp_Receive_m199234CA91A3C269D89C721C6BF9BEDCA0DBC35E (void);
// 0x000002E5 System.Void ExitGames.Client.Photon.SocketUdp::DnsAndConnect()
extern void SocketUdp_DnsAndConnect_m396610977AF49BD29DD2886CFD0111C80ED85F73 (void);
// 0x000002E6 System.Void ExitGames.Client.Photon.SocketUdp::ReceiveLoop()
extern void SocketUdp_ReceiveLoop_m9A000A5385C95B922B89E07605135401B58A828C (void);
// 0x000002E7 System.Void ExitGames.Client.Photon.SocketUdpAsync::.ctor(ExitGames.Client.Photon.PeerBase)
extern void SocketUdpAsync__ctor_m6A946F4AA3EBE86EFEE4D0A3ECED23332AE9593D (void);
// 0x000002E8 System.Void ExitGames.Client.Photon.SocketUdpAsync::Finalize()
extern void SocketUdpAsync_Finalize_mE16A554083614DC1EF56017A2A8F124DBFB5C9E9 (void);
// 0x000002E9 System.Void ExitGames.Client.Photon.SocketUdpAsync::Dispose()
extern void SocketUdpAsync_Dispose_m03EFDAB00C5654F20ECBB7A83ED495BB3B80EE6E (void);
// 0x000002EA System.Boolean ExitGames.Client.Photon.SocketUdpAsync::Connect()
extern void SocketUdpAsync_Connect_mEA3FD10CF3AD6EA34B58CB67E8A33F7CBB5FB276 (void);
// 0x000002EB System.Boolean ExitGames.Client.Photon.SocketUdpAsync::Disconnect()
extern void SocketUdpAsync_Disconnect_m6263DDE1302E9CE076C59C324B1E8A27B6F26400 (void);
// 0x000002EC ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketUdpAsync::Send(System.Byte[],System.Int32)
extern void SocketUdpAsync_Send_m9EBD2A69A46B054F4A09D6424A7EFF0B80A65609 (void);
// 0x000002ED ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketUdpAsync::Receive(System.Byte[]&)
extern void SocketUdpAsync_Receive_m58C7B987D7790BA394A1337CE2A1033F7CF76CE8 (void);
// 0x000002EE System.Void ExitGames.Client.Photon.SocketUdpAsync::DnsAndConnect()
extern void SocketUdpAsync_DnsAndConnect_m8AE352BAF08F2BF93EBBAD283A782942405B1E72 (void);
// 0x000002EF System.Void ExitGames.Client.Photon.SocketUdpAsync::StartReceive()
extern void SocketUdpAsync_StartReceive_m2233330FC0B61E8F85BADC8B053CF5C21D037D4E (void);
// 0x000002F0 System.Void ExitGames.Client.Photon.SocketUdpAsync::OnReceive(System.IAsyncResult)
extern void SocketUdpAsync_OnReceive_m4F79F163F40472FC7534FC3E48982BD27D5E3732 (void);
// 0x000002F1 System.Void ExitGames.Client.Photon.StreamBuffer::.ctor(System.Int32)
extern void StreamBuffer__ctor_m6741D62D0B5AA1AD4F951EA6166971DD91CE921C (void);
// 0x000002F2 System.Void ExitGames.Client.Photon.StreamBuffer::.ctor(System.Byte[])
extern void StreamBuffer__ctor_m3D663C8D89B6B653C6FB5BE69A6D7C567FC1D487 (void);
// 0x000002F3 System.Byte[] ExitGames.Client.Photon.StreamBuffer::ToArray()
extern void StreamBuffer_ToArray_mE8DB28ACF32D71B1ECF2924CA827A23C8C6FD142 (void);
// 0x000002F4 System.Byte[] ExitGames.Client.Photon.StreamBuffer::ToArrayFromPos()
extern void StreamBuffer_ToArrayFromPos_mF245BEEB718733CE04EDE2A1CDEE82E4F57C02CA (void);
// 0x000002F5 System.Void ExitGames.Client.Photon.StreamBuffer::Compact()
extern void StreamBuffer_Compact_mA399EFD3D6D619E644BDAB333A8B929489C3933C (void);
// 0x000002F6 System.Byte[] ExitGames.Client.Photon.StreamBuffer::GetBuffer()
extern void StreamBuffer_GetBuffer_m79F59BF586871847E6B90B6C2A27A5878AC90E37 (void);
// 0x000002F7 System.Byte[] ExitGames.Client.Photon.StreamBuffer::GetBufferAndAdvance(System.Int32,System.Int32&)
extern void StreamBuffer_GetBufferAndAdvance_m38B894FDABD42E27E0B2458CE06ED07BA12FC834 (void);
// 0x000002F8 System.Boolean ExitGames.Client.Photon.StreamBuffer::get_CanRead()
extern void StreamBuffer_get_CanRead_mF9EB523A62BF1FBEFAD2C62E2FC4523A86D1194F (void);
// 0x000002F9 System.Boolean ExitGames.Client.Photon.StreamBuffer::get_CanSeek()
extern void StreamBuffer_get_CanSeek_mA3234BE7AB32AC2ED8C752C18013529144FEC6FE (void);
// 0x000002FA System.Boolean ExitGames.Client.Photon.StreamBuffer::get_CanWrite()
extern void StreamBuffer_get_CanWrite_m8D7860E524BA6AAEED78B4C24F16518A5670FE6F (void);
// 0x000002FB System.Int32 ExitGames.Client.Photon.StreamBuffer::get_Length()
extern void StreamBuffer_get_Length_m25ED1D6A2694D671039B6E613957359C2A08EC7E (void);
// 0x000002FC System.Int32 ExitGames.Client.Photon.StreamBuffer::get_Position()
extern void StreamBuffer_get_Position_mB2DA1691D41DE363A5A5842E5904D9BAECA2A159 (void);
// 0x000002FD System.Void ExitGames.Client.Photon.StreamBuffer::set_Position(System.Int32)
extern void StreamBuffer_set_Position_m24AE0EF7E75D2FA2FAF0AE474C62D8D3EA6D536F (void);
// 0x000002FE System.Void ExitGames.Client.Photon.StreamBuffer::Flush()
extern void StreamBuffer_Flush_m73795E2244C74B6343C7964D6A35BE2AB67B0F74 (void);
// 0x000002FF System.Int64 ExitGames.Client.Photon.StreamBuffer::Seek(System.Int64,System.IO.SeekOrigin)
extern void StreamBuffer_Seek_mB3CA4BE799C99040F278CDE0B628E3D7406737E2 (void);
// 0x00000300 System.Void ExitGames.Client.Photon.StreamBuffer::SetLength(System.Int64)
extern void StreamBuffer_SetLength_mFBB2205D71E335E8781CBFC39427568CD3DA7481 (void);
// 0x00000301 System.Void ExitGames.Client.Photon.StreamBuffer::SetCapacityMinimum(System.Int32)
extern void StreamBuffer_SetCapacityMinimum_mAE7703A01484D3A000FBE4AF736E797B7BC1F149 (void);
// 0x00000302 System.Int32 ExitGames.Client.Photon.StreamBuffer::Read(System.Byte[],System.Int32,System.Int32)
extern void StreamBuffer_Read_m2C67AEA14C4E9C2863F513A1C4E4201C1C1087C5 (void);
// 0x00000303 System.Void ExitGames.Client.Photon.StreamBuffer::Write(System.Byte[],System.Int32,System.Int32)
extern void StreamBuffer_Write_m73CBB2D7D37C0AEC59784DC671A4FA58E1ADDEA2 (void);
// 0x00000304 System.Byte ExitGames.Client.Photon.StreamBuffer::ReadByte()
extern void StreamBuffer_ReadByte_mC09C543D9ECAF0221C64A971BE2FC7AD075C8A14 (void);
// 0x00000305 System.Void ExitGames.Client.Photon.StreamBuffer::WriteByte(System.Byte)
extern void StreamBuffer_WriteByte_m91BD1873D9C122433ED2674AACE71B554BB33769 (void);
// 0x00000306 System.Void ExitGames.Client.Photon.StreamBuffer::WriteBytes(System.Byte,System.Byte)
extern void StreamBuffer_WriteBytes_m55B97C40B8264BF9B6B758574CB3FFCE93078242 (void);
// 0x00000307 System.Void ExitGames.Client.Photon.StreamBuffer::WriteBytes(System.Byte,System.Byte,System.Byte)
extern void StreamBuffer_WriteBytes_m565E330ECF043BCFCF1EA67A3F96883CF4338E60 (void);
// 0x00000308 System.Void ExitGames.Client.Photon.StreamBuffer::WriteBytes(System.Byte,System.Byte,System.Byte,System.Byte)
extern void StreamBuffer_WriteBytes_m748F93C3367B589CF0DD28580ABD9CFACE99D4F5 (void);
// 0x00000309 System.Void ExitGames.Client.Photon.StreamBuffer::WriteBytes(System.Byte,System.Byte,System.Byte,System.Byte,System.Byte,System.Byte,System.Byte,System.Byte)
extern void StreamBuffer_WriteBytes_m2C009C9D17C9F88BAD27ACF57163ABC9836BF0BE (void);
// 0x0000030A System.Boolean ExitGames.Client.Photon.StreamBuffer::CheckSize(System.Int32)
extern void StreamBuffer_CheckSize_m369091E28AA3BC3A89B8554869294BD610C6FBAA (void);
// 0x0000030B System.Collections.Generic.List`1<System.Reflection.MethodInfo> ExitGames.Client.Photon.SupportClass::GetMethods(System.Type,System.Type)
extern void SupportClass_GetMethods_mCBB60FFF3C6E27AFA90ED968FF33008CEA5F45A6 (void);
// 0x0000030C System.Int32 ExitGames.Client.Photon.SupportClass::GetTickCount()
extern void SupportClass_GetTickCount_mA0086E5ACABD24CF0434DD2CD11C54BAD34058D2 (void);
// 0x0000030D System.Byte ExitGames.Client.Photon.SupportClass::StartBackgroundCalls(System.Func`1<System.Boolean>,System.Int32,System.String)
extern void SupportClass_StartBackgroundCalls_m97526EE667EC704A455FD13C141D62E21253A282 (void);
// 0x0000030E System.Boolean ExitGames.Client.Photon.SupportClass::StopBackgroundCalls(System.Byte)
extern void SupportClass_StopBackgroundCalls_m9FAC8E09B24EBBFB79F70D3217DC6DCDF920E5A6 (void);
// 0x0000030F System.Boolean ExitGames.Client.Photon.SupportClass::StopAllBackgroundCalls()
extern void SupportClass_StopAllBackgroundCalls_m01E38449EF57C0FA9C483CE541C9ADCF656C2D85 (void);
// 0x00000310 System.Void ExitGames.Client.Photon.SupportClass::WriteStackTrace(System.Exception,System.IO.TextWriter)
extern void SupportClass_WriteStackTrace_m92D17F6B1D5AE459E3A14C494F681E620F7606C6 (void);
// 0x00000311 System.Void ExitGames.Client.Photon.SupportClass::WriteStackTrace(System.Exception)
extern void SupportClass_WriteStackTrace_mD40141F866AA995D02A2D4F739D004608A89CBC1 (void);
// 0x00000312 System.String ExitGames.Client.Photon.SupportClass::DictionaryToString(System.Collections.IDictionary,System.Boolean)
extern void SupportClass_DictionaryToString_m1E005B8D84A505955CE57EE43881C01A3C5D4525 (void);
// 0x00000313 System.String ExitGames.Client.Photon.SupportClass::DictionaryToString(ExitGames.Client.Photon.NonAllocDictionary`2<System.Byte,System.Object>,System.Boolean)
extern void SupportClass_DictionaryToString_m7DB3E9F96BDA0BBD8FDF9C753518007E6C418F16 (void);
// 0x00000314 System.String ExitGames.Client.Photon.SupportClass::HashtableToString(ExitGames.Client.Photon.Hashtable)
extern void SupportClass_HashtableToString_m58275C29667A4797D2299BEDFA1481E4F443FF8E (void);
// 0x00000315 System.String ExitGames.Client.Photon.SupportClass::ByteArrayToString(System.Byte[])
extern void SupportClass_ByteArrayToString_m62F24AFEB6753A4B51C46ADC4FF6F5D6608F8FC7 (void);
// 0x00000316 System.UInt32[] ExitGames.Client.Photon.SupportClass::InitializeTable(System.UInt32)
extern void SupportClass_InitializeTable_m3D01F8860C55EEB1BE9BF1A08409BD2F58368033 (void);
// 0x00000317 System.UInt32 ExitGames.Client.Photon.SupportClass::CalculateCrc(System.Byte[],System.Int32)
extern void SupportClass_CalculateCrc_m936192955DFE5862CA5EF52BF0B581A51674EEBF (void);
// 0x00000318 System.Void ExitGames.Client.Photon.SupportClass::.ctor()
extern void SupportClass__ctor_m5C3866632D524715A22760D87D6628ADCECBEB33 (void);
// 0x00000319 System.Void ExitGames.Client.Photon.SupportClass::.cctor()
extern void SupportClass__cctor_m8B2F4DB244F7C76095E1D06E73E745EE37312532 (void);
// 0x0000031A System.Void ExitGames.Client.Photon.SupportClass_IntegerMillisecondsDelegate::.ctor(System.Object,System.IntPtr)
extern void IntegerMillisecondsDelegate__ctor_mDA3273E2CE0D8FE39164E71CAA2031FAEDCF287C (void);
// 0x0000031B System.Int32 ExitGames.Client.Photon.SupportClass_IntegerMillisecondsDelegate::Invoke()
extern void IntegerMillisecondsDelegate_Invoke_m3BBA95A0E5A8E30E4FF461F7A8C43FC5E67A4DD4 (void);
// 0x0000031C System.IAsyncResult ExitGames.Client.Photon.SupportClass_IntegerMillisecondsDelegate::BeginInvoke(System.AsyncCallback,System.Object)
extern void IntegerMillisecondsDelegate_BeginInvoke_mE2527A597A807656326C984C51D9A87FBC3FF9CB (void);
// 0x0000031D System.Int32 ExitGames.Client.Photon.SupportClass_IntegerMillisecondsDelegate::EndInvoke(System.IAsyncResult)
extern void IntegerMillisecondsDelegate_EndInvoke_m9356EF0422BC12A81CDE180BC829D30D112ABEFC (void);
// 0x0000031E System.Int32 ExitGames.Client.Photon.SupportClass_ThreadSafeRandom::Next()
extern void ThreadSafeRandom_Next_m81D40266E8D1D8EDD95D9AB0425D7C4005E49B25 (void);
// 0x0000031F System.Void ExitGames.Client.Photon.SupportClass_ThreadSafeRandom::.ctor()
extern void ThreadSafeRandom__ctor_m19029CAA02F811B542856515BD252C47CF08A78F (void);
// 0x00000320 System.Void ExitGames.Client.Photon.SupportClass_ThreadSafeRandom::.cctor()
extern void ThreadSafeRandom__cctor_mDC6B1F44182E3141B4B56F3D5DBDEB29841F0D9B (void);
// 0x00000321 System.Void ExitGames.Client.Photon.SupportClass_<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_m6C82CB693ABED6C0B9863862F932F64AE40D5645 (void);
// 0x00000322 System.Void ExitGames.Client.Photon.SupportClass_<>c__DisplayClass6_0::<StartBackgroundCalls>b__0()
extern void U3CU3Ec__DisplayClass6_0_U3CStartBackgroundCallsU3Eb__0_m2BFA2B91A0E678A5DB5132B6D2F0E6A6759A641E (void);
// 0x00000323 System.Void ExitGames.Client.Photon.SupportClass_<>c::.cctor()
extern void U3CU3Ec__cctor_m4715CD20BEF03F217208AA4D99D50A9C72E421D4 (void);
// 0x00000324 System.Void ExitGames.Client.Photon.SupportClass_<>c::.ctor()
extern void U3CU3Ec__ctor_m9156FE65A757702ED75B32540E42268ECBB698D6 (void);
// 0x00000325 System.Int32 ExitGames.Client.Photon.SupportClass_<>c::<.cctor>b__20_0()
extern void U3CU3Ec_U3C_cctorU3Eb__20_0_mB1D5166DFEE4B03A5BE6EBDC6C2A9AE091DCEB28 (void);
// 0x00000326 System.Void ExitGames.Client.Photon.Pool`1::.ctor(System.Func`1<T>,System.Action`1<T>,System.Int32)
// 0x00000327 System.Void ExitGames.Client.Photon.Pool`1::.ctor(System.Func`1<T>,System.Int32)
// 0x00000328 System.Int32 ExitGames.Client.Photon.Pool`1::get_Count()
// 0x00000329 System.Void ExitGames.Client.Photon.Pool`1::CreatePoolItems(System.Int32)
// 0x0000032A System.Void ExitGames.Client.Photon.Pool`1::Push(T)
// 0x0000032B System.Void ExitGames.Client.Photon.Pool`1::Release(T)
// 0x0000032C T ExitGames.Client.Photon.Pool`1::Pop()
// 0x0000032D T ExitGames.Client.Photon.Pool`1::Acquire()
// 0x0000032E System.Void ExitGames.Client.Photon.PreserveAttribute::.ctor()
extern void PreserveAttribute__ctor_m6C97B88484AE59AF86941BA63360427A96190335 (void);
// 0x0000032F System.Int32 ExitGames.Client.Photon.TPeer::get_QueuedIncomingCommandsCount()
extern void TPeer_get_QueuedIncomingCommandsCount_mA332EC035639C12C0A265699333D74978DDADF7D (void);
// 0x00000330 System.Int32 ExitGames.Client.Photon.TPeer::get_QueuedOutgoingCommandsCount()
extern void TPeer_get_QueuedOutgoingCommandsCount_m786416DF442D145FDB60CE3558EC9EE480C343A6 (void);
// 0x00000331 System.Void ExitGames.Client.Photon.TPeer::.ctor()
extern void TPeer__ctor_m957957FD2DE6B73AFFC8DA74865BFE0A0D8132C2 (void);
// 0x00000332 System.Boolean ExitGames.Client.Photon.TPeer::IsTransportEncrypted()
extern void TPeer_IsTransportEncrypted_mED4014A5183C7D9CAF51AB4F48D142F39497BB1E (void);
// 0x00000333 System.Void ExitGames.Client.Photon.TPeer::Reset()
extern void TPeer_Reset_mC17366CA64B83D5B026E00CE94FB258FD395F8B6 (void);
// 0x00000334 System.Boolean ExitGames.Client.Photon.TPeer::Connect(System.String,System.String,System.String,System.Object)
extern void TPeer_Connect_m11EE8070E8587620C540171BEFC394F270937D9E (void);
// 0x00000335 System.Void ExitGames.Client.Photon.TPeer::OnConnect()
extern void TPeer_OnConnect_mA2AE15A4D17989D9850E4CC29EC74B24A5077C92 (void);
// 0x00000336 System.Void ExitGames.Client.Photon.TPeer::Disconnect()
extern void TPeer_Disconnect_mCC45CECD45E0B01E7E5BB185383B260B1049D494 (void);
// 0x00000337 System.Void ExitGames.Client.Photon.TPeer::StopConnection()
extern void TPeer_StopConnection_m5F73C577E8FCDBEAD992CA73EC5C21F3BEEF1E16 (void);
// 0x00000338 System.Void ExitGames.Client.Photon.TPeer::FetchServerTimestamp()
extern void TPeer_FetchServerTimestamp_m8D2DA7B388BC5776F0F4FCCFB026A09CABF1EE80 (void);
// 0x00000339 System.Void ExitGames.Client.Photon.TPeer::EnqueueInit(System.Byte[])
extern void TPeer_EnqueueInit_m7F9CED6533FFAB3DE884C6CFE5AE6684EE92CC2F (void);
// 0x0000033A System.Boolean ExitGames.Client.Photon.TPeer::DispatchIncomingCommands()
extern void TPeer_DispatchIncomingCommands_mA16275DC611D1E54BC4FBB25AEA9172DEF72C1A4 (void);
// 0x0000033B System.Boolean ExitGames.Client.Photon.TPeer::SendOutgoingCommands()
extern void TPeer_SendOutgoingCommands_mEC0A1C820F055A9F2E806AAF769B83AD809F01C3 (void);
// 0x0000033C System.Boolean ExitGames.Client.Photon.TPeer::SendAcksOnly()
extern void TPeer_SendAcksOnly_m9E2AB7494C35CE49AC8D9DCB30F5A7A45D8ED371 (void);
// 0x0000033D System.Boolean ExitGames.Client.Photon.TPeer::EnqueuePhotonMessage(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.SendOptions)
extern void TPeer_EnqueuePhotonMessage_m8E32860FEA23A0D2799A06380CB2A8437EED8338 (void);
// 0x0000033E System.Boolean ExitGames.Client.Photon.TPeer::EnqueueMessageAsPayload(ExitGames.Client.Photon.DeliveryMode,ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void TPeer_EnqueueMessageAsPayload_m5E6655156E6382425BB131EB858A686B665A94AE (void);
// 0x0000033F System.Void ExitGames.Client.Photon.TPeer::SendPing()
extern void TPeer_SendPing_m17FAFB3761F1AAA35BCAEA0AC15058F04ACDC891 (void);
// 0x00000340 System.Void ExitGames.Client.Photon.TPeer::SendData(System.Byte[],System.Int32)
extern void TPeer_SendData_m9D2A5B81CA25BF2D273259B6E21A8D016EEAC304 (void);
// 0x00000341 System.Void ExitGames.Client.Photon.TPeer::ReceiveIncomingCommands(System.Byte[],System.Int32)
extern void TPeer_ReceiveIncomingCommands_mAAC5886B77F17ED00E9F82DA1EB331BE61B47D40 (void);
// 0x00000342 System.Void ExitGames.Client.Photon.TPeer::ReadPingResult(System.Byte[])
extern void TPeer_ReadPingResult_m21041D75C9316E96AC652AFA5390B1490DCFEB35 (void);
// 0x00000343 System.Void ExitGames.Client.Photon.TPeer::ReadPingResult(ExitGames.Client.Photon.OperationResponse)
extern void TPeer_ReadPingResult_m0BDD6F364B7DD8E1E0D135155F9ED16B2E158408 (void);
// 0x00000344 System.Void ExitGames.Client.Photon.TPeer::.cctor()
extern void TPeer__cctor_m5E259C4C9389F90C0622C8DDE3D1D12FC4543843 (void);
// 0x00000345 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_OperationByteCount()
extern void TrafficStatsGameLevel_get_OperationByteCount_m086A7E5F72C6A007253F619CAA3191EB4C78E914 (void);
// 0x00000346 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_OperationByteCount(System.Int32)
extern void TrafficStatsGameLevel_set_OperationByteCount_mD1AD82B5392459198A0AD2FB6A1A40AE28368C93 (void);
// 0x00000347 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_OperationCount()
extern void TrafficStatsGameLevel_get_OperationCount_mD0FA6651A97EA6536897D9B24B33EC1378010EA8 (void);
// 0x00000348 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_OperationCount(System.Int32)
extern void TrafficStatsGameLevel_set_OperationCount_mE660535935BC321093B76E949C96B65F0511CE56 (void);
// 0x00000349 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_ResultByteCount()
extern void TrafficStatsGameLevel_get_ResultByteCount_m2BA47CF280E2D044126A9F859E83F79F72235ABE (void);
// 0x0000034A System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_ResultByteCount(System.Int32)
extern void TrafficStatsGameLevel_set_ResultByteCount_m79130B5870228D5FF1E1EA4EDE06CDC83A7521B1 (void);
// 0x0000034B System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_ResultCount()
extern void TrafficStatsGameLevel_get_ResultCount_mE96D0080C09F62967746137556E8883B28F719DF (void);
// 0x0000034C System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_ResultCount(System.Int32)
extern void TrafficStatsGameLevel_set_ResultCount_mDFE8B8FD3B2C27E083C8C21C76B92391594DE6C7 (void);
// 0x0000034D System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_EventByteCount()
extern void TrafficStatsGameLevel_get_EventByteCount_m3E3E76F0E4E33509ADD4C25F9CDBE4D30957ABB0 (void);
// 0x0000034E System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_EventByteCount(System.Int32)
extern void TrafficStatsGameLevel_set_EventByteCount_m113F40E2DA8CDCB9EF8E3F40726B2D4BD3464E15 (void);
// 0x0000034F System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_EventCount()
extern void TrafficStatsGameLevel_get_EventCount_mA2F82A89B8B80274BB994B293088984A12BB5FFA (void);
// 0x00000350 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_EventCount(System.Int32)
extern void TrafficStatsGameLevel_set_EventCount_m4AFA89743643BE3CDC141B336776A4EBC06AE573 (void);
// 0x00000351 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestOpResponseCallback()
extern void TrafficStatsGameLevel_get_LongestOpResponseCallback_m93ABE5175296D7A3F12C55964AECB4D98A468437 (void);
// 0x00000352 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestOpResponseCallback(System.Int32)
extern void TrafficStatsGameLevel_set_LongestOpResponseCallback_m3F34F108B0A4D3446FD01F17EDA0D7D504BC4F21 (void);
// 0x00000353 System.Byte ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestOpResponseCallbackOpCode()
extern void TrafficStatsGameLevel_get_LongestOpResponseCallbackOpCode_mF646C104F0D57F26E6C7695CDC46C643C2D8A85B (void);
// 0x00000354 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestOpResponseCallbackOpCode(System.Byte)
extern void TrafficStatsGameLevel_set_LongestOpResponseCallbackOpCode_mED20BE05A576912EE4DB3CB4431EE9C94E5F9572 (void);
// 0x00000355 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestEventCallback()
extern void TrafficStatsGameLevel_get_LongestEventCallback_mCFB892A9DAA383DF5A867C1BAF97F91F9AC2892C (void);
// 0x00000356 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestEventCallback(System.Int32)
extern void TrafficStatsGameLevel_set_LongestEventCallback_m894E046FAC6C54F79AB54D6A1C56B08FB157B3FD (void);
// 0x00000357 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestMessageCallback()
extern void TrafficStatsGameLevel_get_LongestMessageCallback_m2FB5D7572D5F579A26BF5D769344C1DDFDD64C0F (void);
// 0x00000358 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestMessageCallback(System.Int32)
extern void TrafficStatsGameLevel_set_LongestMessageCallback_m8604E721E070E532F9D46941ECFB604C5C363228 (void);
// 0x00000359 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestRawMessageCallback()
extern void TrafficStatsGameLevel_get_LongestRawMessageCallback_m6179ECB340018673BA624517E5F3E957CA9B34F1 (void);
// 0x0000035A System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestRawMessageCallback(System.Int32)
extern void TrafficStatsGameLevel_set_LongestRawMessageCallback_mE9B1FBFE67D6DFCA5E79C4756559D0BC159063B7 (void);
// 0x0000035B System.Byte ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestEventCallbackCode()
extern void TrafficStatsGameLevel_get_LongestEventCallbackCode_m9048920021B7BE2978F807D0C1CC19994EF64BBC (void);
// 0x0000035C System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestEventCallbackCode(System.Byte)
extern void TrafficStatsGameLevel_set_LongestEventCallbackCode_m0467ED6E9B84FB3B730327E72491FF3A87DAE0AE (void);
// 0x0000035D System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestDeltaBetweenDispatching()
extern void TrafficStatsGameLevel_get_LongestDeltaBetweenDispatching_mB8F7ABF7B7DFDF88C4CE6CCC91B1536138B26CA4 (void);
// 0x0000035E System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestDeltaBetweenDispatching(System.Int32)
extern void TrafficStatsGameLevel_set_LongestDeltaBetweenDispatching_m22179901F3200D4681C08C9D2956531B955F0E38 (void);
// 0x0000035F System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestDeltaBetweenSending()
extern void TrafficStatsGameLevel_get_LongestDeltaBetweenSending_mFE6A1F7C968EFA5DCC441B78C0118A26B7AF5E15 (void);
// 0x00000360 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestDeltaBetweenSending(System.Int32)
extern void TrafficStatsGameLevel_set_LongestDeltaBetweenSending_mB238B91A3907CCD9F4FB2F259B55D5D97AAC5CC8 (void);
// 0x00000361 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_DispatchCalls()
extern void TrafficStatsGameLevel_get_DispatchCalls_m985362A23DB1DF8276475506DC5F0993057F0D74 (void);
// 0x00000362 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_DispatchIncomingCommandsCalls()
extern void TrafficStatsGameLevel_get_DispatchIncomingCommandsCalls_m067D46E1430E21CAB6BA11E69A5CD54FC909914D (void);
// 0x00000363 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_DispatchIncomingCommandsCalls(System.Int32)
extern void TrafficStatsGameLevel_set_DispatchIncomingCommandsCalls_m9A1333825C4BE97510FBF0864C1FDB70678B13F9 (void);
// 0x00000364 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_SendOutgoingCommandsCalls()
extern void TrafficStatsGameLevel_get_SendOutgoingCommandsCalls_mECFAA4C1338C3CE34D084954955DAE25ABB3942E (void);
// 0x00000365 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_SendOutgoingCommandsCalls(System.Int32)
extern void TrafficStatsGameLevel_set_SendOutgoingCommandsCalls_mE4D14EB50C26925D3CC405E39EB9540F67BDFB8D (void);
// 0x00000366 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_TotalByteCount()
extern void TrafficStatsGameLevel_get_TotalByteCount_m61C59D944FEA45F6890EC6358FA124D72C6036D5 (void);
// 0x00000367 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_TotalMessageCount()
extern void TrafficStatsGameLevel_get_TotalMessageCount_m09580215C14A7763F34D58CDC1322579281D78AA (void);
// 0x00000368 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_TotalIncomingByteCount()
extern void TrafficStatsGameLevel_get_TotalIncomingByteCount_mD2FC4B90C1819B494F834198BCA1879171263ED8 (void);
// 0x00000369 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_TotalIncomingMessageCount()
extern void TrafficStatsGameLevel_get_TotalIncomingMessageCount_mD4B358D350EB1EA1E70DC9F3BD9C4DE12280F4F9 (void);
// 0x0000036A System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_TotalOutgoingByteCount()
extern void TrafficStatsGameLevel_get_TotalOutgoingByteCount_m1745319A5A651C52EF60CD40E330D08EB6FEB281 (void);
// 0x0000036B System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_TotalOutgoingMessageCount()
extern void TrafficStatsGameLevel_get_TotalOutgoingMessageCount_m4FBE7C7CDD3CEB859CDFFA462E49D7CF4167285C (void);
// 0x0000036C System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::CountOperation(System.Int32)
extern void TrafficStatsGameLevel_CountOperation_mAF25E49F3625B85D4253205BB70ADB7776D3C4BA (void);
// 0x0000036D System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::CountResult(System.Int32)
extern void TrafficStatsGameLevel_CountResult_mDE4D23515A1FA38D9F1A4D20BBB325D12D4ED854 (void);
// 0x0000036E System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::CountEvent(System.Int32)
extern void TrafficStatsGameLevel_CountEvent_m56C7A686D51ADD83721095F1EECA1F7EF2E23F88 (void);
// 0x0000036F System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::TimeForResponseCallback(System.Byte,System.Int32)
extern void TrafficStatsGameLevel_TimeForResponseCallback_m4655B94FDFC5BF288E127638A7F0389C708BBF95 (void);
// 0x00000370 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::TimeForEventCallback(System.Byte,System.Int32)
extern void TrafficStatsGameLevel_TimeForEventCallback_m5B7CEDDA63A03F98206D2D48083F1D6D92EDC594 (void);
// 0x00000371 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::TimeForMessageCallback(System.Int32)
extern void TrafficStatsGameLevel_TimeForMessageCallback_m57439D64362437749BB96BDAB50B9E5ABA8848C1 (void);
// 0x00000372 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::TimeForRawMessageCallback(System.Int32)
extern void TrafficStatsGameLevel_TimeForRawMessageCallback_mE80D0C7E37387D80D1E32EC57A93DB354FDD356F (void);
// 0x00000373 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::DispatchIncomingCommandsCalled()
extern void TrafficStatsGameLevel_DispatchIncomingCommandsCalled_m3E0C3AB4F9C0C8970C598B5160ABE627D2F031FD (void);
// 0x00000374 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::SendOutgoingCommandsCalled()
extern void TrafficStatsGameLevel_SendOutgoingCommandsCalled_m52E73ED4D8C7AF3A1CAFAEDA498574DF43E62661 (void);
// 0x00000375 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::ResetMaximumCounters()
extern void TrafficStatsGameLevel_ResetMaximumCounters_m4B29B200F63BFF61CA88F7FEC034F5D6E9E9C3E4 (void);
// 0x00000376 System.String ExitGames.Client.Photon.TrafficStatsGameLevel::ToString()
extern void TrafficStatsGameLevel_ToString_mC429A8ADC63BE025F7A64E02280FF036E84194C3 (void);
// 0x00000377 System.String ExitGames.Client.Photon.TrafficStatsGameLevel::ToStringVitalStats()
extern void TrafficStatsGameLevel_ToStringVitalStats_m86FBCCC12199B6F28BA5778BFDAF5A0399B96B76 (void);
// 0x00000378 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::.ctor()
extern void TrafficStatsGameLevel__ctor_m71DA010F0631FCDDDE508028B0C42E7157DC79D0 (void);
// 0x00000379 System.Int32 ExitGames.Client.Photon.TrafficStats::get_PackageHeaderSize()
extern void TrafficStats_get_PackageHeaderSize_m1D25FBE1A816E4A827D298A9402C3099A94510C9 (void);
// 0x0000037A System.Void ExitGames.Client.Photon.TrafficStats::set_PackageHeaderSize(System.Int32)
extern void TrafficStats_set_PackageHeaderSize_m19712FF06B25DC18400DE304E403DD8F2D1B8F47 (void);
// 0x0000037B System.Int32 ExitGames.Client.Photon.TrafficStats::get_ReliableCommandCount()
extern void TrafficStats_get_ReliableCommandCount_mBE3A184C7D70373DB0306F93878295FAC75A5F67 (void);
// 0x0000037C System.Void ExitGames.Client.Photon.TrafficStats::set_ReliableCommandCount(System.Int32)
extern void TrafficStats_set_ReliableCommandCount_m9DC554A3C889BDC0A2DE61E6EA3BEAEEC906F192 (void);
// 0x0000037D System.Int32 ExitGames.Client.Photon.TrafficStats::get_UnreliableCommandCount()
extern void TrafficStats_get_UnreliableCommandCount_m3081BE8F9F0731DA8697AA51A95FD60C5B479A03 (void);
// 0x0000037E System.Void ExitGames.Client.Photon.TrafficStats::set_UnreliableCommandCount(System.Int32)
extern void TrafficStats_set_UnreliableCommandCount_mBFAECAEFA858D2E59E99338AFDC4562505A0326E (void);
// 0x0000037F System.Int32 ExitGames.Client.Photon.TrafficStats::get_FragmentCommandCount()
extern void TrafficStats_get_FragmentCommandCount_m14E236EFB0BD1F28FE1662BF89EDD2C8FF8C9A79 (void);
// 0x00000380 System.Void ExitGames.Client.Photon.TrafficStats::set_FragmentCommandCount(System.Int32)
extern void TrafficStats_set_FragmentCommandCount_m4FFD2B1F7FD95A1FD8EE53CC00E73CD2268ACC99 (void);
// 0x00000381 System.Int32 ExitGames.Client.Photon.TrafficStats::get_ControlCommandCount()
extern void TrafficStats_get_ControlCommandCount_m36E3359A94B412A1507A39F0DCCEA3B99550020F (void);
// 0x00000382 System.Void ExitGames.Client.Photon.TrafficStats::set_ControlCommandCount(System.Int32)
extern void TrafficStats_set_ControlCommandCount_mD0EA6ECE6ED42E25057261B7D69EE472C306758E (void);
// 0x00000383 System.Int32 ExitGames.Client.Photon.TrafficStats::get_TotalPacketCount()
extern void TrafficStats_get_TotalPacketCount_m84AD1F6ACA44DCDEEB3D7DDEDD5106D431FBBDC2 (void);
// 0x00000384 System.Void ExitGames.Client.Photon.TrafficStats::set_TotalPacketCount(System.Int32)
extern void TrafficStats_set_TotalPacketCount_mC5A1DB4A8AE80096ACAFC63FF99A3CBEBF269C98 (void);
// 0x00000385 System.Int32 ExitGames.Client.Photon.TrafficStats::get_TotalCommandsInPackets()
extern void TrafficStats_get_TotalCommandsInPackets_m5E47B2625D3BFED27344F06DDBEAC6FCA6D766C5 (void);
// 0x00000386 System.Void ExitGames.Client.Photon.TrafficStats::set_TotalCommandsInPackets(System.Int32)
extern void TrafficStats_set_TotalCommandsInPackets_m370B232CD8889AA6E4D4B1EEF1774EDD6BC994CE (void);
// 0x00000387 System.Int32 ExitGames.Client.Photon.TrafficStats::get_ReliableCommandBytes()
extern void TrafficStats_get_ReliableCommandBytes_m090DC6B8131F0DC3C5744817E3339343BE9B5BD4 (void);
// 0x00000388 System.Void ExitGames.Client.Photon.TrafficStats::set_ReliableCommandBytes(System.Int32)
extern void TrafficStats_set_ReliableCommandBytes_m419D94CCE2B8F80108099055020B8218BB5551B9 (void);
// 0x00000389 System.Int32 ExitGames.Client.Photon.TrafficStats::get_UnreliableCommandBytes()
extern void TrafficStats_get_UnreliableCommandBytes_m89438F439355BA509BC3EBA76B745D52CCAF0CE7 (void);
// 0x0000038A System.Void ExitGames.Client.Photon.TrafficStats::set_UnreliableCommandBytes(System.Int32)
extern void TrafficStats_set_UnreliableCommandBytes_m23502D6EAFBF6A0B1E99D7E168D5CFC1FBF77003 (void);
// 0x0000038B System.Int32 ExitGames.Client.Photon.TrafficStats::get_FragmentCommandBytes()
extern void TrafficStats_get_FragmentCommandBytes_m1A65788B99741445736CC24E4A794B8B0262C680 (void);
// 0x0000038C System.Void ExitGames.Client.Photon.TrafficStats::set_FragmentCommandBytes(System.Int32)
extern void TrafficStats_set_FragmentCommandBytes_m7BA803E436518D0EB4D3AFF6301531CCBE7C6232 (void);
// 0x0000038D System.Int32 ExitGames.Client.Photon.TrafficStats::get_ControlCommandBytes()
extern void TrafficStats_get_ControlCommandBytes_mE9D246D653C6F4EDBA685466EC8A4BE5E7BF03A0 (void);
// 0x0000038E System.Void ExitGames.Client.Photon.TrafficStats::set_ControlCommandBytes(System.Int32)
extern void TrafficStats_set_ControlCommandBytes_m198DDF12387655F1DB8874E6CDE0E1240FB267E1 (void);
// 0x0000038F System.Void ExitGames.Client.Photon.TrafficStats::.ctor(System.Int32)
extern void TrafficStats__ctor_m7A163C8A2322D91D08EA2494558FE98E4A77122D (void);
// 0x00000390 System.Int32 ExitGames.Client.Photon.TrafficStats::get_TotalCommandCount()
extern void TrafficStats_get_TotalCommandCount_mD5AFA9D97FAE04F2B65AD6F803857F5F08E4A1DB (void);
// 0x00000391 System.Int32 ExitGames.Client.Photon.TrafficStats::get_TotalCommandBytes()
extern void TrafficStats_get_TotalCommandBytes_m673E3D70AB03382893BFE55844118814DABE7A59 (void);
// 0x00000392 System.Int32 ExitGames.Client.Photon.TrafficStats::get_TotalPacketBytes()
extern void TrafficStats_get_TotalPacketBytes_m78B80C1327ADF57BF7B60F0F77853B310504D6B9 (void);
// 0x00000393 System.Int32 ExitGames.Client.Photon.TrafficStats::get_TimestampOfLastAck()
extern void TrafficStats_get_TimestampOfLastAck_m8D38D581C2F6EA022C52C970F99DB9F9F2A09ECB (void);
// 0x00000394 System.Void ExitGames.Client.Photon.TrafficStats::set_TimestampOfLastAck(System.Int32)
extern void TrafficStats_set_TimestampOfLastAck_m408B0C0E6ED090884C7753D061709F504F797174 (void);
// 0x00000395 System.Int32 ExitGames.Client.Photon.TrafficStats::get_TimestampOfLastReliableCommand()
extern void TrafficStats_get_TimestampOfLastReliableCommand_m0A94870AAC6A0C00A9C5611C30E8C626F505565E (void);
// 0x00000396 System.Void ExitGames.Client.Photon.TrafficStats::set_TimestampOfLastReliableCommand(System.Int32)
extern void TrafficStats_set_TimestampOfLastReliableCommand_m79BA49951A17159B5FEF0680AB2F486F371D33F7 (void);
// 0x00000397 System.Void ExitGames.Client.Photon.TrafficStats::CountControlCommand(System.Int32)
extern void TrafficStats_CountControlCommand_mA622D5A3E457095819E8C70B7F4F077D29EC7507 (void);
// 0x00000398 System.Void ExitGames.Client.Photon.TrafficStats::CountReliableOpCommand(System.Int32)
extern void TrafficStats_CountReliableOpCommand_m0D47D70C4D06123DFB42DE97969F3600F5965A79 (void);
// 0x00000399 System.Void ExitGames.Client.Photon.TrafficStats::CountUnreliableOpCommand(System.Int32)
extern void TrafficStats_CountUnreliableOpCommand_m7E710A9383D70DC07E75C7116B3B4BE9726FB5BA (void);
// 0x0000039A System.Void ExitGames.Client.Photon.TrafficStats::CountFragmentOpCommand(System.Int32)
extern void TrafficStats_CountFragmentOpCommand_mE91AE8E3CFC81D697BB7F0901C9E02E12A12EB76 (void);
// 0x0000039B System.String ExitGames.Client.Photon.TrafficStats::ToString()
extern void TrafficStats_ToString_mECCBC768029FED503D1FEA6B07FFF9CD1B04F38A (void);
// 0x0000039C System.Void ExitGames.Client.Photon.Version::.cctor()
extern void Version__cctor_mA40B5695C6844031A3374F15754AE95CCDEF8FD1 (void);
// 0x0000039D System.Void ExitGames.Client.Photon.StructWrapping.StructWrapper::.ctor(System.Type,ExitGames.Client.Photon.StructWrapping.WrappedType)
extern void StructWrapper__ctor_mDF1A5F7BDC6A2FF7FAE7F9BE76036198C427EB28 (void);
// 0x0000039E System.Void ExitGames.Client.Photon.StructWrapping.StructWrapper::Dispose()
// 0x0000039F System.String ExitGames.Client.Photon.StructWrapping.StructWrapper::ToString(System.Boolean)
// 0x000003A0 ExitGames.Client.Photon.StructWrapping.StructWrapperPool`1<T> ExitGames.Client.Photon.StructWrapping.StructWrapper`1::get_ReturnPool()
// 0x000003A1 System.Void ExitGames.Client.Photon.StructWrapping.StructWrapper`1::set_ReturnPool(ExitGames.Client.Photon.StructWrapping.StructWrapperPool`1<T>)
// 0x000003A2 System.Void ExitGames.Client.Photon.StructWrapping.StructWrapper`1::.ctor(ExitGames.Client.Photon.StructWrapping.Pooling)
// 0x000003A3 System.Void ExitGames.Client.Photon.StructWrapping.StructWrapper`1::.ctor(ExitGames.Client.Photon.StructWrapping.Pooling,System.Type,ExitGames.Client.Photon.StructWrapping.WrappedType)
// 0x000003A4 T ExitGames.Client.Photon.StructWrapping.StructWrapper`1::Unwrap()
// 0x000003A5 System.Void ExitGames.Client.Photon.StructWrapping.StructWrapper`1::Dispose()
// 0x000003A6 System.String ExitGames.Client.Photon.StructWrapping.StructWrapper`1::ToString()
// 0x000003A7 System.String ExitGames.Client.Photon.StructWrapping.StructWrapper`1::ToString(System.Boolean)
// 0x000003A8 System.Void ExitGames.Client.Photon.StructWrapping.StructWrapper`1::.cctor()
// 0x000003A9 ExitGames.Client.Photon.StructWrapping.WrappedType ExitGames.Client.Photon.StructWrapping.StructWrapperPool::GetWrappedType(System.Type)
extern void StructWrapperPool_GetWrappedType_m8C689F2F9E44119A0507A2EBD44837B492AFACF8 (void);
// 0x000003AA System.Void ExitGames.Client.Photon.StructWrapping.StructWrapperPool::.ctor()
extern void StructWrapperPool__ctor_m81E32623B9398D5D7FDCCE452B8832AB3EAC1C73 (void);
// 0x000003AB System.Void ExitGames.Client.Photon.StructWrapping.StructWrapperPool`1::.ctor(System.Boolean)
// 0x000003AC ExitGames.Client.Photon.StructWrapping.StructWrapper`1<T> ExitGames.Client.Photon.StructWrapping.StructWrapperPool`1::Acquire()
// 0x000003AD ExitGames.Client.Photon.StructWrapping.StructWrapper`1<T> ExitGames.Client.Photon.StructWrapping.StructWrapperPool`1::Acquire(T)
// 0x000003AE System.Void ExitGames.Client.Photon.StructWrapping.StructWrapperPool`1::Release(ExitGames.Client.Photon.StructWrapping.StructWrapper`1<T>)
// 0x000003AF ExitGames.Client.Photon.StructWrapping.StructWrapperPool`1<T> ExitGames.Client.Photon.StructWrapping.StructWrapperPools::GetPoolForType()
// 0x000003B0 ExitGames.Client.Photon.StructWrapping.StructWrapper`1<System.Byte> ExitGames.Client.Photon.StructWrapping.StructWrapperPools::Acquire(System.Byte)
extern void StructWrapperPools_Acquire_m1FE96E54618FCCE9DFFB70D2BBC42E18B556D875 (void);
// 0x000003B1 ExitGames.Client.Photon.StructWrapping.StructWrapper`1<System.Boolean> ExitGames.Client.Photon.StructWrapping.StructWrapperPools::Acquire(System.Boolean)
extern void StructWrapperPools_Acquire_m72323D6359C73C13ABCCB33F06A307BEFF8B1EE4 (void);
// 0x000003B2 ExitGames.Client.Photon.StructWrapping.StructWrapper`1<T> ExitGames.Client.Photon.StructWrapping.StructWrapperPools::Acquire(T)
// 0x000003B3 System.Void ExitGames.Client.Photon.StructWrapping.StructWrapperPools::Clear()
extern void StructWrapperPools_Clear_m0A62D387532994F86DDD519D87ACAE5BE8C0CFA2 (void);
// 0x000003B4 System.Void ExitGames.Client.Photon.StructWrapping.StructWrapperPools::.ctor()
extern void StructWrapperPools__ctor_m65A3AB7112A3EBD740A19838C73328F73A130FA9 (void);
// 0x000003B5 System.Void ExitGames.Client.Photon.StructWrapping.StructWrapperPools::.cctor()
extern void StructWrapperPools__cctor_mE2F4B7AA4E42A618804D8A08BB1080A635776B27 (void);
// 0x000003B6 T ExitGames.Client.Photon.StructWrapping.StructWrapperUtility::Unwrap(System.Object)
// 0x000003B7 T ExitGames.Client.Photon.StructWrapping.StructWrapperUtility::Get(System.Object)
// 0x000003B8 System.Void ExitGames.Client.Photon.Encryption.IPhotonEncryptor::Init(System.Byte[],System.Byte[],System.Byte[],System.Boolean)
// 0x000003B9 System.Void ExitGames.Client.Photon.Encryption.IPhotonEncryptor::Encrypt2(System.Byte[],System.Int32,System.Byte[],System.Byte[],System.Int32,System.Int32&)
// 0x000003BA System.Byte[] ExitGames.Client.Photon.Encryption.IPhotonEncryptor::Decrypt2(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32&)
// 0x000003BB System.Int32 ExitGames.Client.Photon.Encryption.IPhotonEncryptor::CalculateEncryptedSize(System.Int32)
// 0x000003BC System.Int32 ExitGames.Client.Photon.Encryption.IPhotonEncryptor::CalculateFragmentLength()
// 0x000003BD System.Void ExitGames.Client.Photon.Encryption.EncryptorNet::Init(System.Byte[],System.Byte[],System.Byte[],System.Boolean)
extern void EncryptorNet_Init_mB3AEB2F391807AB8DD70A17C2AD91A9AF86BA080 (void);
// 0x000003BE System.Void ExitGames.Client.Photon.Encryption.EncryptorNet::Encrypt2(System.Byte[],System.Int32,System.Byte[],System.Byte[],System.Int32,System.Int32&)
extern void EncryptorNet_Encrypt2_m1B98ECC47D223BF3C800AF472C07F509AD8018CB (void);
// 0x000003BF System.Byte[] ExitGames.Client.Photon.Encryption.EncryptorNet::Decrypt2(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32&)
extern void EncryptorNet_Decrypt2_m16B3D768B5B23A7E6C11E828BD94693B66E8C36E (void);
// 0x000003C0 System.Int32 ExitGames.Client.Photon.Encryption.EncryptorNet::CalculateEncryptedSize(System.Int32)
extern void EncryptorNet_CalculateEncryptedSize_m4BA773EF7C4DC9BCB48C8950086DA9D67B29A2CC (void);
// 0x000003C1 System.Int32 ExitGames.Client.Photon.Encryption.EncryptorNet::CalculateFragmentLength()
extern void EncryptorNet_CalculateFragmentLength_m569F76FAF3CEB6DAD18402D4EA9422C6C6837891 (void);
// 0x000003C2 System.Void ExitGames.Client.Photon.Encryption.EncryptorNet::.ctor()
extern void EncryptorNet__ctor_m7CA333A500C68B8794E3B72505B80F27B204139E (void);
// 0x000003C3 System.IntPtr ExitGames.Client.Photon.Encryption.EncryptorNative::egconstructEncryptor2(System.Byte[],System.Byte[],ExitGames.Client.Photon.Encryption.EncryptorNative_ChainingMode)
extern void EncryptorNative_egconstructEncryptor2_m491CC2D3001AA24B414D223E86533F8D59AB0528 (void);
// 0x000003C4 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::egdestructEncryptor2(System.IntPtr)
extern void EncryptorNative_egdestructEncryptor2_mE6A8D567AD82160BDFDCC9E02E4868BAC2CBE4CB (void);
// 0x000003C5 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::egencrypt2(System.IntPtr,System.Byte[],System.Int32,System.Byte[],System.Byte[],System.Int32,System.Int32&)
extern void EncryptorNative_egencrypt2_mB0688D48E79103AE3E69D7CB4AA5FB81E307567A (void);
// 0x000003C6 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::egdecrypt2(System.IntPtr,System.Byte[],System.Int32,System.Int32,System.Byte[],System.Byte[],System.Int32&)
extern void EncryptorNative_egdecrypt2_mBF8E07E088ADB062E9D9D9202672336E4D24600F (void);
// 0x000003C7 System.Int32 ExitGames.Client.Photon.Encryption.EncryptorNative::egcalculateEncryptedSize(System.IntPtr,System.Int32)
extern void EncryptorNative_egcalculateEncryptedSize_m3AC6FA8308F1F10B9BDBB7D2E1399F120C352F10 (void);
// 0x000003C8 System.Int32 ExitGames.Client.Photon.Encryption.EncryptorNative::egcalculateFragmentLength(System.IntPtr)
extern void EncryptorNative_egcalculateFragmentLength_mE05D0B8AD345196B5D504721F6C5C6D0FAE0B2E2 (void);
// 0x000003C9 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::egsetEncryptorLoggingCallback(System.IntPtr,ExitGames.Client.Photon.Encryption.EncryptorNative_LogCallbackDelegate)
extern void EncryptorNative_egsetEncryptorLoggingCallback_m38437CE892232575891B4E35BD26AA2015E1BA5C (void);
// 0x000003CA System.Boolean ExitGames.Client.Photon.Encryption.EncryptorNative::egsetEncryptorLoggingLevel(System.Int32)
extern void EncryptorNative_egsetEncryptorLoggingLevel_m51CFAADE7666EFBAB4B5A7845C6821D39AFF922C (void);
// 0x000003CB System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::Finalize()
extern void EncryptorNative_Finalize_mB984258D126DBF34F2E11AE8B941D1127F62AE86 (void);
// 0x000003CC System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::OnNativeLog(System.IntPtr,System.Int32,System.String)
extern void EncryptorNative_OnNativeLog_m093EEF0A12F4E92917B10950998C3B705BF1CD8C (void);
// 0x000003CD System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::Init(System.Byte[],System.Byte[],System.Byte[],System.Boolean)
extern void EncryptorNative_Init_m59609AFE78A2ECA3DF9E848103CA39AA83CDE9F2 (void);
// 0x000003CE System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::Dispose(System.Boolean)
extern void EncryptorNative_Dispose_m3AB10BC670FB517D512821075218F9EFA64DEF05 (void);
// 0x000003CF System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::Encrypt2(System.Byte[],System.Int32,System.Byte[],System.Byte[],System.Int32,System.Int32&)
extern void EncryptorNative_Encrypt2_m75CCAE5E86EF7A714C4674DC0FB4BBDC54388FEE (void);
// 0x000003D0 System.Byte[] ExitGames.Client.Photon.Encryption.EncryptorNative::Decrypt2(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32&)
extern void EncryptorNative_Decrypt2_m86A5523A0D47C2C92B5A49F12F73675211ED653D (void);
// 0x000003D1 System.Int32 ExitGames.Client.Photon.Encryption.EncryptorNative::CalculateEncryptedSize(System.Int32)
extern void EncryptorNative_CalculateEncryptedSize_m9ACD15490323D9F745BFC93513F363F87EA607C9 (void);
// 0x000003D2 System.Int32 ExitGames.Client.Photon.Encryption.EncryptorNative::CalculateFragmentLength()
extern void EncryptorNative_CalculateFragmentLength_m44A8E3B8981C6D00009DE009DB23D9E09342242D (void);
// 0x000003D3 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::.ctor()
extern void EncryptorNative__ctor_m30F847B8DA38EDFD8E2FB6023DB92F6B6F5B9888 (void);
// 0x000003D4 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative_LogCallbackDelegate::.ctor(System.Object,System.IntPtr)
extern void LogCallbackDelegate__ctor_mAB26F158E9641F0FAB4056DF05F8A2C1372C2D31 (void);
// 0x000003D5 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative_LogCallbackDelegate::Invoke(System.IntPtr,System.Int32,System.String)
extern void LogCallbackDelegate_Invoke_m4EC3369D43980E37AB72C2A633B089F847E4493F (void);
// 0x000003D6 System.IAsyncResult ExitGames.Client.Photon.Encryption.EncryptorNative_LogCallbackDelegate::BeginInvoke(System.IntPtr,System.Int32,System.String,System.AsyncCallback,System.Object)
extern void LogCallbackDelegate_BeginInvoke_m14EEBF9555D61CE0FDBC4877EC891A6A2973CF7E (void);
// 0x000003D7 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative_LogCallbackDelegate::EndInvoke(System.IAsyncResult)
extern void LogCallbackDelegate_EndInvoke_m91E9CDA8458555C51EEF6D0D355A8873CF2ADA8F (void);
// 0x000003D8 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::.ctor()
extern void DiffieHellmanCryptoProvider__ctor_m12546E890659882808EA2FB4C7F2E92AD6A18B09 (void);
// 0x000003D9 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::.ctor(System.Byte[])
extern void DiffieHellmanCryptoProvider__ctor_mBD6D5FE5B4E8B526062019D037576EAAF5C1678C (void);
// 0x000003DA System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProvider::get_PublicKey()
extern void DiffieHellmanCryptoProvider_get_PublicKey_m1100C1EE0915221FA8AB3ADC4D290F4E6579240B (void);
// 0x000003DB System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::DeriveSharedKey(System.Byte[])
extern void DiffieHellmanCryptoProvider_DeriveSharedKey_m0324A6629DAA697603DDBCAD8D22CCC0BD9DB4FC (void);
// 0x000003DC System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProvider::PhotonBigIntArrayToMsBigIntArray(System.Byte[])
extern void DiffieHellmanCryptoProvider_PhotonBigIntArrayToMsBigIntArray_m3251E72D58580BA854D8DE38D0ECAAA9ADAC5FEA (void);
// 0x000003DD System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProvider::MsBigIntArrayToPhotonBigIntArray(System.Byte[])
extern void DiffieHellmanCryptoProvider_MsBigIntArrayToPhotonBigIntArray_m160F47B4CBA17BA27FE0B30831B6716AD6D831EA (void);
// 0x000003DE System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProvider::Encrypt(System.Byte[],System.Int32,System.Int32)
extern void DiffieHellmanCryptoProvider_Encrypt_mC1C2C023BBFF0349E83E82D360A9764EDB8F524F (void);
// 0x000003DF System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProvider::Decrypt(System.Byte[],System.Int32,System.Int32)
extern void DiffieHellmanCryptoProvider_Decrypt_mD41BE4F0E12B0B13D31B9F77A3F8466ABE206B61 (void);
// 0x000003E0 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::Dispose()
extern void DiffieHellmanCryptoProvider_Dispose_mC169C6044BA837B4340DBAD10A2EDFA9D91B16B0 (void);
// 0x000003E1 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::Dispose(System.Boolean)
extern void DiffieHellmanCryptoProvider_Dispose_m017715B932D4628BB3A4D4C55763AEA2952402F3 (void);
// 0x000003E2 System.Numerics.BigInteger Photon.SocketServer.Security.DiffieHellmanCryptoProvider::CalculatePublicKey()
extern void DiffieHellmanCryptoProvider_CalculatePublicKey_m06288E8A57765AC8D2080A043F2213B58F41E2BC (void);
// 0x000003E3 System.Numerics.BigInteger Photon.SocketServer.Security.DiffieHellmanCryptoProvider::CalculateSharedKey(System.Numerics.BigInteger)
extern void DiffieHellmanCryptoProvider_CalculateSharedKey_m83B163A6D73BF92A9371449A615B1F7DA24B4993 (void);
// 0x000003E4 System.Numerics.BigInteger Photon.SocketServer.Security.DiffieHellmanCryptoProvider::GenerateRandomSecret(System.Int32)
extern void DiffieHellmanCryptoProvider_GenerateRandomSecret_m8F36E8967F63FCC371AF486F31AA6DB20E9EEB02 (void);
// 0x000003E5 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::.cctor()
extern void DiffieHellmanCryptoProvider__cctor_m8414DF0E61471D5B09CD270F39E9717C831965AE (void);
// 0x000003E6 System.IntPtr Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorCreate()
extern void DiffieHellmanCryptoProviderNative_egCryptorCreate_m3DC38F64F637F7FD894B86135F56D7FC5B35EC7F (void);
// 0x000003E7 System.Int32 Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorPublicKey(System.IntPtr,System.IntPtr&,System.Int32&)
extern void DiffieHellmanCryptoProviderNative_egCryptorPublicKey_mEDDB2BFCCCC9F4B048D3E3A8C64ADA849384A9E7 (void);
// 0x000003E8 System.Int32 Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorDeriveSharedKey(System.IntPtr,System.Byte[],System.Int32)
extern void DiffieHellmanCryptoProviderNative_egCryptorDeriveSharedKey_m5AD75715D60C9B5A0E8A769B9BC038AE0E6D2B39 (void);
// 0x000003E9 System.Int32 Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorEncrypt(System.IntPtr,System.Byte[],System.Int32,System.Int32,System.Byte[],System.IntPtr&,System.Int32&)
extern void DiffieHellmanCryptoProviderNative_egCryptorEncrypt_mF568D41A720505CE759ADC90C8BA368211E03DA7 (void);
// 0x000003EA System.Int32 Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorDecrypt(System.IntPtr,System.Byte[],System.Int32,System.Int32,System.Byte[],System.IntPtr&,System.Int32&)
extern void DiffieHellmanCryptoProviderNative_egCryptorDecrypt_m95D5D321050D438953BE392F01C6D68C90E66360 (void);
// 0x000003EB System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorDispose(System.IntPtr)
extern void DiffieHellmanCryptoProviderNative_egCryptorDispose_mADF8497109F276A7E5658757DDC4AAEF4C7588D5 (void);
// 0x000003EC System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::.ctor()
extern void DiffieHellmanCryptoProviderNative__ctor_m9A198E38889D06526A3970477C85A1BB8045842A (void);
// 0x000003ED System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::.ctor(System.Byte[])
extern void DiffieHellmanCryptoProviderNative__ctor_mF88DC9A37C3A1B024B4FE2E51AFA9F705EC6F9B5 (void);
// 0x000003EE System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::get_PublicKey()
extern void DiffieHellmanCryptoProviderNative_get_PublicKey_m3E3960BFAED78C91100340A7969E9CB1FC8A6243 (void);
// 0x000003EF System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::DeriveSharedKey(System.Byte[])
extern void DiffieHellmanCryptoProviderNative_DeriveSharedKey_m3519AA51CC9FB72A6239FB82F031CEBB8E7DED74 (void);
// 0x000003F0 System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::Encrypt(System.Byte[],System.Int32,System.Int32)
extern void DiffieHellmanCryptoProviderNative_Encrypt_mF2CB0558E4A9C93FAADD93FBD4FF7A49667771C3 (void);
// 0x000003F1 System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::Decrypt(System.Byte[],System.Int32,System.Int32)
extern void DiffieHellmanCryptoProviderNative_Decrypt_m1DD5CAEF7C7AE3290DD975DF804D92EDF4079470 (void);
// 0x000003F2 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::Dispose()
extern void DiffieHellmanCryptoProviderNative_Dispose_m8C3A676A922E136C18D3AB6171ECC52D3DD4DE05 (void);
// 0x000003F3 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::Dispose(System.Boolean)
extern void DiffieHellmanCryptoProviderNative_Dispose_mE26025BCDD413431A5374D11070EB266CE717BD6 (void);
// 0x000003F4 System.Byte[] Photon.SocketServer.Security.ICryptoProvider::get_PublicKey()
// 0x000003F5 System.Void Photon.SocketServer.Security.ICryptoProvider::DeriveSharedKey(System.Byte[])
// 0x000003F6 System.Byte[] Photon.SocketServer.Security.ICryptoProvider::Encrypt(System.Byte[],System.Int32,System.Int32)
// 0x000003F7 System.Byte[] Photon.SocketServer.Security.ICryptoProvider::Decrypt(System.Byte[],System.Int32,System.Int32)
// 0x000003F8 System.Void Photon.SocketServer.Security.OakleyGroups::.cctor()
extern void OakleyGroups__cctor_mE0A83D3A98A3D1874821B8DBCA377AE0FB075BDD (void);
static Il2CppMethodPointer s_methodPointers[1016] = 
{
	ByteArraySlice__ctor_m95E921AE77478309149A41A2B34EB4099DB6B693,
	ByteArraySlice__ctor_mCA1F121BC54CAD54356FF8E244FF982E7C9F4A0C,
	ByteArraySlice__ctor_m52E75007027C0D2206B592129520A6B8BF910971,
	ByteArraySlice_Dispose_mD49ED18A23C465947805671BCC35397FAFF296B4,
	ByteArraySlice_Release_m36763938B2E6D82E835210D8539D155E0DCB0358,
	ByteArraySlice_Reset_mDD7E41A520B6990FE03D61F4B1270BCAA0DFCBAC,
	ByteArraySlicePool_get_MinStackIndex_m51B942226EA8AA807D181B9A46A4DD04CF17C479,
	ByteArraySlicePool_set_MinStackIndex_mB6847C0452EAA5DCE25D8F45AFD7C818A7DBEBD8,
	ByteArraySlicePool_get_AllocationCounter_mA563AF605FEE8D0FC4A149E33EC231017658B253,
	ByteArraySlicePool__ctor_m45CA6BE6C2A8713064CDD3EC5EA5B5E84C7B1EF7,
	ByteArraySlicePool_Acquire_m7D5BA7113E8BCAB2B00997EB700361DDB974455F,
	ByteArraySlicePool_Acquire_m6C2FF6BD59562952E4172A910B70C0F61DB6ADA9,
	ByteArraySlicePool_Acquire_mD0F964F307C39FEFD8EBDF8A7CC2B53295C1EAF4,
	ByteArraySlicePool_Release_mA25ACFF5C6C708879983C733D73462279D03030D,
	ByteArraySlicePool_ClearPools_m9BE9DDC19085D7CB3DB9034EDBDA364A9D66D341,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Hashtable_GetBoxedByte_mF882A93166D1A48E0C1F7A7DF0310A096CFEEDED,
	Hashtable__cctor_mCAA756BDCDCFBC823F7E43611D66DE7085196F25,
	Hashtable__ctor_mB089FC557FD6D697B39AFB4FF9D70E85DE37B088,
	Hashtable__ctor_mC0B2B8F1A232989295993C9B6C3DBB8F6482040F,
	Hashtable_get_Item_mC48FD527A6399AB799754650D4AAC398CB432EF9,
	Hashtable_set_Item_mF5FF682E1D19685B7451AABF5266291D2BCE9EC3,
	Hashtable_get_Item_mEBAA564FE8E5B5564818A64F6530F876BEB84658,
	Hashtable_set_Item_mDAB28D1FDD5D4639E2CB89E3FDE428068FE40438,
	Hashtable_Add_mF47F17AD082827648493398B7C98E8AE10743FA6,
	Hashtable_Remove_mEC679EEEA51959549DDCDD55AAD1ED1BA55733DB,
	Hashtable_ContainsKey_mDCA3BB08E0C2C4EA1477E7EF9FE9DCB187A39107,
	Hashtable_GetEnumerator_m59F3AAA904C72C689B596BCFAC9C89FFC76C57A3,
	Hashtable_ToString_m9D89125CC08F6AAFD4722EB7E9939BA45D60A809,
	Hashtable_Clone_mF4B598D0C782D589AFBBF675128412437219D343,
	DictionaryEntryEnumerator__ctor_m03C0784DFEAFC5E7A8D953C35F9CD0BC8B80CF03,
	DictionaryEntryEnumerator_MoveNext_mF75DB872E5617670FC63AE8198D6CB99793561DF,
	DictionaryEntryEnumerator_Reset_m95E84677DABB7CEDE1CFC9335A43EED48FDC5E40,
	DictionaryEntryEnumerator_System_Collections_IEnumerator_get_Current_m8D5744C762D8A17E735557DBC7BD6BE53FB2A7D3,
	DictionaryEntryEnumerator_get_Current_mC652CE08C853BAA299C02233F3B7D0B1F303AE66,
	DictionaryEntryEnumerator_get_Key_mC61AE0F4BA19098B0DDC0944764F9F2ACD2A250C,
	DictionaryEntryEnumerator_get_Value_mA252F5A7AB9A3196DCC0FEEB6020643C7AF10961,
	DictionaryEntryEnumerator_get_Entry_m269EE75BD5400BA8789620442EC43D647D9FBCCB,
	DictionaryEntryEnumerator_Dispose_m8507E3836FBA32A62D3D509EEE8D41219096659C,
	EnetChannel__ctor_mDECAC92CC7EE30013B090D2DC8D344CA301580AA,
	EnetChannel_ContainsUnreliableSequenceNumber_m585106810BCFDFEAB262094F1041046C1E7E1C62,
	EnetChannel_FetchUnreliableSequenceNumber_m9DF237427C09EF366DE13886614B5973AE9A0616,
	EnetChannel_ContainsReliableSequenceNumber_mAB7BDEAD2C2A63BB5766F9FF424AA8C3F0D85C55,
	EnetChannel_FetchReliableSequenceNumber_mC530521EFB7F63791B66221614E18272EE52B560,
	EnetChannel_TryGetFragment_m5DD7970BF21196715AF6F7B06B2F092A80EB718C,
	EnetChannel_RemoveFragment_m4B4E5F72BA0C07CBE745241B98D11C7B4BE4CB37,
	EnetChannel_clearAll_mC663C97BD7286F18603A2C4AC6F8A3D71F9F0F0A,
	EnetChannel_QueueIncomingReliableUnsequenced_m62C9B1711DE9569EEB6A505D4F1CA6A02CDBACDD,
	EnetPeer_get_QueuedIncomingCommandsCount_m7A99149655C89D667086D647115E94B18E3650A6,
	EnetPeer_get_QueuedOutgoingCommandsCount_mF50AA08247746EA9ADF321B4E5004A14DF2A2518,
	EnetPeer_get_SentReliableCommandsCount_m933DB6A02FB27C3461B364DFC2DCCDE72FC57E4D,
	EnetPeer__ctor_m45A1D980D6A4499CFE49C8C755170C4DBA0F4B07,
	EnetPeer_IsTransportEncrypted_m4A6F5E1FDE745DDDF596EC8076B8832E8D538EEA,
	EnetPeer_Reset_m2069B81329E551B4C4C2494C8C0C017AA9378232,
	EnetPeer_ApplyRandomizedSequenceNumbers_mF1B2D0AF61EC5C69010C040EC8D534C0AE623095,
	EnetPeer_GetChannel_m2E8BAF2BFEAC85BB7C337B070FECFCCB38016301,
	EnetPeer_Connect_m709286589D9743EDEE81D8CC8F5B7C5A7DA1AC96,
	EnetPeer_OnConnect_mC434A403507850CC3195F3CD8AC5AD60B0C5A635,
	EnetPeer_Disconnect_mAB877BAC4105B93BD7E351BC258779B3BB7BB019,
	EnetPeer_StopConnection_mB29F7A4BE573D0D402C54A53062F2F530C37047D,
	EnetPeer_FetchServerTimestamp_m9B3A7F4A311323043424CFD7D19CC3C17F8D1DF7,
	EnetPeer_DispatchIncomingCommands_m77D0D5174F51EA8A1F337CD9FC9B1F28EF0B915A,
	EnetPeer_GetFragmentLength_mD3DD2ECE7CC2580CC985F819CEAAB5F01C622490,
	EnetPeer_CalculatePacketSize_mE5C5A2E9A2F72E8B164CCDE9AF483555121555F4,
	EnetPeer_CalculateInitialOffset_m973B17063C88C11B231E3A39F045B89E01B3896F,
	EnetPeer_SendAcksOnly_m5037A4496FBEBFA5A23F539DC130684039F0F56F,
	EnetPeer_SendOutgoingCommands_m36CA883DEBFDDD2720037A9698333D8E8B73609C,
	EnetPeer_AreReliableCommandsInTransit_m1902478CAAA80C6EA400159AFC25903B70B68B3C,
	EnetPeer_EnqueuePhotonMessage_mC6D5C00A8FEE316621C24E9BDEF0671FEF0D2BFE,
	EnetPeer_CreateAndEnqueueCommand_m7F95FE38B790BC4D88C6CE9CF359EB05ADB1BEBD,
	EnetPeer_SerializeAckToBuffer_mB259D00A28AECF4E4C0F7CCBC15B7EBD08FC8D0A,
	EnetPeer_SerializeToBuffer_m9EFFAD52286BFDC225572E822CFEEC1CA8D86B25,
	EnetPeer_SendData_mAD63B2BBDCE7C60F4F5C5902DA4A35C91EAB8E5A,
	EnetPeer_SendToSocket_mCE7DF56445E13679699278C7785296584B297402,
	EnetPeer_SendDataEncrypted_m403492FFA26E5A06C813C80359D7A22213516CD3,
	EnetPeer_QueueSentCommand_m3BFB742ECC74B300B062F5085370D8C3D55F59A0,
	EnetPeer_QueueOutgoingReliableCommand_m1EE185F0743F905FE912D08199B18CB4810059F5,
	EnetPeer_QueueOutgoingUnreliableCommand_mAF7004F33D7063698D75E62BF0EF1C2E2DDE5B5F,
	EnetPeer_QueueOutgoingAcknowledgement_m5AE05DD3B5708F09F63FB09AFB34555BEEC10DC9,
	EnetPeer_ReceiveIncomingCommands_m7AD36F532926FBB0BDD5276E76E06A7A56E0761D,
	EnetPeer_ExecuteCommand_m37713580633028964C2A5323AAF378C1027EE232,
	EnetPeer_QueueIncomingCommand_m75F50B0FB77477EB30A1CCFCACBC3D98EA4463FF,
	EnetPeer_RemoveSentReliableCommand_mB54F4B84CAAFF96CE8EC830310E26B78052F3901,
	EnetPeer_CommandListToString_m7A1DAD749BAD2BC17AE0C233FC1C814E568601D1,
	EnetPeer__cctor_m6AFDD29A22CFC5E3454C757CCAEDD99FCD43EE84,
	EnetPeer_U3CExecuteCommandU3Eb__66_0_m448874D2AA4EDA6C3F9C428DF89D441B2B6E0F78,
	NULL,
	NULL,
	NULL,
	NULL,
	IPhotonSocket_get_Listener_m7CFA610DF796ED179ED62179509BFA5DE06ABC74,
	IPhotonSocket_get_MTU_mC44CA042574F0BC945782126B8C27125CBF755D0,
	IPhotonSocket_get_State_mD9AB135F98DD72499F910819560E3A56669567E6,
	IPhotonSocket_set_State_mEF43882322161D6DF457B8888185A2E825583A99,
	IPhotonSocket_get_Connected_m356CE78036AF9A4618195937E5BEA0A9865A4F9B,
	IPhotonSocket_get_ServerAddress_mA5AB6B7A162F657613FCA2783237DE147B041F3B,
	IPhotonSocket_set_ServerAddress_m7B1006418167CE1C679227AF7128D29259DE20FE,
	IPhotonSocket_get_ProxyServerAddress_mB1E62D31E7F91B7B04D8364E239FDF91A3078538,
	IPhotonSocket_set_ProxyServerAddress_m1400E408C64B9FDF925577FAF05E4C7869C280E1,
	IPhotonSocket_get_ServerIpAddress_m64742FBD4CA0C3105F9C323B2866AAEA281BDD96,
	IPhotonSocket_set_ServerIpAddress_m0B6C227D9722E0E1D1A4EC7476357FE2B09B47BC,
	IPhotonSocket_get_ServerPort_mD8B3BC1BB71CB40997C173C220EFCB241BDB8449,
	IPhotonSocket_set_ServerPort_m33DDD60B4056ED444AFE34AB059A125E3A46122E,
	IPhotonSocket_get_AddressResolvedAsIpv6_mC9BDB92DF61BE495906070CE4B03C764F0245DC8,
	IPhotonSocket_set_AddressResolvedAsIpv6_m2960FDE4B84F6907BFD0BCD940F4BB456F7412B3,
	IPhotonSocket_get_UrlProtocol_m86E8F0FBBF0086C2D09ADF5D4E7DDD98D2004D88,
	IPhotonSocket_set_UrlProtocol_m3A7C82D2489C70707745274B84613913A6C06B9B,
	IPhotonSocket_get_UrlPath_m06F1C599E5CECECE1F9FE877A3C7DE0ECD7AE9E6,
	IPhotonSocket_set_UrlPath_m8DC227CD6A8CDD360850C35C856D9EDDA8B165F0,
	IPhotonSocket_get_SerializationProtocol_m7FBB47DA69A1A8F4929A1BF625D2CC58C9492083,
	IPhotonSocket__ctor_mE056977E4ABF8D825769957097BF00FBF3B92127,
	IPhotonSocket_Connect_mCAEA0DACFE4E2EA057BA9F0B6154823A4F4843A1,
	NULL,
	NULL,
	NULL,
	IPhotonSocket_HandleReceivedDatagram_m78ED899FE11D7AC121B55B6EF487E689729F388C,
	IPhotonSocket_ReportDebugOfLevel_m42B7A34B2A760CA559E48D9E22CB28B0E87DEB51,
	IPhotonSocket_EnqueueDebugReturn_mF56E7F4758AFE8CED4C051C28D687754CE92E4BC,
	IPhotonSocket_HandleException_mBD5906834CA0860520827A30D71970F2F533F032,
	IPhotonSocket_TryParseAddress_mB8A55C8DF5A977D2C4539923C2A3185A7DF7EAC9,
	IPhotonSocket_IpAddressTryParse_m7FC012A2DBA260FF63376C6F5D400B9634BEA22A,
	IPhotonSocket_GetIpAddresses_mF9228DAE21109CFE4F12DEF27CA5629AFEE89AD7,
	IPhotonSocket_AddressSortComparer_m001457474D03F9CC1B2E153E9E3AF54DBDA25A2C,
	IPhotonSocket_GetIpAddress_mC2AFD505F79D4B491D4CC30F29EA415AC6143081,
	IPhotonSocket_U3CHandleExceptionU3Eb__52_0_mFCF52B8AB45CAFA6D699C75F76D1A04AE38E2CA5,
	U3CU3Ec__cctor_m84A0AA5DEBEF55FF34678B8A25053F4356ECE5F6,
	U3CU3Ec__ctor_m2DC6E88857116A70E8BBE90D855EFC747D9513F0,
	U3CU3Ec_U3CGetIpAddressesU3Eb__55_0_m2E72D50540242120DC5420B230CD2BC722C4E50A,
	SerializationProtocolFactory_Create_m828411AF46F8D23FA6992DCECECC19C71512F91A,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	IProtocol_Serialize_mE36283E280487E33758F993A98FD77E7444B3A7D,
	IProtocol_Deserialize_m421744AC949C962A7ED4FA51C5288A8FC7098CBC,
	IProtocol_Deserialize_m91D6DE9AD7F486D6EEA1CBDA60EA64C111678CA7,
	IProtocol_DeserializeMessage_m0FF19BA502FB23788851D24B449572E461574F8C,
	IProtocol_SerializeMessage_mFCA6D708093FF14AE91F9719B18D5021902E837A,
	IProtocol__ctor_mC1A6763F4AC0FAD207A96EE314767E45CB35A2ED,
	NULL,
	NULL,
	NULL,
	NCommandPool_Acquire_m034BEAA7EEDAB0441235A095ECBE25E638647029,
	NCommandPool_Acquire_mE3833B289E40184616ABD0F0AF6B7CDDB2216F01,
	NCommandPool_Release_m50E5DD59ABBA5EAA06DD46EB6A15880F12FD8EFE,
	NCommandPool__ctor_m6D1F0DB9DA198E389FA0D2D09832F91D4A0663E1,
	NCommand_get_SizeOfPayload_mE715C222EF4476056DF1471B5DF9D6991B14A8ED,
	NCommand_get_IsFlaggedUnsequenced_m568A51F3AFC3B6FE78BD5BF7B640BD05DB9E2B90,
	NCommand_get_IsFlaggedReliable_m7F4045E61D3C3FA6925BC7FE5D742EB329858525,
	NCommand_CreateAck_m2ADE0341B41E7E14E578E0E61D4A4C77EF034E0A,
	NCommand__ctor_mA134B38B05DA8E71D6E9E3A5D81DAE2EB04CAC88,
	NCommand_Initialize_m7EB458A2A7EC2EB0599D38E1320E1B1AF8F3C5BA,
	NCommand__ctor_mCCF2652E29B7C3A0B5A530BE08CB5B6D3CD38B50,
	NCommand_Initialize_m30F530D6A6E57B4A413761BAA814039542E277EB,
	NCommand_Reset_mBC61BFE8E57D782D72726A1461822CE2B4407E80,
	NCommand_SerializeHeader_mA5E87B8D648794E0AF8D0CE8C6C88F403A484B82,
	NCommand_Serialize_mA5B2F00F5474AE4F4A1E06D71559BACC9AF5624C,
	NCommand_FreePayload_mA5F75525FD735957EB941B508AFDB078A903AC6E,
	NCommand_Release_m9F4BDC65F40BEB47847E7F2A9F2DCE71D498D2F7,
	NCommand_CompareTo_m25236EF216DBCED568899B9FADE1C839ECC966EF,
	NCommand_ToString_m4F8538A56BCD5008746DD85F7932D627D45AC034,
	SimulationItem__ctor_mB8D0480360EB2B0AE2A6E0B00B3ED82061966998,
	SimulationItem_get_Delay_m992E38FB5B1CE1CED810A3600507EBF256B3F941,
	SimulationItem_set_Delay_m20FFD2B127A1CACACE7E0211A42BB43C909B592B,
	NetworkSimulationSet_get_IsSimulationEnabled_m47618A34244193AE829DE9B8E858CE328EE472A4,
	NetworkSimulationSet_set_IsSimulationEnabled_mF0B2D88CA13EBBD72783E6FEA6906069B5DE87E2,
	NetworkSimulationSet_get_OutgoingLag_m1D497FC0EC1D765A929804EBA791A057DCD985C9,
	NetworkSimulationSet_set_OutgoingLag_m115104A9606EFD6C1AC71DA697EA91BDA8356728,
	NetworkSimulationSet_get_OutgoingJitter_mF78EF15C69B1B0197AC359A9299955061480A166,
	NetworkSimulationSet_set_OutgoingJitter_mADBCB529A1F67F9CF10B779AF01B3191455F0A97,
	NetworkSimulationSet_get_OutgoingLossPercentage_mC93121324017E776937D3107C88D49C1E842A938,
	NetworkSimulationSet_set_OutgoingLossPercentage_m276DD42229AA08EFC4AC089C62EDCB1ADAD2CC4E,
	NetworkSimulationSet_get_IncomingLag_mCF5C3C95B9BF351C082614516F9BCDC9F5C9E593,
	NetworkSimulationSet_set_IncomingLag_mD8A8C824A65DCA9999464B52FDB816A89966BBCF,
	NetworkSimulationSet_get_IncomingJitter_mA8D155C61FF951A0ADC0D898B26173D87C515C27,
	NetworkSimulationSet_set_IncomingJitter_m7A102D778F9A7D02E7B69FF6C29632478CE3DFB5,
	NetworkSimulationSet_get_IncomingLossPercentage_m42AF5F432276068AA7B4BF4DE9F9E0D00B8CFA3A,
	NetworkSimulationSet_set_IncomingLossPercentage_m53495F0DB5FDF95281F15A597CADE01D2D3274D5,
	NetworkSimulationSet_get_LostPackagesOut_m76460DE18DD3CA7D7F143655A391AEF1A5B0993B,
	NetworkSimulationSet_set_LostPackagesOut_m2B350E2F46E65E7F3E2727C1658C5DF522FC0D22,
	NetworkSimulationSet_get_LostPackagesIn_mF9BE67E3A3C2D7B1046CA2D7E51C3B80D2B65DFC,
	NetworkSimulationSet_set_LostPackagesIn_m2E37ECD65D991774806793C6D1BAE9B06FF79A3F,
	NetworkSimulationSet_ToString_mFFAF45B81FEEF35C48269E525F292F677F1D2733,
	NetworkSimulationSet__ctor_mAA4F85C0AEB7213D220F4A24F90F134E71B214BC,
	ParameterDictionary__ctor_m8B49AB5AEB9C55CE7185C69BA6C59ECE68CB61DF,
	ParameterDictionary__ctor_m6900EE93057F3DF22FCE07CFF157E57D36512423,
	ParameterDictionary_op_Implicit_m1B42BEC6E2D2CE44E2BBFF21006B0B7EB9815EB9,
	ParameterDictionary_get_Item_m1D37EB387177C5154937E23B8BEBF97FC1B72F71,
	ParameterDictionary_set_Item_mF07CA6A013F2881B79E3B2115214589087741BEF,
	ParameterDictionary_get_Count_m488B3EBF29B916257B82BDF42DC9344A161EFFDF,
	ParameterDictionary_Clear_m13B7A2459B37EC6BEB16D8772DC3F420C9F278A4,
	ParameterDictionary_Add_mF03F5FAA71BC7F0BD89C706964592C09EF18B31E,
	ParameterDictionary_Add_mBAB093D7885A2E18269ABD1132B39A2743CC9B4C,
	ParameterDictionary_Add_m6ED0FBED94C1D912678D23AABA40EDE7D6B26A49,
	ParameterDictionary_Add_mF03786DF05797C61052CDC5E9E2E9A1D6C7A3AA6,
	ParameterDictionary_Add_mFDD4FCCB62F4B75E781C96E5BA2B5AAF64A5337D,
	ParameterDictionary_Add_m20EA3893BFC308C70A07390B90A379EC0323BED7,
	ParameterDictionary_Add_m2BBF93B32D483E2CB6D4D0EBC9832A45A7122C75,
	ParameterDictionary_Add_m3F1A06F00F20F42C3B87ED370B4B57C2205EE2A0,
	NULL,
	NULL,
	ParameterDictionary_ContainsKey_m7FF5DC8A8B0A97143B303A195EDBA8AFC634B4C4,
	ParameterDictionary_TryGetObject_mAF0C3E9ACFFAFF7384DDDE581A7C06C94FA87E49,
	ParameterDictionary_TryGetValue_mFF3D9727D9763C52EC1784956D3F96A36F06819E,
	NULL,
	ParameterDictionary_GetEnumerator_m23B3039379C809BD0D6CF9AA24EEC6A29E9EC143,
	ParameterDictionary_ToStringFull_mBC9D3ACAC94C11789840F08F7F683A906F0D75D6,
	KeyValuePair__ctor_m4E445DB86086ABB6508DBA097900C06CBEEF4D11_AdjustorThunk,
	KeyValuePair_get_Current_m6EBA06DEDA08F64CAF4B8796AB901A9D4C8ED947_AdjustorThunk,
	KeyValuePair_MoveNext_mB9769FAF69400820D54D2A5C590DD1C02E71A66E_AdjustorThunk,
	PhotonCodes__cctor_mBBD974B4BC67C38543F4FE015484FF0E8A8694B3,
	PeerBase_get_ServerAddress_m10944D189D17F5DCA7F729BCC5C9157C1560309E,
	PeerBase_set_ServerAddress_m24011D39B9330A075D6A3E44240B73E5222ABD6A,
	PeerBase_get_ProxyServerAddress_mBE0574FE50C191F0866A35B6776813EC95EE4919,
	PeerBase_set_ProxyServerAddress_m264AFBC59E0F679449B38D7649874594EF3F123F,
	PeerBase_get_Listener_m03954E24EFA4ABCBB26DA56FAE7053F2393428A5,
	PeerBase_get_debugOut_m67D7BD3029FBE9AD23445226209BD39358CE3B4C,
	PeerBase_get_DisconnectTimeout_m09FBDA78FE60E6BBD9B385693C36C9EF4F78A3B4,
	PeerBase_get_timePingInterval_m96D5A38D056163C1E669CFC6A4287A339B7D8E32,
	PeerBase_get_ChannelCount_m78B93310192C9A1C91E8F4C1462E30EF6718AA0D,
	PeerBase_get_BytesOut_m80A5C32F5F907925ED4B3ED82CA27424390452BE,
	PeerBase_get_BytesIn_mB0ACED6C6DFC04C4B2746D26A617BEACDFCEBEB2,
	NULL,
	NULL,
	PeerBase_get_SentReliableCommandsCount_m59964C176DA84948D163F485743C3DBDED5B0530,
	PeerBase_get_PeerID_mC90660C0DB65BFF3A934E4D9DAECFEF692665DA8,
	PeerBase_get_timeInt_m684602318BEA8E6EBF19C0CAA720DDD52B4262CD,
	PeerBase_get_outgoingStreamBufferSize_m64B6618D5B7A1844F7443D3CADEF0FA8DB0A65F7,
	PeerBase_get_IsSendingOnlyAcks_mC8DE21F87D58AB7887D6F342A0DF59C4932855F2,
	PeerBase_get_mtu_m7E93C9FB411EAD89E47739FA4ACE00AA953418E5,
	PeerBase_get_IsIpv6_m489A5BDC9E0D5C66AC03AE6894A23CB8FBBB8171,
	PeerBase__ctor_m8E3B20C66C5220AA2B22CFC69A1F4EC4692194FF,
	PeerBase_MessageBufferPoolGet_m29E0E9ED1F3F90AD695A68274405C657476D6554,
	PeerBase_MessageBufferPoolPut_m68F6EDE4E589B82EC35EC47535D38F17C7D4A729,
	PeerBase_Reset_m9E55CF5689C3B69E1E96DAC91F5B20761349F844,
	NULL,
	PeerBase_GetHttpKeyValueString_mFED3D50AB334A1C7925C3D000F902DC6E486A0AB,
	PeerBase_WriteInitRequest_m93B6B8C2D27A36A220016568A1CBC06CED1AC150,
	PeerBase_WriteInitV3_m6EA0C9832C7DE0D063F99FE6545236FCF4D2932F,
	PeerBase_PepareWebSocketUrl_m412ED80EB0138A636EC1801EE09AB65D7198DA25,
	NULL,
	PeerBase_InitCallback_m38983153A5ADCC639181C20ED0114FB9239780B7,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PeerBase_SerializeOperationToMessage_mEC78C0876E869EA1E9A2A34DF32FAD4A24C33AC4,
	PeerBase_SerializeOperationToMessage_mF9561C10973B6FAD518A88DB27585309512E6A5A,
	PeerBase_SerializeMessageToMessage_mF0EEF67E965C3C78DAA22E9A02CEC4560798F668,
	NULL,
	PeerBase_SendAcksOnly_m2A12BBBD2B890A60755FD90E3CFAAA90D45C3B41,
	NULL,
	NULL,
	PeerBase_DeserializeMessageAndCallback_m6E85A9674C09080C61D8B364F46136EB43D000EE,
	PeerBase_UpdateRoundTripTimeAndVariance_m951EC733736AB9475EE334DB283A32C6543FB3A0,
	PeerBase_ExchangeKeysForEncryption_mFE32BAAF2F73B9707F7C0164B5CE7259C0C5A8AE,
	PeerBase_DeriveSharedKey_m22D58A8EB38AD5BBDF8891EAA1ED1AC9FA3D0FF4,
	PeerBase_InitEncryption_mB71FBA3A0A599F67FDE4DA3634BD676D8210481A,
	PeerBase_EnqueueActionForDispatch_mC79508D2BA63A62A2E052D9C48B7A5C71B8DD84B,
	PeerBase_EnqueueDebugReturn_mA970CB09DF2811F5A9678470B73573670C3C4025,
	PeerBase_EnqueueStatusCallback_mD7222780DC33EB9871C8C7628A5EF8509027B2A6,
	PeerBase_get_NetworkSimulationSettings_m5AF79B90A13BCA5BE4C3A1BCB9B7AE4BA8FF11CC,
	PeerBase_SendNetworkSimulated_m419DC4EAFC08D5B49737E8A2EE62DBEA1C23C505,
	PeerBase_ReceiveNetworkSimulated_mA600DD4B96F273F83E1637CC7BB4FBFD67053DAE,
	PeerBase_NetworkSimRun_m584DA041044DBDFC2349FC4F70B9C06F4BB40FFF,
	PeerBase_get_TrafficStatsEnabled_mCEB79F943EED0CF4EABE5FBD706829E685B26D84,
	PeerBase_get_TrafficStatsIncoming_m7EA752B6B8C63E370775F0D6DD1A90BB9671F07C,
	PeerBase_get_TrafficStatsOutgoing_m796734FDA942AD0B88124CA19D209F9849B2F04C,
	PeerBase_get_TrafficStatsGameLevel_m4047DD71E6DDAA793A48AF43CD35B71872CDFA83,
	PeerBase__cctor_m43DFD5487B66142A8F8D42F5E57874E071DC28F3,
	MyAction__ctor_mA4E45068C583C9A36D57A62DD11313423F6D660E,
	MyAction_Invoke_m8ED616F18FBC1F97985ABADD10C44653D0E8D689,
	MyAction_BeginInvoke_mA7C62E36147456BB8EF51AEC520CCB52805DF43E,
	MyAction_EndInvoke_mED909E72E34A1303A3BC8DEDE6E4B8924A518889,
	U3CU3Ec__DisplayClass110_0__ctor_mE0B26BCE8BE0B33BB719278BC4F28DD05AB8AABB,
	U3CU3Ec__DisplayClass110_0_U3CEnqueueDebugReturnU3Eb__0_mDA77118CE7115DE46F0769C76318F5DFB7790F46,
	U3CU3Ec__DisplayClass111_0__ctor_m10987EAEB786E1E1318F4F3ED9D1C06081B1354F,
	U3CU3Ec__DisplayClass111_0_U3CEnqueueStatusCallbackU3Eb__0_m0ECC377EE1B7C6B72BB7DEB3CE58C29B879AAD3B,
	PhotonClientWebSocket__ctor_m3B182E99BF52CFB3ACFCFAFB353F7784F59ABFA6,
	PhotonClientWebSocket_Connect_m40CAD7964783313850390D7D3F1033C5D7098D2A,
	PhotonClientWebSocket_AsyncConnectAndReceive_mBA69B40E95B4C83FFA1DFC0143D771AFB4CD15C9,
	PhotonClientWebSocket_Disconnect_m38BD261C5551EC438787AD47AFCFA4909514FFE3,
	PhotonClientWebSocket_Send_mAEE5EB5A2FE9BA01610BFFE9095C0A1B651F1110,
	PhotonClientWebSocket_Receive_m4ABE9F7F789099E55D8325EA0DB6988D32C4E3FF,
	PhotonPeer_get_CommandBufferSize_m443228DB7FE2194797798162B25AA05CEEF4582C,
	PhotonPeer_set_CommandBufferSize_mB86FA5959011D5529F87F6A356D07DAE87DAEB54,
	PhotonPeer_get_LimitOfUnreliableCommands_mD0FCB02B8DB2B0123E445678B94830FD883ACE93,
	PhotonPeer_set_LimitOfUnreliableCommands_mB7994DDBF3E868DB57BDF00696E75A469B98B070,
	PhotonPeer_get_LocalTimeInMilliSeconds_m0625AC365852EAF0CAB2E368E8348ECB1F345C46,
	PhotonPeer_CommandLogToString_m5383F9093DF320E726EC6FB6C84D3C2FE6986A12,
	PhotonPeer_get_ClientSdkIdShifted_m9DB2F195BE27630E51359D1933180351A86AD121,
	PhotonPeer_get_ClientVersion_m2A40E299025E03015641C18B33FA8BA33F740318,
	PhotonPeer_get_NativeSocketLibAvailable_m98A0EF479F65080CA9AAD1E19E0DDAF0A6E22974,
	PhotonPeer_get_NativePayloadEncryptionLibAvailable_mAEC6A41A26C2ADB9A0D3385B217CA1F9B92676F4,
	PhotonPeer_get_NativeDatagramEncryptionLibAvailable_mEA9CF5032B974ED8BCA45AB45F99D85DDCB6EC7C,
	PhotonPeer_CheckNativeLibsAvailability_m8A3871A8DB5FEB2C731E29EB87DF724A03D1D870,
	PhotonPeer_get_SerializationProtocolType_m3E0FE394D65FD240003DA72F52AE43F2019AF8B1,
	PhotonPeer_set_SerializationProtocolType_m02676498FE60666B33768152B5CA30C4F8FC6EFD,
	PhotonPeer_get_SocketImplementation_m4CFE54CA5FCF0BB5820A1B42914AD7484D3A5198,
	PhotonPeer_set_SocketImplementation_m289CFBA0718087875BB453C66E3ADDD36757C613,
	PhotonPeer_get_Listener_m887BECA64658F676E50480D559D3E133A62F159A,
	PhotonPeer_set_Listener_m853BE7848FA55AB832A8BAE561EBA746F1E4CA28,
	PhotonPeer_add_OnDisconnectMessage_m22463EFDD6DA0A060DE27EE4E4D79D2516A77ACE,
	PhotonPeer_remove_OnDisconnectMessage_mD61C68CAEE2E7C63BF549F818896287AD0DFA749,
	PhotonPeer_get_ReuseEventInstance_mC082E5735B38E8287F1CA3303618015F07C8C8B0,
	PhotonPeer_set_ReuseEventInstance_mC8F8073785CA0C6176F425841B210847B46B0F30,
	PhotonPeer_get_UseByteArraySlicePoolForEvents_mDA3D712BAE30E8C4C348A4299081BA29A63E2240,
	PhotonPeer_set_UseByteArraySlicePoolForEvents_m2434369DFFFFC80B9F8265681ED52EF00E5345F9,
	PhotonPeer_get_WrapIncomingStructs_m1B2D926E56FC89C31334BFDEB022C76A2C3E53E6,
	PhotonPeer_set_WrapIncomingStructs_mE9E151AFDE44C3B88505BA25DCE1693C77D2FFB5,
	PhotonPeer_get_ByteArraySlicePool_mBE19F601AF8244E1B1414FBCD1E032D1EC22C420,
	PhotonPeer_get_BytesIn_m54215BB6A8B9BD05A38F60ED10EE954F6E32424E,
	PhotonPeer_get_BytesOut_m96964D14F0B1B2CA944C4E5CFBA7EEFBEE3DF26A,
	PhotonPeer_get_ByteCountCurrentDispatch_m88E3B1AD5C53FDF1C12C410BFA76965533836F82,
	PhotonPeer_get_CommandInfoCurrentDispatch_mAB17A3465956B1FAE7EE283B74DBB00A4A1E855E,
	PhotonPeer_get_ByteCountLastOperation_mBE8D1B8DD6265682CAE46CAB03B8B47346105E0B,
	PhotonPeer_get_EnableServerTracing_m18A1ACFEA37C05184F857D1C5D87EF05F306A595,
	PhotonPeer_set_EnableServerTracing_m8814641772F47AD400C956A7B223ECD4D9C9F0D9,
	PhotonPeer_get_QuickResendAttempts_mD01A6A47AFDFA919B74966F65AEB4A6C5288EAED,
	PhotonPeer_set_QuickResendAttempts_mF1A6AF63A324442A7D3DDD07794D7071C50E8BDB,
	PhotonPeer_get_PeerState_m88FD264346AFB1D75762E4B2FF0385258EC3BB99,
	PhotonPeer_get_PeerID_mCFE1D8A04860C907EB895FB4888E2572E6E6FEE8,
	PhotonPeer_get_QueuedIncomingCommands_m089990B31608CBEA27CA06E1B878D330F0438C98,
	PhotonPeer_get_QueuedOutgoingCommands_mDC1937F3C7BD71F911AE6004C275CA8525844FD2,
	PhotonPeer_MessageBufferPoolTrim_m667A1F4C30747022F01A9165618587BF5A346C36,
	PhotonPeer_MessageBufferPoolSize_m2FE0BCC9CA61FCAAAE77C68C4551C8B0F0306E4D,
	PhotonPeer_get_CrcEnabled_m9C938E3DD435390BF289EC04C0716D83B8401479,
	PhotonPeer_set_CrcEnabled_mC35D5639838B6BBD01803F39752E7B5B193FF861,
	PhotonPeer_get_PacketLossByCrc_m1E076970BB46019F6AE17000B94C177028E97010,
	PhotonPeer_get_PacketLossByChallenge_m42310BDC5191DAF7845C0619AE74E2B74132E715,
	PhotonPeer_get_SentReliableCommandsCount_m465F3D79D36D7F28A68FB0DAECEA35EC1EA26D93,
	PhotonPeer_get_ResentReliableCommands_m574A9F8EE1BCF083FDBE81E5160113AC5071DDC9,
	PhotonPeer_get_DisconnectTimeout_mA10F0BBD2136B75EADE9844D7A50283D9C84E7CD,
	PhotonPeer_set_DisconnectTimeout_m1A09FFC6C6EF02A2D29254CA90752ED94B023FF0,
	PhotonPeer_get_ServerTimeInMilliSeconds_m48B4E6E2E4A19C14BA99AC57FC04D56CC913A7D8,
	PhotonPeer_set_LocalMsTimestampDelegate_m9E33B0166FC28A1F6ACC6D0AFFF8722DC516CEEA,
	PhotonPeer_get_ConnectionTime_m9F70BA6979E294FFF1E9FB021F2A7BC06F3A62F1,
	PhotonPeer_get_LastSendAckTime_m1B0DE46390708644D9D4A7B29D73873A92A9804D,
	PhotonPeer_get_LastSendOutgoingTime_m473D5BD8F686EA19A30140876891DA260453A5A9,
	PhotonPeer_get_LongestSentCall_m6D28545D14718EDBCF8C329AE90C540E3CFFE0EE,
	PhotonPeer_set_LongestSentCall_m031D6BDCA4901F3CA36BFA562D4B1BD82CA90EEC,
	PhotonPeer_get_RoundTripTime_m74BE6E225C1F4EAC9F98A479A5283E6F8137E0A5,
	PhotonPeer_get_RoundTripTimeVariance_m606C1E46FD35CC9BCD3EBD9B4A7DB86578320836,
	PhotonPeer_get_LastRoundTripTime_m0C03E59517A6FDA26BD69E7572CED948D0A78114,
	PhotonPeer_get_TimestampOfLastSocketReceive_m1C0B76D764835D829C8F07FC483DCF9EB79A68D9,
	PhotonPeer_get_ServerAddress_mA78ED5E85749B747D7130E710A174555C134C6A3,
	PhotonPeer_get_ServerIpAddress_m4666717F31CA5968B11172E63A30E0470EC725EA,
	PhotonPeer_get_UsedProtocol_m4686906F6D5052926E68229C645155F0832628F6,
	PhotonPeer_get_TransportProtocol_m767D7E412A9F27CD9689630891F5506575307C4E,
	PhotonPeer_set_TransportProtocol_m80F1A37AC3F8CA8715B4C94B5CCABA6F2212725B,
	PhotonPeer_get_IsSimulationEnabled_mD035CB4485897813D96CB3C4C1A84AA483912D20,
	PhotonPeer_set_IsSimulationEnabled_m3C059BDECC55B176170F3CD84A76C84A581E5092,
	PhotonPeer_get_NetworkSimulationSettings_m43D3DC8846AC3B792260E24D964156B0CC0830BD,
	PhotonPeer_get_MaximumTransferUnit_m904843DF7767EB6EFE82DEB8DF6116A56D4BD494,
	PhotonPeer_set_MaximumTransferUnit_mEE070FE799743B331CA83FCC89AD7380174564DA,
	PhotonPeer_get_IsEncryptionAvailable_mB1AD5EA055403463741C7B76F387DB022AD8B4A5,
	PhotonPeer_get_IsSendingOnlyAcks_mFA3DB1A7DB77E3E521DE863F8A2270DE8836AD87,
	PhotonPeer_set_IsSendingOnlyAcks_m62B51C5659FE0D9DE7A4F9BB487F6A3E320F65CC,
	PhotonPeer_get_TrafficStatsIncoming_mB5B5418A73812C70E12DEEFAE8D613B960A609D5,
	PhotonPeer_set_TrafficStatsIncoming_mD8B9ED647CA95A2B9466B0D8CD8D8D1A6E17092F,
	PhotonPeer_get_TrafficStatsOutgoing_m39F4B4571628D143BC9DD0C35E51A75A21BD1839,
	PhotonPeer_set_TrafficStatsOutgoing_m0C2F85D63AD3232D4351E0019C87096B93B8927A,
	PhotonPeer_get_TrafficStatsGameLevel_m9D614C0C28437757DD44F328955AC9D91C23BB96,
	PhotonPeer_set_TrafficStatsGameLevel_m52E56118408A5F4CB070589626A9F9B44FF4BCC0,
	PhotonPeer_get_TrafficStatsElapsedMs_mA4409826A3847436D7035D66CC25ACF6270E2D58,
	PhotonPeer_get_TrafficStatsEnabled_mF6968A3F13443FB9D5CAD342375E6DF03C452066,
	PhotonPeer_set_TrafficStatsEnabled_m63D18A4834D74787ACF4C57FCA3B8CA3C74D285E,
	PhotonPeer_TrafficStatsReset_mA2FB3E7703F48B830B7D481A0BD9DC7717F21721,
	PhotonPeer_InitializeTrafficStats_m69E72037D3EC9D51588233C148FA0289FFB7302A,
	PhotonPeer_VitalStatsToString_mDF9D5301AB2D91C6CD64AE76B488ADC595EFB518,
	PhotonPeer_get_EncryptorType_mA75C4423E584B68BAA3B096966E692AA906F14CF,
	PhotonPeer_set_EncryptorType_m14753F3B50F3061F071716A0FCBFA3CCB97C6BF8,
	PhotonPeer_get_CountDiscarded_m30387BE17BD0EAEC093BCC5507F4820FB8FE881B,
	PhotonPeer_set_CountDiscarded_m4D744BD16E9D4C5D55A2818730734D6385878DB7,
	PhotonPeer_get_DeltaUnreliableNumber_m8BEE3C8070A562FC8D6E8BB20DBB787F67E2A304,
	PhotonPeer_set_DeltaUnreliableNumber_mC2A0228B74216C80460D3E4960A427D6F2A28EB7,
	PhotonPeer__ctor_m38515A3E371289E1132751051AE6236909114FCB,
	PhotonPeer__ctor_m501CF8AB2D93EA3190BBE0F3DCFCBE5FC7A6AEE3,
	PhotonPeer_Connect_m72984A500910B5A55D2D54AD87DCB3FA0EAC3F3B,
	PhotonPeer_Connect_mB73B289096309A4E15185A0BE6FEE82A523D39EE,
	PhotonPeer_CreatePeerBase_mD24BFF1814A065BBB52D0DD6B373F0D407CEC74B,
	PhotonPeer_Disconnect_m863D6F91AEB5E18EB704BC80985B6B9EB5597655,
	PhotonPeer_OnDisconnectMessageCall_mCAB30DD61D1D545353ADCEAB2BA3FB3794F060DB,
	PhotonPeer_StopThread_m07FC3E2D5650A262179C87DD305FF0C56CA31E4C,
	PhotonPeer_FetchServerTimestamp_mB57D30DE42227BA44DC85C051BA457F16220BB92,
	PhotonPeer_EstablishEncryption_m8635FA2B26F476C22D3152B3734ADE787955AE5B,
	PhotonPeer_InitDatagramEncryption_m5763710F8FFE525CFAF94DC71C2EFE1DDAE590DD,
	PhotonPeer_InitPayloadEncryption_m2ABC4A9C97D901C1EC9BBE5157C1200098632B4C,
	PhotonPeer_Service_mCB6FC0D9496BF709A5AFDC2673D9FC50426692FA,
	PhotonPeer_SendOutgoingCommands_mF3104B861AA48A5A3AB330C5D452C9941856312C,
	PhotonPeer_SendAcksOnly_m437CA459431F629F76FBEB7F9ACFEB02674881AC,
	PhotonPeer_DispatchIncomingCommands_mCAF078435CB2ECBDD69CC0B45B12DC82E79F4833,
	PhotonPeer_SendOperation_m871717EC9305F011A482BF52037F44B9FFE230D8,
	PhotonPeer_SendOperation_mC22D66512298CF37D07D4BBC86B121D283E89723,
	PhotonPeer_RegisterType_m0B7FF218BB0C55EF27A2A78147C0E9A78940914B,
	PhotonPeer_RegisterType_m0ECEC15A8AE97F0751B29A791C22897A6ABCBFC0,
	PhotonPeer__cctor_mF490B1497039DECE97B95B1A36E0F0DA80586EE5,
	PhotonPeer_U3CEstablishEncryptionU3Eb__220_0_m8A34D437798A9DBACF6FC45B055D8C767760E9E1,
	OperationRequest__ctor_mA8E4F8C6EE9E0949EB7B02A063DEEFC9DC743B5F,
	OperationResponse_get_Item_m0129E7DF764B87113A443CEA9537478C4040D0BC,
	OperationResponse_set_Item_m4493B35BAA19F6A52E70F1F562B42BE8B05C1104,
	OperationResponse_ToString_m284F3715502CE797867432477ED2A6ED201C0752,
	OperationResponse_ToStringFull_m3199D448BDD773C8652EF7E3C9ABF422D33FB5EE,
	OperationResponse__ctor_mA876E3701ED5CF5428D4379AE3324574508A1DBF,
	DisconnectMessage__ctor_m932DE568123A243B0166705D82CADBBDA7EE4EB6,
	EventData__ctor_m972A9C95F3874A0CE1E4204BB92293E60D5C80F0,
	EventData_get_Item_m0B6DECAC5E4E913E0B9C2229ABF41797A46E840C,
	EventData_set_Item_mB7DD2CBF2BB7FE9DD04B9FFA9257D3A7BA86EAF3,
	EventData_get_Sender_mE0F9AFE67C414CEF769B982C8FA299E0A6C41269,
	EventData_set_Sender_mCB8B03028382D08CF624BF25E66BDB94BD86461B,
	EventData_get_CustomData_m4D0A5928FCF5AB90A20BF79A980C43F88F098434,
	EventData_set_CustomData_mDB4DF0DBFBD09830FA509F35E443956A8C2FDC05,
	EventData_Reset_mD146DABD3B11F677BA45689B2B504080BE569DD0,
	EventData_ToString_m4A3E644B01E58EC22CFBEFD77027561857595768,
	EventData_ToStringFull_m278564F21BDC0596EABB1781F868054261986E52,
	SerializeMethod__ctor_m96BC348674809A197BC5DCC3A9E1E2AADDD39DAD,
	SerializeMethod_Invoke_m2A26A185AE91964A251119037A553C6E86D349E1,
	SerializeMethod_BeginInvoke_mE0169B293A31A693DD1A04BA4AC4463BA6B3F456,
	SerializeMethod_EndInvoke_mA508A823D40AFEE88169D2A041D5E469F0376842,
	SerializeStreamMethod__ctor_m5727105B26DE58354DA5B13EFFFD77434B70DEBF,
	SerializeStreamMethod_Invoke_m1D00168E642A230A7E8AAA7DE07ED03B728DC03E,
	SerializeStreamMethod_BeginInvoke_mE43378F00EDD1F95520418F6F614EBE8669AFD72,
	SerializeStreamMethod_EndInvoke_mDCB34CA93CA5719CBF7719762984A18C088FC26B,
	DeserializeMethod__ctor_m3AC517B570D77033065EF138A30672CC1C9DB9C0,
	DeserializeMethod_Invoke_mCC5F7D5A8C00B74D8217C86B2A0BF85430F3A791,
	DeserializeMethod_BeginInvoke_m0C5601E36806A7835A92D1F6ECAF2F65FE318E2E,
	DeserializeMethod_EndInvoke_m8C7E512975D5D4792185F217E22B9DA9C495A392,
	DeserializeStreamMethod__ctor_mF8F3783D7EF3114059BDF53CFB0238559135E346,
	DeserializeStreamMethod_Invoke_m7D9A79222D4C7287C6ACB335B49FE7D3A4273E46,
	DeserializeStreamMethod_BeginInvoke_mA8C68FFD6586822857072182430A4542992DF27A,
	DeserializeStreamMethod_EndInvoke_m201B80499B982FC2EC4B0E5C398ACA06FA083A4F,
	CustomType__ctor_m60AF973AEEA38FF2983E72D442F949E65F8AA753,
	CustomType__ctor_mEFCC4B2772EF2D0C48881A5EEABE73BAE70A92A3,
	Protocol_TryRegisterType_m8255302EEB4258D52247EB1755C185BDE7289DEB,
	Protocol_TryRegisterType_m5CF4AC809FD0A168658B1625675354A504BFB55D,
	Protocol_Serialize_m06033A4D0AD53A023906C528FC0E9D4103847509,
	Protocol_Deserialize_m412DA38040DEF51F1DA42B804936ABAF254A8BB0,
	Protocol_Serialize_mD54B54F99D80A391A02160F4F949A3561C236F82,
	Protocol_Serialize_m27E2692AE673B1810ACA6011A7F861A0E18F6D81,
	Protocol_Serialize_mFA5F2139A75516B7B781ADCB40B7FC766857DD99,
	Protocol_Deserialize_m1C09A03E55AF5D8C561DBC47B4CCA6773101A705,
	Protocol_Deserialize_m180D4E319855AAE9AB99769218D4E1ACD84B9EEB,
	Protocol_Deserialize_m6E12343C3EF275E24F20CF6F143DE1247B29C87C,
	Protocol__ctor_m1BDA97874B5B4F9F9376F49C305A08A70237BB91,
	Protocol__cctor_m9E76C52B6F18ADC90B79BDE7DBF72222D58CE223,
	Protocol16_get_ProtocolType_mD438E25ABC22D7CCD6398905557EE6CEE92E695A,
	Protocol16_get_VersionBytes_m98E3ACB96E587331D35A63A5E69AE88F11A55978,
	Protocol16_SerializeCustom_m59CD45B021D66B0DA6C505067C8BE4918A949880,
	Protocol16_DeserializeCustom_m0863DEB302D41DC1E2ADA0D2EB34865746117A21,
	Protocol16_GetTypeOfCode_mDE3A7EBBBA57480E19546202FE8547609FA4A3A7,
	Protocol16_GetCodeOfType_mA89A00BB10307CEC476076FBDE2A382B2DD5878E,
	Protocol16_CreateArrayByType_mC615C831BF33993E8C671C20DB773E7BDD6F5640,
	Protocol16_SerializeOperationRequest_mC4522D1203BE1CFDD78207CADC978CAC5745EAF4,
	Protocol16_SerializeOperationRequest_mBA7C02DD74F7B9BEEAFD8E50F012644C25911482,
	Protocol16_SerializeOperationRequest_m2A78110D8E406A66882FEAA9D14098992599BA29,
	Protocol16_DeserializeOperationRequest_m924BAAB16BB4B0F16E6E4B1C1B218FD1E30E9A3C,
	Protocol16_SerializeOperationResponse_mC49488819DCF7F9561C2F044183B2BDBF812DAB9,
	Protocol16_DeserializeDisconnectMessage_m8DF5E920924E7EE4BE3A47C132B6F542AF188C4A,
	Protocol16_DeserializeOperationResponse_m2291F3A386E136CCD0000D7D74FEED2F131117F0,
	Protocol16_SerializeEventData_m521DC5143BB32874492CB70BEC576AE4E67777DE,
	Protocol16_DeserializeEventData_mE2D54E13A0011EF5F6BE72BA0DA6A6B65493C250,
	Protocol16_SerializeParameterTable_m8F32540D8293403C4249222538C87205957A3F4C,
	Protocol16_SerializeParameterTable_mDC5182DDFAACD02BCBB8F133A025D7C38C6F0F16,
	Protocol16_DeserializeParameterTable_mC8CF132C52541033797C333ED3F3B765F587FA9A,
	Protocol16_DeserializeParameterDictionary_m902A290589C30ED34686607E23E1AE83CABB6347,
	Protocol16_Serialize_m54D16B40372962422496A7E8BCB70F83D1AA0539,
	Protocol16_SerializeByte_m434EA5ECDB0B1DF13628D48C2B6A22451835F318,
	Protocol16_SerializeBoolean_m1140814EB4953795837AC31A4F3F1685FC85D1FC,
	Protocol16_SerializeShort_mE31C720721710309730D86CF5FEE1830CD142796,
	Protocol16_SerializeInteger_m623B201CFF5EFF4C37E384DB94A4885FF65C126D,
	Protocol16_SerializeLong_m71359451ACA304469F78C6482A1DB51DAB9C95B7,
	Protocol16_SerializeFloat_mCCC5EA6FF0A9EA140012E68F2DAD366CE9064C12,
	Protocol16_SerializeDouble_m80642E2CF99AF881673A9806A9ED6EC0D47ADF45,
	Protocol16_SerializeString_m49FFBEF21BB10ED64CF2392C27FA14BFEA4268BB,
	Protocol16_SerializeArray_m931FF4BCAA5EF5DEAE745D432B9F298B7BDBD538,
	Protocol16_SerializeByteArray_mBD537757E9CA7298E466CABA9DA6BB4F3A671414,
	Protocol16_SerializeByteArraySegment_m8AD08CE6CBCB253BDF43966A22FCB2A91D7EFCF0,
	Protocol16_SerializeIntArrayOptimized_m51242157A146677E03A6AA59DB71793D97FF47F8,
	Protocol16_SerializeStringArray_m300DB80F6FC47106DDBB4B8A1881F1685350D324,
	Protocol16_SerializeObjectArray_mB659BA13D94C160C51270854A5222AE186AA310B,
	Protocol16_SerializeHashTable_m250CE58BF19D2FFFA9DB89AC054FB87796FB5E93,
	Protocol16_SerializeDictionary_mEA0C5D5C9576DAAD2EDB370CE474EB3A6C788451,
	Protocol16_SerializeDictionaryHeader_mAC60D2188B6AFB7373F2C2EE3FB4F678DB95CE5F,
	Protocol16_SerializeDictionaryHeader_mEADDFC9231764982EB25F869811FE7350CA697CD,
	Protocol16_SerializeDictionaryElements_m627241133D5F77E2B09C8ABF2BC36E27AB55BCFB,
	Protocol16_Deserialize_m2E78539B08BE2D296D1D90AE0039F6FD9BCDE55C,
	Protocol16_DeserializeByte_m27500E61762018A0E4C4DE3209EC20AF16DFACC8,
	Protocol16_DeserializeBoolean_mA0D0A5693A755401ED13C214773D9F3830FBA5FE,
	Protocol16_DeserializeShort_mF7485DFE5051F4CE47BE6E68ADB54B006B38403D,
	Protocol16_DeserializeInteger_m1F49250A65209E8ED50E2DA29049213918BE3D92,
	Protocol16_DeserializeLong_m86327A051C9C1FD8AEE2E9FE7248B5A48D598A2B,
	Protocol16_DeserializeFloat_m4B62FF8C63207DF266B930303941CACEF80D4588,
	Protocol16_DeserializeDouble_mE37562ABE997B47A4BC42F2A24F75069E9C16B02,
	Protocol16_DeserializeString_m5B7220E906B4A65B1E35C4480DAECCF7A604B528,
	Protocol16_DeserializeArray_m638BA0C8F43F015F3354376CDAD2764149EB3FFA,
	Protocol16_DeserializeByteArray_mA96762CDD41EB483194826E629F6A35552A161D4,
	Protocol16_DeserializeIntArray_mF2C069FDFD1156FB08648ECE379EFC7DF282906C,
	Protocol16_DeserializeStringArray_mF0A18AAFDD22DE57017DF9394FCCA7E89B000CB7,
	Protocol16_DeserializeObjectArray_mCF37B12D9B5D4301268503BBCA9A460241D0F25C,
	Protocol16_DeserializeHashTable_m988DBD14203EE4D91E2B82EB8EC54D42DDA1BA1F,
	Protocol16_DeserializeDictionary_m2F102FA2CF9D1AB02A26AE1EBDA87A38DFE9B527,
	Protocol16_DeserializeDictionaryArray_m76C13696C0B2A0ED3B0F52D661AD7DE7FF18E47B,
	Protocol16_DeserializeDictionaryType_m1F020B4D887856178943BC3A5A0578DE6C0A64E6,
	Protocol16__ctor_mF057AE2E519093202ECCD64863A2F96C33512E31,
	Protocol16__cctor_m9BC5BE7AB1F93F8986DB505F874FE349EA15D934,
	InvalidDataException__ctor_mF58EF21176D7A7967191E8366FE029F70E3DBAD2,
	Protocol18_get_ProtocolType_m4D601C5463B6E966798714B2948D3BB9D914388B,
	Protocol18_get_VersionBytes_m8992AF836BA06DAEB5A8F776307F3B5B56278F5E,
	Protocol18_Serialize_m5AF3A118526180C5F9C5C50BE01EF978C6A4115E,
	Protocol18_SerializeShort_m8BF8D507CB1F281274D3AB12FCF005F0CF2A7C06,
	Protocol18_SerializeString_m069E84195462BC9030B57051D2C6FB73816A5B09,
	Protocol18_Deserialize_mD50E46C3EF112ECE195E4A55155E5432CAC0C676,
	Protocol18_DeserializeShort_m1CE243C8558F696882534D918E9F1A6DB9BF79FE,
	Protocol18_DeserializeByte_mDD6E9495D4D5310716C01A37AA17900D76960F47,
	Protocol18_GetAllowedDictionaryKeyTypes_m35B12853C4567346FA295DFD4189066959F65815,
	Protocol18_GetClrArrayType_mEF02327BD24D846456DF3C6C47705189BC651EEA,
	Protocol18_GetCodeOfType_m79E179F34BC05A60F7F2274BEF54148302B259DC,
	Protocol18_GetCodeOfTypeCode_mEF6F68A3D06CF32A1BD4E51879811F7ECAE45E36,
	Protocol18_Read_m2F993F195161CA6803C2FF392B28DA2DCD808815,
	Protocol18_Read_m09D79564B117D8678ED56EBBF67A74AA12B9FC21,
	Protocol18_ReadBoolean_mD3E77C1567BD5440F4DCEC4BA66E81C445CE5946,
	Protocol18_ReadByte_m3A2E41414A3B9ED13C2564B0EFD354E974E9CB22,
	Protocol18_ReadInt16_m3C680275F34C6574C58FAEA4EA384E8970377712,
	Protocol18_ReadUShort_m442DA2616C8CF5CD7126F272B68A78EF9055DAD1,
	Protocol18_ReadInt32_mD59026398ECCBDC0381CD69E2E866BFF107E20D8,
	Protocol18_ReadInt64_mE8888751930F29535356F853B7B694694DA43A5E,
	Protocol18_ReadSingle_m98136AC94743FA6E6F06CF87895B1CB5714582BE,
	Protocol18_ReadDouble_mE5B8E203EA512CD77A32E73D3FF4C4D044E48B07,
	Protocol18_ReadNonAllocByteArray_mCDCA9986C4D5C495E6E4106A8BF3ED1DE34ED5BA,
	Protocol18_ReadByteArray_m64888E3710D21110F53B0877F3CF873CB22EFDA1,
	Protocol18_ReadCustomType_mD210A247BE40D402B9994FCF2FDAA814EB3A6F81,
	Protocol18_DeserializeEventData_m8D4FB7860B3E1C053D76078603A00FF1BC053950,
	Protocol18_ReadParameterTable_m79A00541CCAFBFF89C4D823801A21A026A901992,
	Protocol18_ReadParameterDictionary_m619A90D8D1E6CEC2A7686B51A3F0F501F3ACBD49,
	Protocol18_ReadHashtable_mB22E5871CC37A9C75927379BA2F5B70C87E586D9,
	Protocol18_ReadIntArray_m3B343CF26249C5AAC197242D06CE39A3C4CCE60C,
	Protocol18_DeserializeOperationRequest_mBA04093A752535C776B38203F40F69B3033711E0,
	Protocol18_DeserializeOperationResponse_m33E867327C730F3E0FC4DCC21CE33B3B3267C0B5,
	Protocol18_DeserializeDisconnectMessage_mFCFB449842D41FC5AF013ABE5C97768CFD0FA47A,
	Protocol18_ReadString_mF16FE2D7A57FF2E8FACE33944A86162C07D47BC4,
	Protocol18_ReadCustomTypeArray_m71E3645610B21DB7CBC4BE5122C18912B1D61689,
	Protocol18_ReadDictionaryType_m6FCAA15F2B9F0D9E24C077623085A38EF0B5609A,
	Protocol18_ReadDictionaryType_mA179C7203D3C62DD25AD6292E95DC89F20773BDF,
	Protocol18_GetDictArrayType_mA1E792172A5B4C5BCFCF1E19BD9CF5F459F659AF,
	Protocol18_ReadDictionary_m92ED8996EE2C263227200362C8DCE6336C823908,
	Protocol18_ReadDictionaryElements_mBCE55F96C3A41A5A409B09BAD6FB5D8B4F4A48CC,
	Protocol18_ReadObjectArray_m0DDD95C4C4B317C5D9A314E2D59F429D59BB4BCD,
	Protocol18_ReadWrapperArray_mF5B843E73615653074CE2CDFF0E9105210D32A0A,
	Protocol18_ReadBooleanArray_m85A0489F16D59CB193CD4205202C02A3739F0515,
	Protocol18_ReadInt16Array_m4F058F1C87B5C1839E3EAA792A73908F9960078A,
	Protocol18_ReadSingleArray_m7FE62D3211B463F5BAD4FA36536D528BB0E8442D,
	Protocol18_ReadDoubleArray_m02E56ECD6DC63074A58A5D2813E0C6BF263C4EAD,
	Protocol18_ReadStringArray_m2B5C1B56BEA5EE25F1484933456AA525402E404C,
	Protocol18_ReadHashtableArray_mE30AFB6D375CB558D164AD759C55B4F2221E4826,
	Protocol18_ReadDictionaryArray_m3B2B76720AD64D1645AF5E1B63280C65E391AF79,
	Protocol18_ReadArrayInArray_m9753F27A394BDBF161952EFCC3A0A5F64144D64C,
	Protocol18_ReadInt1_m365F861F96014A7393AAD7CEA5E3EF95D7008A01,
	Protocol18_ReadInt2_mD7790185AA89E4C3D67F6392F738A5D9B26A322C,
	Protocol18_ReadCompressedInt32_mD1EB2A16A7217DFEDCF16DF30DF8DCFD1A7992DA,
	Protocol18_ReadCompressedUInt32_m17057086842E42718F09DA3A903D63750F87A50F,
	Protocol18_ReadCompressedInt64_m2FFF6CFFE5CD1544683E0BF78DAE87CE75F6767C,
	Protocol18_ReadCompressedUInt64_m9B7F063484F938E4F240BA002B67F338250A9483,
	Protocol18_ReadCompressedInt32Array_mB7F5D2B618F1061766D66D947EB64C63D291F8D9,
	Protocol18_ReadCompressedInt64Array_m120C88D9BCFF624E2FD978A66675607FC154DD58,
	Protocol18_DecodeZigZag32_mACEEA9051FC1AFFEB8429B8BEF592310B7DA1116,
	Protocol18_DecodeZigZag64_mA4BC3625A35BE928E09A3218588FEE85341D2453,
	Protocol18_Write_mF7C37DDD5DDDE1CE617B58DB04F4302EF590EA42,
	Protocol18_Write_m9BC32ACCE1E26B31E516B4E3073D7A95DF21F351,
	Protocol18_SerializeEventData_m39E5951CE427081C3A8DBF9F97D701AEF45EB3CE,
	Protocol18_WriteParameterTable_m8C35A8A50438B5AEBEA3595DE849DBC7FF13A6F6,
	Protocol18_WriteParameterTable_m32EF7D045788EDE51B9B9846DDEA0DB721425992,
	Protocol18_SerializeOperationRequest_m9077C7AE7E6F7D9188034220A3AB39CA9504AD9F,
	Protocol18_SerializeOperationRequest_mF49A0ACE7567A86F2F6A227E3BDB7DAA7EBCA672,
	Protocol18_SerializeOperationRequest_m8BA0E9475E3924D5322A9F527F4E33364B436760,
	Protocol18_SerializeOperationResponse_m36D6E5989F064BACBD8F6EB1DC2B12E8F39EFDA2,
	Protocol18_WriteByte_m09AF71165F0200B2646F6804C4A5C85A4CD7BACB,
	Protocol18_WriteBoolean_m0769B46175746D07F2977B89C0572F1612006757,
	Protocol18_WriteUShort_m8D45AAFAB5254DE317600BD5B515A8EFBC7A2A4F,
	Protocol18_WriteInt16_m8491308A0FFDDD4707E10DDE7ACF0CD5AFC0B76C,
	Protocol18_WriteDouble_mF35491A348EE9254188C8D872A243D3D922AFFD5,
	Protocol18_WriteSingle_m8DDF6C197F96E072539452AF1CA9E06C8DB4493A,
	Protocol18_WriteString_m7DAB4B13ECCF933C34C890B74C79D5D9EC654E1D,
	Protocol18_WriteHashtable_m3049CA1849694F40E4D5416EC2F5DEA4C366259B,
	Protocol18_WriteByteArray_mA29066A57F922C59FBDC0D2A613F7D0058F6C582,
	Protocol18_WriteArraySegmentByte_m850F64E20D6D5C70BC0864ED1E4C103934F0C987,
	Protocol18_WriteByteArraySlice_m8561C7F465CB7824029EFB7BD558679B777A10CC,
	Protocol18_WriteInt32ArrayCompressed_m36418993D473E2308BF03DD8265A0ED46522BCB6,
	Protocol18_WriteInt64ArrayCompressed_m6EF1B8668BDB155E31FCDADE9E78A80D5707BA70,
	Protocol18_WriteBoolArray_m5E390996A6A50C3F372E71022777E8FE56EFA5A0,
	Protocol18_WriteInt16Array_m0B6B162DC1C956540EDAC316DD4B6D9B70E524DC,
	Protocol18_WriteSingleArray_m573081EB19FAB3E13660A2312242A361A358AEBE,
	Protocol18_WriteDoubleArray_mD2620072C5D98BA7B990D4C5673129823AFCA9C9,
	Protocol18_WriteStringArray_m1152C424C3ACF23FF7A16B8A5BD1A2694E9E938D,
	Protocol18_WriteObjectArray_mB6F7ADE913EFD4D39007AE12AE8B0457976B8D44,
	Protocol18_WriteObjectArray_m3366E5C482B5E3AFF93570D35F3D0B66CEF10576,
	Protocol18_WriteArrayInArray_mDB7CF18A498261F79E910C6E3E9329C30A54C0F1,
	Protocol18_WriteCustomTypeBody_m93B798CB5F8E3A6EF026F4050E55521EFEC19001,
	Protocol18_WriteCustomType_m1C8B98F817EF3300F3AE2718363E154CD0C548B9,
	Protocol18_WriteCustomTypeArray_mB8F4EA8B7EF63A5B0B1950F522F6200CC7DBDEB6,
	Protocol18_WriteArrayHeader_mFD3EF867E30605F1C7E202ABE9C262317A5E0A5F,
	Protocol18_WriteDictionaryElements_m0BA00C62C65E8AE638298A6723D26D0807B504E5,
	Protocol18_WriteDictionary_mB2251C0C08D240514A0C85A36C25E0F385219070,
	Protocol18_WriteDictionaryHeader_m17F347CC6010BD4A290112DCA5B0F5EEBB0908C9,
	Protocol18_WriteArrayType_m0F062BA8DC79325022D5139101BE6D403590FFF2,
	Protocol18_WriteHashtableArray_m71A34C4A5116A147C460A6CB58F1C25B1CCD6ACD,
	Protocol18_WriteDictionaryArray_m21B482D391C88C70810F4573C1A84E58446F39F5,
	Protocol18_WriteIntLength_m08FC5AE95B2ABFB77AF31EF0A45D7518BA54C6F9,
	Protocol18_WriteVarInt32_m9B26A239DFABE2A1EBF4641CC19C65CB716B17C9,
	Protocol18_WriteCompressedInt32_mD3A5BF3430F53D75E7502C8288514BEA4B1E2EC8,
	Protocol18_WriteCompressedInt64_m743E019C394294E2F2FE0838BEE1ECCE98F0F063,
	Protocol18_WriteCompressedUInt32_mBCCAFF4517A9250DFD1D84351FA07BC8C43D2AF2,
	Protocol18_WriteCompressedUInt32_mEFE4A8C0A0E8710F2A7A4F04DC070A39E9CAE757,
	Protocol18_WriteCompressedUInt64_mD349352229DF670BBFF340C2A32A67F063625933,
	Protocol18_EncodeZigZag32_m986834D9F95CB41469A7AFE41BB5E3583487D8B1,
	Protocol18_EncodeZigZag64_mFEC1878B0B7684B9DEB5A867F3CD10EAA5E2D7E6,
	Protocol18__ctor_m22A7FC9394BEC0B9033B6816D5561B33139D15EE,
	Protocol18__cctor_m08035FE03A369339AA8B8F5944DC76C26F035139,
	SendOptions_get_Reliability_mB59F1C863C7D1F054C004F11E7320CD7F94B55C4_AdjustorThunk,
	SendOptions_set_Reliability_mC77446E8524CA786BE18E235B7857357F1EF12A0_AdjustorThunk,
	SendOptions__cctor_mDC55D7C2228550A15240DC3BDF99322552906D16,
	SocketNative_egconnect_m5176E005A047310FBAD3925093430D655B30ECB4,
	SocketNative_egconnectWithProtocol_m806F08EDDBCC87E91BEA0B4B5C6DD20CD6537FD9,
	SocketNative_egconnectWithProtocols_m78D90C2E20B316FF5E3A7A5B04929CF0C2D92C59,
	SocketNative_eggetState_m4AD208DAA5A2980AAABBECA1019DD30E6AE8D688,
	SocketNative_egdisconnect_m750D6BDB5D814582523F0BB0FA1144AB7496FCAA,
	SocketNative_egservice_m4C88B9F394F0CE2964250AD66450D59E2500339B,
	SocketNative_egsend_mA60863CC2B6F230B0BC1403D4B95E5FA6EE9C1C4,
	SocketNative_egread_m2D60605B078002752445D93C4AB748617547EAE4,
	SocketNative_egsetSocketLoggingCallback_mE8AF39979206D829B16AB4DA422A728A977F77D4,
	SocketNative_egsetSocketLoggingLevel_m38053AEE63633BF17868B53F3EF79C66F4104389,
	SocketNative_eggetUsingIPv6_m83C9849BFFBA18E8DD7DDEF9962217B05E6259FD,
	SocketNative__ctor_m3AEEE22ACF3E30F3F21E3837283C91E48A16857A,
	SocketNative_Finalize_m1337197EC8A39DA301ACDDC621AE3F3A8AF7C93E,
	SocketNative_Dispose_mEEB96AE00BB25794615051FD3CB9394BD23C21AB,
	SocketNative_Connect_m26D14B23A416C1531F0CB7D48D166334635A0771,
	SocketNative_DebugReturn_m3D36438056F5FD4B647AD3D732F52B028557B6C6,
	SocketNative_DnsAndConnect_m7D5858BF00FC7D1E1116C6D44D551DA8FDB8699D,
	SocketNative_Disconnect_mCCD2CFE2EB69256C268ECCD434A822CACE5E937C,
	SocketNative_Send_mFE6D1CF3180FD67421AC1AD40E103F5E8B26A8F9,
	SocketNative_Receive_mECB59C242FD2A3D79449F28A6BA871796D82F928,
	SocketNative_ReceiveLoop_m5571BF0BDF112DF5E0969BFD99A84721F9659CE3,
	LogCallbackDelegate__ctor_m044E69D655ECA9BC09132D1CCA84B0789C3B90FC,
	LogCallbackDelegate_Invoke_mCA190F9A5AD687AF46634DDF8B9194B9360DCBE5,
	LogCallbackDelegate_BeginInvoke_mE37C748185236AB26F63FBEAF08BB1A9B307D990,
	LogCallbackDelegate_EndInvoke_mD10D6BB783DA08E522A6A680F2B8F25CF6C8F015,
	SocketTcp__ctor_m13C724CC217A6A4AC3C9BBE826F6800F9C773F14,
	SocketTcp_Finalize_m50FEC8060A6E0574F554A8592E1B419CD550C135,
	SocketTcp_Dispose_mE3FC268156D1A60E36AF823EA2BDB95A5EBDDA31,
	SocketTcp_Connect_mF685C8B52ABD9664927A42034F39750B85EF1AE4,
	SocketTcp_Disconnect_m274104C3EAB2A82D40EAAF5347AC7B3056EC7CF5,
	SocketTcp_Send_m3D571D4C1438B575D6DDE2C0443B4EF6E22D7AB0,
	SocketTcp_Receive_m3DD9B3246B73FC16E968A6821E2D75946C0CD583,
	SocketTcp_DnsAndConnect_mB027C1D044836E47C565057AFDF8E0D43B4D5AC3,
	SocketTcp_ReceiveLoop_m8CEF82CD3E0268C9A1529B6E60E30343E11DE25F,
	SocketTcpAsync__ctor_mF0DD3CA73B04F5685B3A5F55BCBD6F6BF5727D32,
	SocketTcpAsync_Finalize_m782644322B409F031DEEBBA425F98632C1CC15FD,
	SocketTcpAsync_Dispose_m9D8910FA9790D2A4865927A8FC2EBCC3E23183A0,
	SocketTcpAsync_Connect_mE2DC1317A00792C6E6332E2B5E2487EC2AEEA62A,
	SocketTcpAsync_Disconnect_mBDDB27A6311764679211DFBFDC82E4EDFD4133AC,
	SocketTcpAsync_Send_mE9BE56BDA956FBF91E16E8D4048064DE9A542E50,
	SocketTcpAsync_Receive_mE2F9F9698E66A99A4A033C14DCB08EA18D3397FB,
	SocketTcpAsync_DnsAndConnect_m74F7F2053F81C40B4F4DA336512734D618349FCE,
	SocketTcpAsync_ReceiveAsync_m236ADD7C52953B6F11E9B315021A00CAA62F28D7,
	SocketTcpAsync_ReceiveAsync_m47212B002D7A0395407BDF641559C7FD1FC5783C,
	ReceiveContext__ctor_m5A7B0DE7FA6B305890A16936B93C6B581478BDF5,
	ReceiveContext_get_ReadingHeader_m35F07F0FA8823F3FC69D751A76A0BB4E369906D5,
	ReceiveContext_get_ReadingMessage_m28DF43B11B6BB645FFE71644B84274E06AF90A8C,
	ReceiveContext_get_CurrentBuffer_m6B5498715FE8F542D87D48FFC327B60CAC37448D,
	ReceiveContext_get_CurrentOffset_m2E40691FCD9BD5A4609C3965D6F22D2A34CD0C8B,
	ReceiveContext_get_CurrentExpected_m6C6CD2F8A4AAE9BA96F8F3BE296119E4DC890104,
	ReceiveContext_Reset_mECAA41521CAA2D5953C06BB1173F92EC2B6E8536,
	SocketUdp__ctor_mEFC2826611898FB056BBF00920762C63FDF836DE,
	SocketUdp_Finalize_mF8DE0107AC42D9C95F08FBCE7172EA33C4833651,
	SocketUdp_Dispose_m77D90E62CFAAF49E80206C37F125E21E6394EBBB,
	SocketUdp_Connect_mD14776A9DB51520BE90E1AC2D4CB0B560933DC70,
	SocketUdp_Disconnect_mA8AE69A876F2F09B96BDFF6462680B01931CD377,
	SocketUdp_Send_mF494761D40C5D32D4CA21F37D2788B4A27873158,
	SocketUdp_Receive_m199234CA91A3C269D89C721C6BF9BEDCA0DBC35E,
	SocketUdp_DnsAndConnect_m396610977AF49BD29DD2886CFD0111C80ED85F73,
	SocketUdp_ReceiveLoop_m9A000A5385C95B922B89E07605135401B58A828C,
	SocketUdpAsync__ctor_m6A946F4AA3EBE86EFEE4D0A3ECED23332AE9593D,
	SocketUdpAsync_Finalize_mE16A554083614DC1EF56017A2A8F124DBFB5C9E9,
	SocketUdpAsync_Dispose_m03EFDAB00C5654F20ECBB7A83ED495BB3B80EE6E,
	SocketUdpAsync_Connect_mEA3FD10CF3AD6EA34B58CB67E8A33F7CBB5FB276,
	SocketUdpAsync_Disconnect_m6263DDE1302E9CE076C59C324B1E8A27B6F26400,
	SocketUdpAsync_Send_m9EBD2A69A46B054F4A09D6424A7EFF0B80A65609,
	SocketUdpAsync_Receive_m58C7B987D7790BA394A1337CE2A1033F7CF76CE8,
	SocketUdpAsync_DnsAndConnect_m8AE352BAF08F2BF93EBBAD283A782942405B1E72,
	SocketUdpAsync_StartReceive_m2233330FC0B61E8F85BADC8B053CF5C21D037D4E,
	SocketUdpAsync_OnReceive_m4F79F163F40472FC7534FC3E48982BD27D5E3732,
	StreamBuffer__ctor_m6741D62D0B5AA1AD4F951EA6166971DD91CE921C,
	StreamBuffer__ctor_m3D663C8D89B6B653C6FB5BE69A6D7C567FC1D487,
	StreamBuffer_ToArray_mE8DB28ACF32D71B1ECF2924CA827A23C8C6FD142,
	StreamBuffer_ToArrayFromPos_mF245BEEB718733CE04EDE2A1CDEE82E4F57C02CA,
	StreamBuffer_Compact_mA399EFD3D6D619E644BDAB333A8B929489C3933C,
	StreamBuffer_GetBuffer_m79F59BF586871847E6B90B6C2A27A5878AC90E37,
	StreamBuffer_GetBufferAndAdvance_m38B894FDABD42E27E0B2458CE06ED07BA12FC834,
	StreamBuffer_get_CanRead_mF9EB523A62BF1FBEFAD2C62E2FC4523A86D1194F,
	StreamBuffer_get_CanSeek_mA3234BE7AB32AC2ED8C752C18013529144FEC6FE,
	StreamBuffer_get_CanWrite_m8D7860E524BA6AAEED78B4C24F16518A5670FE6F,
	StreamBuffer_get_Length_m25ED1D6A2694D671039B6E613957359C2A08EC7E,
	StreamBuffer_get_Position_mB2DA1691D41DE363A5A5842E5904D9BAECA2A159,
	StreamBuffer_set_Position_m24AE0EF7E75D2FA2FAF0AE474C62D8D3EA6D536F,
	StreamBuffer_Flush_m73795E2244C74B6343C7964D6A35BE2AB67B0F74,
	StreamBuffer_Seek_mB3CA4BE799C99040F278CDE0B628E3D7406737E2,
	StreamBuffer_SetLength_mFBB2205D71E335E8781CBFC39427568CD3DA7481,
	StreamBuffer_SetCapacityMinimum_mAE7703A01484D3A000FBE4AF736E797B7BC1F149,
	StreamBuffer_Read_m2C67AEA14C4E9C2863F513A1C4E4201C1C1087C5,
	StreamBuffer_Write_m73CBB2D7D37C0AEC59784DC671A4FA58E1ADDEA2,
	StreamBuffer_ReadByte_mC09C543D9ECAF0221C64A971BE2FC7AD075C8A14,
	StreamBuffer_WriteByte_m91BD1873D9C122433ED2674AACE71B554BB33769,
	StreamBuffer_WriteBytes_m55B97C40B8264BF9B6B758574CB3FFCE93078242,
	StreamBuffer_WriteBytes_m565E330ECF043BCFCF1EA67A3F96883CF4338E60,
	StreamBuffer_WriteBytes_m748F93C3367B589CF0DD28580ABD9CFACE99D4F5,
	StreamBuffer_WriteBytes_m2C009C9D17C9F88BAD27ACF57163ABC9836BF0BE,
	StreamBuffer_CheckSize_m369091E28AA3BC3A89B8554869294BD610C6FBAA,
	SupportClass_GetMethods_mCBB60FFF3C6E27AFA90ED968FF33008CEA5F45A6,
	SupportClass_GetTickCount_mA0086E5ACABD24CF0434DD2CD11C54BAD34058D2,
	SupportClass_StartBackgroundCalls_m97526EE667EC704A455FD13C141D62E21253A282,
	SupportClass_StopBackgroundCalls_m9FAC8E09B24EBBFB79F70D3217DC6DCDF920E5A6,
	SupportClass_StopAllBackgroundCalls_m01E38449EF57C0FA9C483CE541C9ADCF656C2D85,
	SupportClass_WriteStackTrace_m92D17F6B1D5AE459E3A14C494F681E620F7606C6,
	SupportClass_WriteStackTrace_mD40141F866AA995D02A2D4F739D004608A89CBC1,
	SupportClass_DictionaryToString_m1E005B8D84A505955CE57EE43881C01A3C5D4525,
	SupportClass_DictionaryToString_m7DB3E9F96BDA0BBD8FDF9C753518007E6C418F16,
	SupportClass_HashtableToString_m58275C29667A4797D2299BEDFA1481E4F443FF8E,
	SupportClass_ByteArrayToString_m62F24AFEB6753A4B51C46ADC4FF6F5D6608F8FC7,
	SupportClass_InitializeTable_m3D01F8860C55EEB1BE9BF1A08409BD2F58368033,
	SupportClass_CalculateCrc_m936192955DFE5862CA5EF52BF0B581A51674EEBF,
	SupportClass__ctor_m5C3866632D524715A22760D87D6628ADCECBEB33,
	SupportClass__cctor_m8B2F4DB244F7C76095E1D06E73E745EE37312532,
	IntegerMillisecondsDelegate__ctor_mDA3273E2CE0D8FE39164E71CAA2031FAEDCF287C,
	IntegerMillisecondsDelegate_Invoke_m3BBA95A0E5A8E30E4FF461F7A8C43FC5E67A4DD4,
	IntegerMillisecondsDelegate_BeginInvoke_mE2527A597A807656326C984C51D9A87FBC3FF9CB,
	IntegerMillisecondsDelegate_EndInvoke_m9356EF0422BC12A81CDE180BC829D30D112ABEFC,
	ThreadSafeRandom_Next_m81D40266E8D1D8EDD95D9AB0425D7C4005E49B25,
	ThreadSafeRandom__ctor_m19029CAA02F811B542856515BD252C47CF08A78F,
	ThreadSafeRandom__cctor_mDC6B1F44182E3141B4B56F3D5DBDEB29841F0D9B,
	U3CU3Ec__DisplayClass6_0__ctor_m6C82CB693ABED6C0B9863862F932F64AE40D5645,
	U3CU3Ec__DisplayClass6_0_U3CStartBackgroundCallsU3Eb__0_m2BFA2B91A0E678A5DB5132B6D2F0E6A6759A641E,
	U3CU3Ec__cctor_m4715CD20BEF03F217208AA4D99D50A9C72E421D4,
	U3CU3Ec__ctor_m9156FE65A757702ED75B32540E42268ECBB698D6,
	U3CU3Ec_U3C_cctorU3Eb__20_0_mB1D5166DFEE4B03A5BE6EBDC6C2A9AE091DCEB28,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PreserveAttribute__ctor_m6C97B88484AE59AF86941BA63360427A96190335,
	TPeer_get_QueuedIncomingCommandsCount_mA332EC035639C12C0A265699333D74978DDADF7D,
	TPeer_get_QueuedOutgoingCommandsCount_m786416DF442D145FDB60CE3558EC9EE480C343A6,
	TPeer__ctor_m957957FD2DE6B73AFFC8DA74865BFE0A0D8132C2,
	TPeer_IsTransportEncrypted_mED4014A5183C7D9CAF51AB4F48D142F39497BB1E,
	TPeer_Reset_mC17366CA64B83D5B026E00CE94FB258FD395F8B6,
	TPeer_Connect_m11EE8070E8587620C540171BEFC394F270937D9E,
	TPeer_OnConnect_mA2AE15A4D17989D9850E4CC29EC74B24A5077C92,
	TPeer_Disconnect_mCC45CECD45E0B01E7E5BB185383B260B1049D494,
	TPeer_StopConnection_m5F73C577E8FCDBEAD992CA73EC5C21F3BEEF1E16,
	TPeer_FetchServerTimestamp_m8D2DA7B388BC5776F0F4FCCFB026A09CABF1EE80,
	TPeer_EnqueueInit_m7F9CED6533FFAB3DE884C6CFE5AE6684EE92CC2F,
	TPeer_DispatchIncomingCommands_mA16275DC611D1E54BC4FBB25AEA9172DEF72C1A4,
	TPeer_SendOutgoingCommands_mEC0A1C820F055A9F2E806AAF769B83AD809F01C3,
	TPeer_SendAcksOnly_m9E2AB7494C35CE49AC8D9DCB30F5A7A45D8ED371,
	TPeer_EnqueuePhotonMessage_m8E32860FEA23A0D2799A06380CB2A8437EED8338,
	TPeer_EnqueueMessageAsPayload_m5E6655156E6382425BB131EB858A686B665A94AE,
	TPeer_SendPing_m17FAFB3761F1AAA35BCAEA0AC15058F04ACDC891,
	TPeer_SendData_m9D2A5B81CA25BF2D273259B6E21A8D016EEAC304,
	TPeer_ReceiveIncomingCommands_mAAC5886B77F17ED00E9F82DA1EB331BE61B47D40,
	TPeer_ReadPingResult_m21041D75C9316E96AC652AFA5390B1490DCFEB35,
	TPeer_ReadPingResult_m0BDD6F364B7DD8E1E0D135155F9ED16B2E158408,
	TPeer__cctor_m5E259C4C9389F90C0622C8DDE3D1D12FC4543843,
	TrafficStatsGameLevel_get_OperationByteCount_m086A7E5F72C6A007253F619CAA3191EB4C78E914,
	TrafficStatsGameLevel_set_OperationByteCount_mD1AD82B5392459198A0AD2FB6A1A40AE28368C93,
	TrafficStatsGameLevel_get_OperationCount_mD0FA6651A97EA6536897D9B24B33EC1378010EA8,
	TrafficStatsGameLevel_set_OperationCount_mE660535935BC321093B76E949C96B65F0511CE56,
	TrafficStatsGameLevel_get_ResultByteCount_m2BA47CF280E2D044126A9F859E83F79F72235ABE,
	TrafficStatsGameLevel_set_ResultByteCount_m79130B5870228D5FF1E1EA4EDE06CDC83A7521B1,
	TrafficStatsGameLevel_get_ResultCount_mE96D0080C09F62967746137556E8883B28F719DF,
	TrafficStatsGameLevel_set_ResultCount_mDFE8B8FD3B2C27E083C8C21C76B92391594DE6C7,
	TrafficStatsGameLevel_get_EventByteCount_m3E3E76F0E4E33509ADD4C25F9CDBE4D30957ABB0,
	TrafficStatsGameLevel_set_EventByteCount_m113F40E2DA8CDCB9EF8E3F40726B2D4BD3464E15,
	TrafficStatsGameLevel_get_EventCount_mA2F82A89B8B80274BB994B293088984A12BB5FFA,
	TrafficStatsGameLevel_set_EventCount_m4AFA89743643BE3CDC141B336776A4EBC06AE573,
	TrafficStatsGameLevel_get_LongestOpResponseCallback_m93ABE5175296D7A3F12C55964AECB4D98A468437,
	TrafficStatsGameLevel_set_LongestOpResponseCallback_m3F34F108B0A4D3446FD01F17EDA0D7D504BC4F21,
	TrafficStatsGameLevel_get_LongestOpResponseCallbackOpCode_mF646C104F0D57F26E6C7695CDC46C643C2D8A85B,
	TrafficStatsGameLevel_set_LongestOpResponseCallbackOpCode_mED20BE05A576912EE4DB3CB4431EE9C94E5F9572,
	TrafficStatsGameLevel_get_LongestEventCallback_mCFB892A9DAA383DF5A867C1BAF97F91F9AC2892C,
	TrafficStatsGameLevel_set_LongestEventCallback_m894E046FAC6C54F79AB54D6A1C56B08FB157B3FD,
	TrafficStatsGameLevel_get_LongestMessageCallback_m2FB5D7572D5F579A26BF5D769344C1DDFDD64C0F,
	TrafficStatsGameLevel_set_LongestMessageCallback_m8604E721E070E532F9D46941ECFB604C5C363228,
	TrafficStatsGameLevel_get_LongestRawMessageCallback_m6179ECB340018673BA624517E5F3E957CA9B34F1,
	TrafficStatsGameLevel_set_LongestRawMessageCallback_mE9B1FBFE67D6DFCA5E79C4756559D0BC159063B7,
	TrafficStatsGameLevel_get_LongestEventCallbackCode_m9048920021B7BE2978F807D0C1CC19994EF64BBC,
	TrafficStatsGameLevel_set_LongestEventCallbackCode_m0467ED6E9B84FB3B730327E72491FF3A87DAE0AE,
	TrafficStatsGameLevel_get_LongestDeltaBetweenDispatching_mB8F7ABF7B7DFDF88C4CE6CCC91B1536138B26CA4,
	TrafficStatsGameLevel_set_LongestDeltaBetweenDispatching_m22179901F3200D4681C08C9D2956531B955F0E38,
	TrafficStatsGameLevel_get_LongestDeltaBetweenSending_mFE6A1F7C968EFA5DCC441B78C0118A26B7AF5E15,
	TrafficStatsGameLevel_set_LongestDeltaBetweenSending_mB238B91A3907CCD9F4FB2F259B55D5D97AAC5CC8,
	TrafficStatsGameLevel_get_DispatchCalls_m985362A23DB1DF8276475506DC5F0993057F0D74,
	TrafficStatsGameLevel_get_DispatchIncomingCommandsCalls_m067D46E1430E21CAB6BA11E69A5CD54FC909914D,
	TrafficStatsGameLevel_set_DispatchIncomingCommandsCalls_m9A1333825C4BE97510FBF0864C1FDB70678B13F9,
	TrafficStatsGameLevel_get_SendOutgoingCommandsCalls_mECFAA4C1338C3CE34D084954955DAE25ABB3942E,
	TrafficStatsGameLevel_set_SendOutgoingCommandsCalls_mE4D14EB50C26925D3CC405E39EB9540F67BDFB8D,
	TrafficStatsGameLevel_get_TotalByteCount_m61C59D944FEA45F6890EC6358FA124D72C6036D5,
	TrafficStatsGameLevel_get_TotalMessageCount_m09580215C14A7763F34D58CDC1322579281D78AA,
	TrafficStatsGameLevel_get_TotalIncomingByteCount_mD2FC4B90C1819B494F834198BCA1879171263ED8,
	TrafficStatsGameLevel_get_TotalIncomingMessageCount_mD4B358D350EB1EA1E70DC9F3BD9C4DE12280F4F9,
	TrafficStatsGameLevel_get_TotalOutgoingByteCount_m1745319A5A651C52EF60CD40E330D08EB6FEB281,
	TrafficStatsGameLevel_get_TotalOutgoingMessageCount_m4FBE7C7CDD3CEB859CDFFA462E49D7CF4167285C,
	TrafficStatsGameLevel_CountOperation_mAF25E49F3625B85D4253205BB70ADB7776D3C4BA,
	TrafficStatsGameLevel_CountResult_mDE4D23515A1FA38D9F1A4D20BBB325D12D4ED854,
	TrafficStatsGameLevel_CountEvent_m56C7A686D51ADD83721095F1EECA1F7EF2E23F88,
	TrafficStatsGameLevel_TimeForResponseCallback_m4655B94FDFC5BF288E127638A7F0389C708BBF95,
	TrafficStatsGameLevel_TimeForEventCallback_m5B7CEDDA63A03F98206D2D48083F1D6D92EDC594,
	TrafficStatsGameLevel_TimeForMessageCallback_m57439D64362437749BB96BDAB50B9E5ABA8848C1,
	TrafficStatsGameLevel_TimeForRawMessageCallback_mE80D0C7E37387D80D1E32EC57A93DB354FDD356F,
	TrafficStatsGameLevel_DispatchIncomingCommandsCalled_m3E0C3AB4F9C0C8970C598B5160ABE627D2F031FD,
	TrafficStatsGameLevel_SendOutgoingCommandsCalled_m52E73ED4D8C7AF3A1CAFAEDA498574DF43E62661,
	TrafficStatsGameLevel_ResetMaximumCounters_m4B29B200F63BFF61CA88F7FEC034F5D6E9E9C3E4,
	TrafficStatsGameLevel_ToString_mC429A8ADC63BE025F7A64E02280FF036E84194C3,
	TrafficStatsGameLevel_ToStringVitalStats_m86FBCCC12199B6F28BA5778BFDAF5A0399B96B76,
	TrafficStatsGameLevel__ctor_m71DA010F0631FCDDDE508028B0C42E7157DC79D0,
	TrafficStats_get_PackageHeaderSize_m1D25FBE1A816E4A827D298A9402C3099A94510C9,
	TrafficStats_set_PackageHeaderSize_m19712FF06B25DC18400DE304E403DD8F2D1B8F47,
	TrafficStats_get_ReliableCommandCount_mBE3A184C7D70373DB0306F93878295FAC75A5F67,
	TrafficStats_set_ReliableCommandCount_m9DC554A3C889BDC0A2DE61E6EA3BEAEEC906F192,
	TrafficStats_get_UnreliableCommandCount_m3081BE8F9F0731DA8697AA51A95FD60C5B479A03,
	TrafficStats_set_UnreliableCommandCount_mBFAECAEFA858D2E59E99338AFDC4562505A0326E,
	TrafficStats_get_FragmentCommandCount_m14E236EFB0BD1F28FE1662BF89EDD2C8FF8C9A79,
	TrafficStats_set_FragmentCommandCount_m4FFD2B1F7FD95A1FD8EE53CC00E73CD2268ACC99,
	TrafficStats_get_ControlCommandCount_m36E3359A94B412A1507A39F0DCCEA3B99550020F,
	TrafficStats_set_ControlCommandCount_mD0EA6ECE6ED42E25057261B7D69EE472C306758E,
	TrafficStats_get_TotalPacketCount_m84AD1F6ACA44DCDEEB3D7DDEDD5106D431FBBDC2,
	TrafficStats_set_TotalPacketCount_mC5A1DB4A8AE80096ACAFC63FF99A3CBEBF269C98,
	TrafficStats_get_TotalCommandsInPackets_m5E47B2625D3BFED27344F06DDBEAC6FCA6D766C5,
	TrafficStats_set_TotalCommandsInPackets_m370B232CD8889AA6E4D4B1EEF1774EDD6BC994CE,
	TrafficStats_get_ReliableCommandBytes_m090DC6B8131F0DC3C5744817E3339343BE9B5BD4,
	TrafficStats_set_ReliableCommandBytes_m419D94CCE2B8F80108099055020B8218BB5551B9,
	TrafficStats_get_UnreliableCommandBytes_m89438F439355BA509BC3EBA76B745D52CCAF0CE7,
	TrafficStats_set_UnreliableCommandBytes_m23502D6EAFBF6A0B1E99D7E168D5CFC1FBF77003,
	TrafficStats_get_FragmentCommandBytes_m1A65788B99741445736CC24E4A794B8B0262C680,
	TrafficStats_set_FragmentCommandBytes_m7BA803E436518D0EB4D3AFF6301531CCBE7C6232,
	TrafficStats_get_ControlCommandBytes_mE9D246D653C6F4EDBA685466EC8A4BE5E7BF03A0,
	TrafficStats_set_ControlCommandBytes_m198DDF12387655F1DB8874E6CDE0E1240FB267E1,
	TrafficStats__ctor_m7A163C8A2322D91D08EA2494558FE98E4A77122D,
	TrafficStats_get_TotalCommandCount_mD5AFA9D97FAE04F2B65AD6F803857F5F08E4A1DB,
	TrafficStats_get_TotalCommandBytes_m673E3D70AB03382893BFE55844118814DABE7A59,
	TrafficStats_get_TotalPacketBytes_m78B80C1327ADF57BF7B60F0F77853B310504D6B9,
	TrafficStats_get_TimestampOfLastAck_m8D38D581C2F6EA022C52C970F99DB9F9F2A09ECB,
	TrafficStats_set_TimestampOfLastAck_m408B0C0E6ED090884C7753D061709F504F797174,
	TrafficStats_get_TimestampOfLastReliableCommand_m0A94870AAC6A0C00A9C5611C30E8C626F505565E,
	TrafficStats_set_TimestampOfLastReliableCommand_m79BA49951A17159B5FEF0680AB2F486F371D33F7,
	TrafficStats_CountControlCommand_mA622D5A3E457095819E8C70B7F4F077D29EC7507,
	TrafficStats_CountReliableOpCommand_m0D47D70C4D06123DFB42DE97969F3600F5965A79,
	TrafficStats_CountUnreliableOpCommand_m7E710A9383D70DC07E75C7116B3B4BE9726FB5BA,
	TrafficStats_CountFragmentOpCommand_mE91AE8E3CFC81D697BB7F0901C9E02E12A12EB76,
	TrafficStats_ToString_mECCBC768029FED503D1FEA6B07FFF9CD1B04F38A,
	Version__cctor_mA40B5695C6844031A3374F15754AE95CCDEF8FD1,
	StructWrapper__ctor_mDF1A5F7BDC6A2FF7FAE7F9BE76036198C427EB28,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	StructWrapperPool_GetWrappedType_m8C689F2F9E44119A0507A2EBD44837B492AFACF8,
	StructWrapperPool__ctor_m81E32623B9398D5D7FDCCE452B8832AB3EAC1C73,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	StructWrapperPools_Acquire_m1FE96E54618FCCE9DFFB70D2BBC42E18B556D875,
	StructWrapperPools_Acquire_m72323D6359C73C13ABCCB33F06A307BEFF8B1EE4,
	NULL,
	StructWrapperPools_Clear_m0A62D387532994F86DDD519D87ACAE5BE8C0CFA2,
	StructWrapperPools__ctor_m65A3AB7112A3EBD740A19838C73328F73A130FA9,
	StructWrapperPools__cctor_mE2F4B7AA4E42A618804D8A08BB1080A635776B27,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	EncryptorNet_Init_mB3AEB2F391807AB8DD70A17C2AD91A9AF86BA080,
	EncryptorNet_Encrypt2_m1B98ECC47D223BF3C800AF472C07F509AD8018CB,
	EncryptorNet_Decrypt2_m16B3D768B5B23A7E6C11E828BD94693B66E8C36E,
	EncryptorNet_CalculateEncryptedSize_m4BA773EF7C4DC9BCB48C8950086DA9D67B29A2CC,
	EncryptorNet_CalculateFragmentLength_m569F76FAF3CEB6DAD18402D4EA9422C6C6837891,
	EncryptorNet__ctor_m7CA333A500C68B8794E3B72505B80F27B204139E,
	EncryptorNative_egconstructEncryptor2_m491CC2D3001AA24B414D223E86533F8D59AB0528,
	EncryptorNative_egdestructEncryptor2_mE6A8D567AD82160BDFDCC9E02E4868BAC2CBE4CB,
	EncryptorNative_egencrypt2_mB0688D48E79103AE3E69D7CB4AA5FB81E307567A,
	EncryptorNative_egdecrypt2_mBF8E07E088ADB062E9D9D9202672336E4D24600F,
	EncryptorNative_egcalculateEncryptedSize_m3AC6FA8308F1F10B9BDBB7D2E1399F120C352F10,
	EncryptorNative_egcalculateFragmentLength_mE05D0B8AD345196B5D504721F6C5C6D0FAE0B2E2,
	EncryptorNative_egsetEncryptorLoggingCallback_m38437CE892232575891B4E35BD26AA2015E1BA5C,
	EncryptorNative_egsetEncryptorLoggingLevel_m51CFAADE7666EFBAB4B5A7845C6821D39AFF922C,
	EncryptorNative_Finalize_mB984258D126DBF34F2E11AE8B941D1127F62AE86,
	EncryptorNative_OnNativeLog_m093EEF0A12F4E92917B10950998C3B705BF1CD8C,
	EncryptorNative_Init_m59609AFE78A2ECA3DF9E848103CA39AA83CDE9F2,
	EncryptorNative_Dispose_m3AB10BC670FB517D512821075218F9EFA64DEF05,
	EncryptorNative_Encrypt2_m75CCAE5E86EF7A714C4674DC0FB4BBDC54388FEE,
	EncryptorNative_Decrypt2_m86A5523A0D47C2C92B5A49F12F73675211ED653D,
	EncryptorNative_CalculateEncryptedSize_m9ACD15490323D9F745BFC93513F363F87EA607C9,
	EncryptorNative_CalculateFragmentLength_m44A8E3B8981C6D00009DE009DB23D9E09342242D,
	EncryptorNative__ctor_m30F847B8DA38EDFD8E2FB6023DB92F6B6F5B9888,
	LogCallbackDelegate__ctor_mAB26F158E9641F0FAB4056DF05F8A2C1372C2D31,
	LogCallbackDelegate_Invoke_m4EC3369D43980E37AB72C2A633B089F847E4493F,
	LogCallbackDelegate_BeginInvoke_m14EEBF9555D61CE0FDBC4877EC891A6A2973CF7E,
	LogCallbackDelegate_EndInvoke_m91E9CDA8458555C51EEF6D0D355A8873CF2ADA8F,
	DiffieHellmanCryptoProvider__ctor_m12546E890659882808EA2FB4C7F2E92AD6A18B09,
	DiffieHellmanCryptoProvider__ctor_mBD6D5FE5B4E8B526062019D037576EAAF5C1678C,
	DiffieHellmanCryptoProvider_get_PublicKey_m1100C1EE0915221FA8AB3ADC4D290F4E6579240B,
	DiffieHellmanCryptoProvider_DeriveSharedKey_m0324A6629DAA697603DDBCAD8D22CCC0BD9DB4FC,
	DiffieHellmanCryptoProvider_PhotonBigIntArrayToMsBigIntArray_m3251E72D58580BA854D8DE38D0ECAAA9ADAC5FEA,
	DiffieHellmanCryptoProvider_MsBigIntArrayToPhotonBigIntArray_m160F47B4CBA17BA27FE0B30831B6716AD6D831EA,
	DiffieHellmanCryptoProvider_Encrypt_mC1C2C023BBFF0349E83E82D360A9764EDB8F524F,
	DiffieHellmanCryptoProvider_Decrypt_mD41BE4F0E12B0B13D31B9F77A3F8466ABE206B61,
	DiffieHellmanCryptoProvider_Dispose_mC169C6044BA837B4340DBAD10A2EDFA9D91B16B0,
	DiffieHellmanCryptoProvider_Dispose_m017715B932D4628BB3A4D4C55763AEA2952402F3,
	DiffieHellmanCryptoProvider_CalculatePublicKey_m06288E8A57765AC8D2080A043F2213B58F41E2BC,
	DiffieHellmanCryptoProvider_CalculateSharedKey_m83B163A6D73BF92A9371449A615B1F7DA24B4993,
	DiffieHellmanCryptoProvider_GenerateRandomSecret_m8F36E8967F63FCC371AF486F31AA6DB20E9EEB02,
	DiffieHellmanCryptoProvider__cctor_m8414DF0E61471D5B09CD270F39E9717C831965AE,
	DiffieHellmanCryptoProviderNative_egCryptorCreate_m3DC38F64F637F7FD894B86135F56D7FC5B35EC7F,
	DiffieHellmanCryptoProviderNative_egCryptorPublicKey_mEDDB2BFCCCC9F4B048D3E3A8C64ADA849384A9E7,
	DiffieHellmanCryptoProviderNative_egCryptorDeriveSharedKey_m5AD75715D60C9B5A0E8A769B9BC038AE0E6D2B39,
	DiffieHellmanCryptoProviderNative_egCryptorEncrypt_mF568D41A720505CE759ADC90C8BA368211E03DA7,
	DiffieHellmanCryptoProviderNative_egCryptorDecrypt_m95D5D321050D438953BE392F01C6D68C90E66360,
	DiffieHellmanCryptoProviderNative_egCryptorDispose_mADF8497109F276A7E5658757DDC4AAEF4C7588D5,
	DiffieHellmanCryptoProviderNative__ctor_m9A198E38889D06526A3970477C85A1BB8045842A,
	DiffieHellmanCryptoProviderNative__ctor_mF88DC9A37C3A1B024B4FE2E51AFA9F705EC6F9B5,
	DiffieHellmanCryptoProviderNative_get_PublicKey_m3E3960BFAED78C91100340A7969E9CB1FC8A6243,
	DiffieHellmanCryptoProviderNative_DeriveSharedKey_m3519AA51CC9FB72A6239FB82F031CEBB8E7DED74,
	DiffieHellmanCryptoProviderNative_Encrypt_mF2CB0558E4A9C93FAADD93FBD4FF7A49667771C3,
	DiffieHellmanCryptoProviderNative_Decrypt_m1DD5CAEF7C7AE3290DD975DF804D92EDF4079470,
	DiffieHellmanCryptoProviderNative_Dispose_m8C3A676A922E136C18D3AB6171ECC52D3DD4DE05,
	DiffieHellmanCryptoProviderNative_Dispose_mE26025BCDD413431A5374D11070EB266CE717BD6,
	NULL,
	NULL,
	NULL,
	NULL,
	OakleyGroups__cctor_mE0A83D3A98A3D1874821B8DBCA377AE0FB075BDD,
};
static const int32_t s_InvokerIndices[1016] = 
{
	137,
	35,
	23,
	23,
	89,
	23,
	10,
	32,
	10,
	23,
	54,
	34,
	58,
	9,
	136,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	825,
	3,
	23,
	32,
	28,
	27,
	130,
	88,
	88,
	31,
	218,
	14,
	14,
	14,
	26,
	89,
	23,
	14,
	693,
	14,
	14,
	693,
	23,
	830,
	30,
	34,
	30,
	34,
	1840,
	139,
	23,
	9,
	10,
	10,
	10,
	23,
	89,
	23,
	23,
	130,
	1006,
	23,
	23,
	23,
	23,
	89,
	10,
	37,
	10,
	89,
	89,
	89,
	1841,
	1842,
	10,
	112,
	137,
	137,
	137,
	26,
	26,
	26,
	137,
	137,
	26,
	9,
	782,
	28,
	3,
	23,
	88,
	26,
	32,
	26,
	14,
	10,
	10,
	32,
	89,
	14,
	26,
	14,
	26,
	4,
	159,
	10,
	32,
	89,
	31,
	14,
	26,
	14,
	26,
	14,
	26,
	89,
	89,
	510,
	1843,
	363,
	218,
	88,
	32,
	1844,
	803,
	28,
	41,
	0,
	23,
	3,
	23,
	28,
	43,
	14,
	14,
	152,
	1240,
	152,
	152,
	1845,
	1845,
	152,
	1306,
	221,
	9,
	102,
	58,
	58,
	28,
	28,
	28,
	28,
	28,
	27,
	23,
	89,
	31,
	1846,
	688,
	1847,
	26,
	23,
	10,
	89,
	89,
	1848,
	1845,
	1845,
	622,
	622,
	23,
	637,
	14,
	23,
	23,
	112,
	14,
	23,
	10,
	32,
	89,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	14,
	23,
	23,
	32,
	0,
	130,
	88,
	10,
	23,
	88,
	88,
	42,
	42,
	1849,
	830,
	1850,
	88,
	-1,
	-1,
	218,
	130,
	1851,
	-1,
	1852,
	130,
	26,
	1853,
	89,
	3,
	14,
	26,
	14,
	26,
	14,
	89,
	10,
	10,
	89,
	177,
	177,
	10,
	10,
	10,
	14,
	10,
	106,
	89,
	10,
	89,
	23,
	4,
	159,
	23,
	1006,
	28,
	14,
	14,
	209,
	23,
	23,
	23,
	23,
	23,
	89,
	1841,
	1854,
	1854,
	153,
	89,
	89,
	137,
	89,
	9,
	32,
	9,
	26,
	26,
	26,
	88,
	32,
	14,
	26,
	26,
	23,
	89,
	14,
	14,
	14,
	3,
	131,
	23,
	105,
	26,
	23,
	23,
	23,
	23,
	26,
	89,
	23,
	89,
	510,
	1843,
	10,
	32,
	10,
	32,
	10,
	14,
	89,
	14,
	49,
	49,
	49,
	3,
	10,
	32,
	14,
	26,
	14,
	26,
	26,
	26,
	89,
	31,
	89,
	31,
	89,
	31,
	14,
	177,
	177,
	10,
	14,
	10,
	89,
	31,
	89,
	31,
	89,
	14,
	10,
	10,
	169,
	106,
	89,
	31,
	10,
	10,
	10,
	10,
	10,
	32,
	10,
	26,
	10,
	10,
	10,
	10,
	32,
	10,
	10,
	10,
	10,
	14,
	14,
	89,
	89,
	31,
	89,
	31,
	14,
	10,
	32,
	89,
	89,
	31,
	14,
	26,
	14,
	26,
	14,
	26,
	177,
	89,
	31,
	23,
	23,
	130,
	14,
	26,
	10,
	32,
	10,
	32,
	31,
	458,
	1006,
	1855,
	23,
	23,
	26,
	23,
	23,
	89,
	1856,
	26,
	23,
	89,
	89,
	89,
	1857,
	1857,
	1858,
	1858,
	3,
	89,
	23,
	130,
	88,
	14,
	14,
	23,
	23,
	23,
	130,
	88,
	10,
	32,
	14,
	26,
	23,
	14,
	14,
	131,
	28,
	209,
	28,
	131,
	1859,
	132,
	221,
	131,
	28,
	209,
	28,
	131,
	1860,
	1861,
	28,
	949,
	949,
	1858,
	1858,
	0,
	0,
	1184,
	1862,
	1863,
	1065,
	1065,
	1065,
	23,
	3,
	14,
	14,
	90,
	1306,
	130,
	9,
	1864,
	152,
	1845,
	1845,
	58,
	152,
	28,
	58,
	152,
	102,
	27,
	27,
	105,
	102,
	152,
	814,
	814,
	1240,
	363,
	1865,
	1866,
	1867,
	152,
	152,
	152,
	1868,
	152,
	152,
	152,
	152,
	152,
	27,
	588,
	1869,
	1306,
	9,
	9,
	221,
	112,
	222,
	223,
	224,
	28,
	28,
	58,
	58,
	28,
	28,
	28,
	28,
	1870,
	1292,
	23,
	3,
	26,
	14,
	14,
	152,
	1240,
	152,
	1306,
	221,
	9,
	825,
	825,
	9,
	30,
	488,
	1871,
	9,
	9,
	221,
	221,
	112,
	222,
	223,
	224,
	28,
	28,
	153,
	102,
	102,
	102,
	488,
	28,
	58,
	58,
	28,
	28,
	28,
	1292,
	28,
	28,
	488,
	1872,
	488,
	488,
	28,
	28,
	28,
	28,
	28,
	488,
	488,
	488,
	1278,
	1278,
	112,
	112,
	222,
	222,
	28,
	28,
	37,
	998,
	152,
	1869,
	152,
	27,
	27,
	152,
	1845,
	1845,
	152,
	814,
	814,
	964,
	1240,
	1867,
	1866,
	152,
	152,
	152,
	1873,
	152,
	152,
	152,
	152,
	152,
	152,
	152,
	152,
	152,
	152,
	152,
	202,
	152,
	152,
	90,
	1869,
	152,
	588,
	1233,
	152,
	152,
	137,
	363,
	363,
	1865,
	137,
	510,
	176,
	37,
	998,
	23,
	3,
	89,
	31,
	3,
	24,
	1874,
	1875,
	599,
	25,
	160,
	1876,
	1877,
	1878,
	1879,
	599,
	26,
	23,
	23,
	89,
	1880,
	23,
	89,
	510,
	1843,
	23,
	131,
	1881,
	1882,
	26,
	26,
	23,
	23,
	89,
	89,
	510,
	1843,
	23,
	23,
	26,
	23,
	23,
	89,
	89,
	510,
	1843,
	23,
	26,
	26,
	202,
	89,
	89,
	14,
	10,
	10,
	23,
	26,
	23,
	23,
	89,
	89,
	510,
	1843,
	23,
	23,
	26,
	23,
	23,
	89,
	89,
	510,
	1843,
	23,
	23,
	26,
	32,
	26,
	14,
	14,
	23,
	14,
	692,
	89,
	89,
	89,
	10,
	10,
	32,
	23,
	736,
	204,
	32,
	511,
	35,
	89,
	31,
	42,
	676,
	85,
	84,
	30,
	1,
	106,
	232,
	5,
	49,
	142,
	159,
	158,
	158,
	0,
	0,
	43,
	114,
	23,
	3,
	131,
	10,
	105,
	112,
	106,
	23,
	3,
	23,
	23,
	3,
	23,
	10,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	23,
	10,
	10,
	23,
	89,
	23,
	1006,
	23,
	23,
	23,
	23,
	26,
	89,
	89,
	89,
	1841,
	1883,
	23,
	137,
	137,
	26,
	26,
	3,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	89,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	89,
	31,
	10,
	32,
	10,
	32,
	10,
	10,
	32,
	10,
	32,
	10,
	10,
	10,
	10,
	10,
	10,
	32,
	32,
	32,
	830,
	830,
	32,
	32,
	23,
	23,
	23,
	14,
	14,
	23,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	32,
	10,
	10,
	10,
	10,
	32,
	10,
	32,
	32,
	32,
	32,
	32,
	14,
	3,
	137,
	23,
	130,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	94,
	23,
	-1,
	-1,
	-1,
	-1,
	-1,
	130,
	130,
	-1,
	23,
	23,
	3,
	-1,
	-1,
	981,
	1884,
	1885,
	37,
	10,
	981,
	1884,
	1885,
	37,
	10,
	23,
	1886,
	25,
	1887,
	1888,
	1889,
	160,
	1200,
	46,
	23,
	1880,
	981,
	31,
	1884,
	1885,
	37,
	10,
	23,
	131,
	1881,
	1882,
	26,
	23,
	26,
	14,
	26,
	28,
	28,
	54,
	54,
	23,
	31,
	1890,
	1891,
	1892,
	3,
	770,
	1893,
	1894,
	1895,
	1895,
	25,
	23,
	26,
	14,
	26,
	54,
	54,
	23,
	31,
	14,
	26,
	54,
	54,
	3,
};
static const Il2CppTokenIndexMethodTuple s_reversePInvokeIndices[2] = 
{
	{ 0x060002BA, 8,  (void**)&SocketNative_DebugReturn_m3D36438056F5FD4B647AD3D732F52B028557B6C6_RuntimeMethod_var, 0 },
	{ 0x060003CC, 7,  (void**)&EncryptorNative_OnNativeLog_m093EEF0A12F4E92917B10950998C3B705BF1CD8C_RuntimeMethod_var, 0 },
};
static const Il2CppTokenRangePair s_rgctxIndices[14] = 
{
	{ 0x02000004, { 0, 27 } },
	{ 0x02000005, { 27, 1 } },
	{ 0x02000006, { 28, 1 } },
	{ 0x02000007, { 29, 3 } },
	{ 0x0200004D, { 37, 10 } },
	{ 0x02000056, { 47, 8 } },
	{ 0x02000058, { 55, 10 } },
	{ 0x06000105, { 32, 1 } },
	{ 0x06000106, { 33, 1 } },
	{ 0x0600010A, { 34, 3 } },
	{ 0x060003AF, { 65, 3 } },
	{ 0x060003B2, { 68, 2 } },
	{ 0x060003B6, { 70, 2 } },
	{ 0x060003B7, { 72, 2 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[74] = 
{
	{ (Il2CppRGCTXDataType)2, 20359 },
	{ (Il2CppRGCTXDataType)3, 13980 },
	{ (Il2CppRGCTXDataType)2, 20364 },
	{ (Il2CppRGCTXDataType)3, 13981 },
	{ (Il2CppRGCTXDataType)3, 13982 },
	{ (Il2CppRGCTXDataType)2, 23647 },
	{ (Il2CppRGCTXDataType)3, 13983 },
	{ (Il2CppRGCTXDataType)2, 23648 },
	{ (Il2CppRGCTXDataType)3, 13984 },
	{ (Il2CppRGCTXDataType)3, 13985 },
	{ (Il2CppRGCTXDataType)3, 13986 },
	{ (Il2CppRGCTXDataType)2, 23649 },
	{ (Il2CppRGCTXDataType)3, 13987 },
	{ (Il2CppRGCTXDataType)3, 13988 },
	{ (Il2CppRGCTXDataType)2, 20360 },
	{ (Il2CppRGCTXDataType)3, 13989 },
	{ (Il2CppRGCTXDataType)2, 20411 },
	{ (Il2CppRGCTXDataType)3, 13990 },
	{ (Il2CppRGCTXDataType)3, 13991 },
	{ (Il2CppRGCTXDataType)3, 13992 },
	{ (Il2CppRGCTXDataType)3, 13993 },
	{ (Il2CppRGCTXDataType)2, 20369 },
	{ (Il2CppRGCTXDataType)3, 13994 },
	{ (Il2CppRGCTXDataType)3, 13995 },
	{ (Il2CppRGCTXDataType)3, 13996 },
	{ (Il2CppRGCTXDataType)2, 20366 },
	{ (Il2CppRGCTXDataType)3, 13997 },
	{ (Il2CppRGCTXDataType)2, 20378 },
	{ (Il2CppRGCTXDataType)2, 20388 },
	{ (Il2CppRGCTXDataType)3, 13998 },
	{ (Il2CppRGCTXDataType)2, 20398 },
	{ (Il2CppRGCTXDataType)3, 13999 },
	{ (Il2CppRGCTXDataType)3, 14000 },
	{ (Il2CppRGCTXDataType)3, 14001 },
	{ (Il2CppRGCTXDataType)3, 14002 },
	{ (Il2CppRGCTXDataType)2, 23650 },
	{ (Il2CppRGCTXDataType)2, 20487 },
	{ (Il2CppRGCTXDataType)2, 23651 },
	{ (Il2CppRGCTXDataType)3, 14003 },
	{ (Il2CppRGCTXDataType)3, 14004 },
	{ (Il2CppRGCTXDataType)3, 14005 },
	{ (Il2CppRGCTXDataType)3, 14006 },
	{ (Il2CppRGCTXDataType)3, 14007 },
	{ (Il2CppRGCTXDataType)3, 14008 },
	{ (Il2CppRGCTXDataType)2, 20653 },
	{ (Il2CppRGCTXDataType)3, 14009 },
	{ (Il2CppRGCTXDataType)3, 14010 },
	{ (Il2CppRGCTXDataType)1, 20679 },
	{ (Il2CppRGCTXDataType)3, 14011 },
	{ (Il2CppRGCTXDataType)3, 14012 },
	{ (Il2CppRGCTXDataType)3, 14013 },
	{ (Il2CppRGCTXDataType)2, 20679 },
	{ (Il2CppRGCTXDataType)2, 20678 },
	{ (Il2CppRGCTXDataType)3, 14014 },
	{ (Il2CppRGCTXDataType)2, 23652 },
	{ (Il2CppRGCTXDataType)1, 20688 },
	{ (Il2CppRGCTXDataType)2, 23653 },
	{ (Il2CppRGCTXDataType)3, 14015 },
	{ (Il2CppRGCTXDataType)3, 14016 },
	{ (Il2CppRGCTXDataType)2, 20687 },
	{ (Il2CppRGCTXDataType)3, 14017 },
	{ (Il2CppRGCTXDataType)3, 14018 },
	{ (Il2CppRGCTXDataType)3, 14019 },
	{ (Il2CppRGCTXDataType)3, 14020 },
	{ (Il2CppRGCTXDataType)3, 14021 },
	{ (Il2CppRGCTXDataType)1, 20693 },
	{ (Il2CppRGCTXDataType)2, 20692 },
	{ (Il2CppRGCTXDataType)3, 14022 },
	{ (Il2CppRGCTXDataType)3, 14023 },
	{ (Il2CppRGCTXDataType)3, 14024 },
	{ (Il2CppRGCTXDataType)2, 23654 },
	{ (Il2CppRGCTXDataType)2, 20702 },
	{ (Il2CppRGCTXDataType)2, 23655 },
	{ (Il2CppRGCTXDataType)2, 20703 },
};
extern const Il2CppCodeGenModule g_Photon3Unity3DCodeGenModule;
const Il2CppCodeGenModule g_Photon3Unity3DCodeGenModule = 
{
	"Photon3Unity3D.dll",
	1016,
	s_methodPointers,
	s_InvokerIndices,
	2,
	s_reversePInvokeIndices,
	14,
	s_rgctxIndices,
	74,
	s_rgctxValues,
	NULL,
};
