﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.WWW::.ctor(System.String,UnityEngine.WWWForm)
extern void WWW__ctor_mCD26DA4AF4D023C128F1E031AC85A0557B98E6BF (void);
// 0x00000002 System.String UnityEngine.WWW::get_error()
extern void WWW_get_error_mED42EEAAE7847167CCEEFF2098563F78A79F8C2A (void);
// 0x00000003 System.String UnityEngine.WWW::get_text()
extern void WWW_get_text_mC889F75AD1B47FD117196F98F3DDDC83985BD0E1 (void);
// 0x00000004 System.String UnityEngine.WWW::get_url()
extern void WWW_get_url_m201062308E01D69B4AED10B7BBA6B345F8E42089 (void);
// 0x00000005 System.Boolean UnityEngine.WWW::get_keepWaiting()
extern void WWW_get_keepWaiting_m2C52E54F48964EFD711C55A514E738CDF5D2EEB4 (void);
// 0x00000006 System.Void UnityEngine.WWW::Dispose()
extern void WWW_Dispose_m481A801C09AEF9D4B7EE5BD680ECE80C0B1E0F66 (void);
// 0x00000007 System.Boolean UnityEngine.WWW::WaitUntilDoneIfPossible()
extern void WWW_WaitUntilDoneIfPossible_mBCA182F05B2F71D4F1816951748AFAF1C4FFD5D0 (void);
static Il2CppMethodPointer s_methodPointers[7] = 
{
	WWW__ctor_mCD26DA4AF4D023C128F1E031AC85A0557B98E6BF,
	WWW_get_error_mED42EEAAE7847167CCEEFF2098563F78A79F8C2A,
	WWW_get_text_mC889F75AD1B47FD117196F98F3DDDC83985BD0E1,
	WWW_get_url_m201062308E01D69B4AED10B7BBA6B345F8E42089,
	WWW_get_keepWaiting_m2C52E54F48964EFD711C55A514E738CDF5D2EEB4,
	WWW_Dispose_m481A801C09AEF9D4B7EE5BD680ECE80C0B1E0F66,
	WWW_WaitUntilDoneIfPossible_mBCA182F05B2F71D4F1816951748AFAF1C4FFD5D0,
};
static const int32_t s_InvokerIndices[7] = 
{
	27,
	14,
	14,
	14,
	89,
	23,
	89,
};
extern const Il2CppCodeGenModule g_UnityEngine_UnityWebRequestWWWModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_UnityWebRequestWWWModuleCodeGenModule = 
{
	"UnityEngine.UnityWebRequestWWWModule.dll",
	7,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
