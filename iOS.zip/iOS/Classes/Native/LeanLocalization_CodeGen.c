﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void Lean.Localization.LeanLocalizedAudioSource::UpdateTranslation(Lean.Localization.LeanTranslation)
extern void LeanLocalizedAudioSource_UpdateTranslation_m3D5AD2A324BF04DA42AE44BF16D833CB5882225A (void);
// 0x00000002 System.Void Lean.Localization.LeanLocalizedAudioSource::Awake()
extern void LeanLocalizedAudioSource_Awake_m2CD9197843E56763D7B4FB5137062DD977D75C77 (void);
// 0x00000003 System.Void Lean.Localization.LeanLocalizedAudioSource::.ctor()
extern void LeanLocalizedAudioSource__ctor_mC50AA6BBC75C5F3AD8C44396B76335A13DB4B9F4 (void);
// 0x00000004 System.Collections.Generic.List`1<Lean.Localization.LeanLocalizedDropdown_Option> Lean.Localization.LeanLocalizedDropdown::get_Options()
extern void LeanLocalizedDropdown_get_Options_m8EFBECC437CD782467065B75274CEF69E2DEECEA (void);
// 0x00000005 System.Void Lean.Localization.LeanLocalizedDropdown::Register(Lean.Localization.LeanToken)
extern void LeanLocalizedDropdown_Register_m5FD9B89F4FE477A2BAC09463F0DF137FA5E56F14 (void);
// 0x00000006 System.Void Lean.Localization.LeanLocalizedDropdown::Unregister(Lean.Localization.LeanToken)
extern void LeanLocalizedDropdown_Unregister_m9FEC3B281146931C3F4A1A9F7F2B1DDAD43210CF (void);
// 0x00000007 System.Void Lean.Localization.LeanLocalizedDropdown::UnregisterAll()
extern void LeanLocalizedDropdown_UnregisterAll_m6143B2617C9870289E61E60874D97BE92EBB6F2F (void);
// 0x00000008 System.Void Lean.Localization.LeanLocalizedDropdown::UpdateLocalization()
extern void LeanLocalizedDropdown_UpdateLocalization_mFA39661F7996B1300E1F054FFA33E15285144656 (void);
// 0x00000009 System.Void Lean.Localization.LeanLocalizedDropdown::OnEnable()
extern void LeanLocalizedDropdown_OnEnable_m36A9E1BF86D04AFEEA8DECFD2E0E6A7BC269DC48 (void);
// 0x0000000A System.Void Lean.Localization.LeanLocalizedDropdown::OnDisable()
extern void LeanLocalizedDropdown_OnDisable_m9D6596FAF435C61518AA08C6261273BB5457C0CA (void);
// 0x0000000B System.Void Lean.Localization.LeanLocalizedDropdown::.ctor()
extern void LeanLocalizedDropdown__ctor_m284ADF4473EB1DDEDFA7AFDF31A3F66DBC81B5FA (void);
// 0x0000000C System.Void Lean.Localization.LeanLocalizedImage::UpdateTranslation(Lean.Localization.LeanTranslation)
extern void LeanLocalizedImage_UpdateTranslation_mD283A5A9FEFF54D08290BB31FA3B3A5270EE091D (void);
// 0x0000000D System.Void Lean.Localization.LeanLocalizedImage::Awake()
extern void LeanLocalizedImage_Awake_mEC882AF71C47F7E7C9F4D20B8C136983FF0C1052 (void);
// 0x0000000E System.Void Lean.Localization.LeanLocalizedImage::.ctor()
extern void LeanLocalizedImage__ctor_mC9038611807CF10C3E08C48B2B790227428DB05F (void);
// 0x0000000F System.Void Lean.Localization.LeanLocalizedRenderer::UpdateTranslation(Lean.Localization.LeanTranslation)
extern void LeanLocalizedRenderer_UpdateTranslation_m87869DDCEA3E79003D8C22CFDC78BE89E86FBA5B (void);
// 0x00000010 System.Void Lean.Localization.LeanLocalizedRenderer::Awake()
extern void LeanLocalizedRenderer_Awake_mE6E5EB98B9028DDF99F119FA535ED4D9B67E8E7B (void);
// 0x00000011 System.Void Lean.Localization.LeanLocalizedRenderer::.ctor()
extern void LeanLocalizedRenderer__ctor_mE1A186BA45E82CE3FE2A71EB726B5B87CD3FDED8 (void);
// 0x00000012 System.Void Lean.Localization.LeanLocalizedSpriteRenderer::UpdateTranslation(Lean.Localization.LeanTranslation)
extern void LeanLocalizedSpriteRenderer_UpdateTranslation_mB940DAE92FC6B87E536D183CF7CA46BDA476AA2D (void);
// 0x00000013 System.Void Lean.Localization.LeanLocalizedSpriteRenderer::Awake()
extern void LeanLocalizedSpriteRenderer_Awake_mCF51A57D7D1D60955F180EBBDBB497E401E435D6 (void);
// 0x00000014 System.Void Lean.Localization.LeanLocalizedSpriteRenderer::.ctor()
extern void LeanLocalizedSpriteRenderer__ctor_m9B029B77693D2DA3A724BFB67AB51275876D110A (void);
// 0x00000015 System.Void Lean.Localization.LeanLocalizedText::UpdateTranslation(Lean.Localization.LeanTranslation)
extern void LeanLocalizedText_UpdateTranslation_mF9AA229D7EA144B08AE9D4D923E276B81D2DACF0 (void);
// 0x00000016 System.Void Lean.Localization.LeanLocalizedText::Awake()
extern void LeanLocalizedText_Awake_mB4C1661B66224B8E5C5CFFD4161023CFB1C860BA (void);
// 0x00000017 System.Void Lean.Localization.LeanLocalizedText::.ctor()
extern void LeanLocalizedText__ctor_mDCAD88AE98B43BBEA22DC0E8A1BA338843D1AB64 (void);
// 0x00000018 System.Void Lean.Localization.LeanLocalizedTextFont::UpdateTranslation(Lean.Localization.LeanTranslation)
extern void LeanLocalizedTextFont_UpdateTranslation_m401F13C1326AFCA3CE4C3C102A7E3C03C2DCCF01 (void);
// 0x00000019 System.Void Lean.Localization.LeanLocalizedTextFont::Awake()
extern void LeanLocalizedTextFont_Awake_mF0F7F369C12BA5A57995E0819BD729413F9E6761 (void);
// 0x0000001A System.Void Lean.Localization.LeanLocalizedTextFont::.ctor()
extern void LeanLocalizedTextFont__ctor_m27891F7026C1BEA948BE443F17F5D2933F98E333 (void);
// 0x0000001B System.Void Lean.Localization.LeanLocalizedTextMesh::UpdateTranslation(Lean.Localization.LeanTranslation)
extern void LeanLocalizedTextMesh_UpdateTranslation_m3DA1541B85B2E6845CB01291B4FA56AFEBF70D67 (void);
// 0x0000001C System.Void Lean.Localization.LeanLocalizedTextMesh::Awake()
extern void LeanLocalizedTextMesh_Awake_m2FBC625039996CF0E997441673982C2E1831554A (void);
// 0x0000001D System.Void Lean.Localization.LeanLocalizedTextMesh::.ctor()
extern void LeanLocalizedTextMesh__ctor_m7FAED80A469EFCBCB29CEBF01736BDC67616ED3B (void);
// 0x0000001E System.Void Lean.Localization.LeanLocalizedTextMeshFont::UpdateTranslation(Lean.Localization.LeanTranslation)
extern void LeanLocalizedTextMeshFont_UpdateTranslation_m4DE47C3A4D78EF74D9D7EFBA4CBE4E8C830D8A13 (void);
// 0x0000001F System.Void Lean.Localization.LeanLocalizedTextMeshFont::Awake()
extern void LeanLocalizedTextMeshFont_Awake_mF6E843C1ECA65ED9738A150D8C506BD4AC08F73C (void);
// 0x00000020 System.Void Lean.Localization.LeanLocalizedTextMeshFont::.ctor()
extern void LeanLocalizedTextMeshFont__ctor_mFB7B00933CF92021CAD34F4FD5471C8054C9F767 (void);
// 0x00000021 System.Void Lean.Localization.ILocalizationHandler::UpdateLocalization()
// 0x00000022 System.Void Lean.Localization.ILocalizationHandler::Register(Lean.Localization.LeanToken)
// 0x00000023 System.Void Lean.Localization.ILocalizationHandler::Unregister(Lean.Localization.LeanToken)
// 0x00000024 System.Void Lean.Localization.ILocalizationHandler::UnregisterAll()
// 0x00000025 System.Void Lean.Localization.LeanLanguage::set_Name(System.String)
extern void LeanLanguage_set_Name_mBC291BA04E0C372ED91CCE09FEEDB4349223825C (void);
// 0x00000026 System.String Lean.Localization.LeanLanguage::get_Name()
extern void LeanLanguage_get_Name_m1CD8874A9DA7FA9351C1244A29B483B0B6429747 (void);
// 0x00000027 System.Collections.Generic.List`1<System.String> Lean.Localization.LeanLanguage::get_Cultures()
extern void LeanLanguage_get_Cultures_m7959777C0A5F72CE1686EE625388D75844F99BAD (void);
// 0x00000028 System.Void Lean.Localization.LeanLanguage::.ctor()
extern void LeanLanguage__ctor_mF2943AE96D93AA0DB79FB665DA5E28D585E89D1D (void);
// 0x00000029 System.Collections.Generic.List`1<Lean.Localization.LeanLanguageCSV_Entry> Lean.Localization.LeanLanguageCSV::get_Entries()
extern void LeanLanguageCSV_get_Entries_mD11DB073AD3BB42CF99F2F0863936F7D85A63A81 (void);
// 0x0000002A System.Void Lean.Localization.LeanLanguageCSV::Compile(System.String,System.String)
extern void LeanLanguageCSV_Compile_m5EA2F3DCF489559073849B076552F82A36F41A8D (void);
// 0x0000002B System.Void Lean.Localization.LeanLanguageCSV::Clear()
extern void LeanLanguageCSV_Clear_m176C91687BAD81DC7C2861C8819F1760D1197519 (void);
// 0x0000002C System.Void Lean.Localization.LeanLanguageCSV::LoadFromSource()
extern void LeanLanguageCSV_LoadFromSource_mEFED077B9EAE08DD618E8BC6F4534B1903DBFC33 (void);
// 0x0000002D System.Void Lean.Localization.LeanLanguageCSV::.ctor()
extern void LeanLanguageCSV__ctor_mDD24A33328C7FB36F1BD8FB778E49D8F579E3C69 (void);
// 0x0000002E System.Void Lean.Localization.LeanLanguageCSV::.cctor()
extern void LeanLanguageCSV__cctor_m39EBDAEBBAB1F58CF4EE97BFAF221E5FF0961CF9 (void);
// 0x0000002F System.Void Lean.Localization.LeanLanguageNameAttribute::.ctor()
extern void LeanLanguageNameAttribute__ctor_m310453BE0490CE858AF56D4A7D4C033DC1A65869 (void);
// 0x00000030 System.Boolean Lean.Localization.LeanLocalToken::TryGetLocalToken(UnityEngine.GameObject,System.String,Lean.Localization.LeanToken&)
extern void LeanLocalToken_TryGetLocalToken_m09CD3AAA6AAAF99E435E4C4C99B7D3176A8D88A9 (void);
// 0x00000031 System.Void Lean.Localization.LeanLocalToken::Compile(System.String,System.String)
extern void LeanLocalToken_Compile_m585B0C868CD63DBDC31E251E8EBA9BF907910C78 (void);
// 0x00000032 System.Void Lean.Localization.LeanLocalToken::.ctor()
extern void LeanLocalToken__ctor_m789C648797492C9B720459F61B688FE7088746FD (void);
// 0x00000033 System.Void Lean.Localization.LeanLocalToken::.cctor()
extern void LeanLocalToken__cctor_mF3DCC459C118C952DDB9F6646C096F5C5B3CB02F (void);
// 0x00000034 System.Void Lean.Localization.LeanLocalization::add_OnLocalizationChanged(System.Action)
extern void LeanLocalization_add_OnLocalizationChanged_m94C19E1856E30C503763C80CCE647150F1E993AF (void);
// 0x00000035 System.Void Lean.Localization.LeanLocalization::remove_OnLocalizationChanged(System.Action)
extern void LeanLocalization_remove_OnLocalizationChanged_m80D98D6BE071602EF82C9B511BDE6491E825B357 (void);
// 0x00000036 System.Collections.Generic.List`1<Lean.Localization.LeanLanguage> Lean.Localization.LeanLocalization::get_Languages()
extern void LeanLocalization_get_Languages_mA65ECCCAB0C0BA044B8B8BFE74F576E9724ED12F (void);
// 0x00000037 System.Collections.Generic.List`1<Lean.Localization.LeanPrefab> Lean.Localization.LeanLocalization::get_Prefabs()
extern void LeanLocalization_get_Prefabs_mD90386DAA8E02B169B923AD305D7BF18784CD73B (void);
// 0x00000038 System.Boolean Lean.Localization.LeanLocalization::get_CurrentSaveLanguage()
extern void LeanLocalization_get_CurrentSaveLanguage_mE1F1ED35B45A5CDD07A330D18E916A8A303BD0D6 (void);
// 0x00000039 System.Void Lean.Localization.LeanLocalization::set_CurrentLanguage(System.String)
extern void LeanLocalization_set_CurrentLanguage_mFF7DE5C168273DD7B44C680024CCA616994DA95F (void);
// 0x0000003A System.String Lean.Localization.LeanLocalization::get_CurrentLanguage()
extern void LeanLocalization_get_CurrentLanguage_mE21CEB2E374B02AD95296ECBFA3930A9F110511A (void);
// 0x0000003B System.Void Lean.Localization.LeanLocalization::RegisterToken(System.String,Lean.Localization.LeanToken)
extern void LeanLocalization_RegisterToken_m8FE99AA4FDF661D33AD531FB0BA2E3C8239B3232 (void);
// 0x0000003C Lean.Localization.LeanTranslation Lean.Localization.LeanLocalization::RegisterTranslation(System.String)
extern void LeanLocalization_RegisterTranslation_mC2AA95C83C5071E8EB670C62395772C332A81679 (void);
// 0x0000003D System.Void Lean.Localization.LeanLocalization::ClearSave()
extern void LeanLocalization_ClearSave_m3C3666DD031E70BBC321B9DEDD4DF48A5AA4571F (void);
// 0x0000003E System.Void Lean.Localization.LeanLocalization::SaveNow()
extern void LeanLocalization_SaveNow_mBC3E848B60C3C72F3E05909D4907A5053ED3C551 (void);
// 0x0000003F System.Void Lean.Localization.LeanLocalization::LoadNow()
extern void LeanLocalization_LoadNow_m3B2319EA74AC1B7046E7198354B75182946FF043 (void);
// 0x00000040 System.Void Lean.Localization.LeanLocalization::SetCurrentLanguage(System.String)
extern void LeanLocalization_SetCurrentLanguage_mFF7163299C3604A0D6EC1FB3949497630CD08FB5 (void);
// 0x00000041 System.Void Lean.Localization.LeanLocalization::SetCurrentLanguage(System.Int32)
extern void LeanLocalization_SetCurrentLanguage_mA7EDE4BB40E2921FA24F173D51CF4829F787AD1D (void);
// 0x00000042 System.Boolean Lean.Localization.LeanLocalization::LanguageExists(System.String)
extern void LeanLocalization_LanguageExists_mFD4B3E1264B4483606759939C86F345449127293 (void);
// 0x00000043 System.Boolean Lean.Localization.LeanLocalization::TryGetLanguage(System.String,Lean.Localization.LeanLanguage&)
extern void LeanLocalization_TryGetLanguage_m8BEA90BE74F86273B5F8EE1828E268BF6AFD4FD6 (void);
// 0x00000044 System.Void Lean.Localization.LeanLocalization::AddPrefab(UnityEngine.Object)
extern void LeanLocalization_AddPrefab_mE93415C6FCD516F9F19D1772C4435A39E99553CA (void);
// 0x00000045 Lean.Localization.LeanLanguage Lean.Localization.LeanLocalization::AddLanguage(System.String,System.String[])
extern void LeanLocalization_AddLanguage_m94033EABB6B296E7C335756E4C3D85CE8BE17511 (void);
// 0x00000046 Lean.Localization.LeanToken Lean.Localization.LeanLocalization::AddTokenToFirst(System.String)
extern void LeanLocalization_AddTokenToFirst_m45F34C3AE6CB6B4A95D3DD847C853120789594F1 (void);
// 0x00000047 Lean.Localization.LeanToken Lean.Localization.LeanLocalization::AddToken(System.String)
extern void LeanLocalization_AddToken_m4B98DE704036D9FFA1B9A43924DEEEA373206CAA (void);
// 0x00000048 System.Void Lean.Localization.LeanLocalization::SetToken(System.String,System.String,System.Boolean)
extern void LeanLocalization_SetToken_m8247978E3CDD219DD4EA02D72465F24D2286362A (void);
// 0x00000049 System.String Lean.Localization.LeanLocalization::GetToken(System.String,System.String)
extern void LeanLocalization_GetToken_mF29621B59E1248F72D6C2BD12ED775F738BFCA79 (void);
// 0x0000004A Lean.Localization.LeanPhrase Lean.Localization.LeanLocalization::AddPhraseToFirst(System.String)
extern void LeanLocalization_AddPhraseToFirst_mDB84D9AB2165E15D57EAC2393D857FB15A50E12D (void);
// 0x0000004B Lean.Localization.LeanPhrase Lean.Localization.LeanLocalization::AddPhrase(System.String)
extern void LeanLocalization_AddPhrase_m7D90BC01075268E09414D215FEB06F20C725A83F (void);
// 0x0000004C Lean.Localization.LeanTranslation Lean.Localization.LeanLocalization::GetTranslation(System.String)
extern void LeanLocalization_GetTranslation_mC0C24BB93C0D0DB5479321D491B78255FFA2946A (void);
// 0x0000004D System.String Lean.Localization.LeanLocalization::GetTranslationText(System.String,System.String,System.Boolean)
extern void LeanLocalization_GetTranslationText_m56249FE91505DD542E5B7C0529F99D7D481455A4 (void);
// 0x0000004E T Lean.Localization.LeanLocalization::GetTranslationObject(System.String,T)
// 0x0000004F System.Void Lean.Localization.LeanLocalization::UpdateTranslations(System.Boolean)
extern void LeanLocalization_UpdateTranslations_m4AD9BA5429972143B16255120BE9816A5E8616DA (void);
// 0x00000050 System.Void Lean.Localization.LeanLocalization::DelayUpdateTranslations()
extern void LeanLocalization_DelayUpdateTranslations_m10E7A3F98114D5B868A98B22C57DC0EC66499EC1 (void);
// 0x00000051 System.Void Lean.Localization.LeanLocalization::OnEnable()
extern void LeanLocalization_OnEnable_mC67B06812514191898CB3E9AB809790395FDEB99 (void);
// 0x00000052 System.Void Lean.Localization.LeanLocalization::OnDisable()
extern void LeanLocalization_OnDisable_m7DF614D1CAB89285B7F0A65F49033B0EF293B98B (void);
// 0x00000053 System.Void Lean.Localization.LeanLocalization::Update()
extern void LeanLocalization_Update_m51A70B02277097702F3F4A5C9C2E1DF9B126430C (void);
// 0x00000054 System.Void Lean.Localization.LeanLocalization::RegisterAndBuild()
extern void LeanLocalization_RegisterAndBuild_mD4895D15A67EE63635837969686CD3A4964F3C68 (void);
// 0x00000055 System.Void Lean.Localization.LeanLocalization::UpdateCurrentLanguage()
extern void LeanLocalization_UpdateCurrentLanguage_m334D7AB35432580CBA53B795562CA35EF07C561C (void);
// 0x00000056 System.String Lean.Localization.LeanLocalization::FindLanguageName(System.String)
extern void LeanLocalization_FindLanguageName_m47B960142137BB7CB354084DB0233361CE6A163A (void);
// 0x00000057 System.Void Lean.Localization.LeanLocalization::.ctor()
extern void LeanLocalization__ctor_m3D27A4234223C52836736630645C52A6791822A8 (void);
// 0x00000058 System.Void Lean.Localization.LeanLocalization::.cctor()
extern void LeanLocalization__cctor_mE54F2F68558DFBD00835BCE8BD04B1EBF26F0614 (void);
// 0x00000059 System.Void Lean.Localization.LeanLocalizedBehaviour::set_TranslationName(System.String)
extern void LeanLocalizedBehaviour_set_TranslationName_m5313EA8203C958D582909C10EA71518DB5D3E450 (void);
// 0x0000005A System.String Lean.Localization.LeanLocalizedBehaviour::get_TranslationName()
extern void LeanLocalizedBehaviour_get_TranslationName_mDF43128F5D7343BEF712A2EDF205C687FC42EABD (void);
// 0x0000005B System.Void Lean.Localization.LeanLocalizedBehaviour::Register(Lean.Localization.LeanToken)
extern void LeanLocalizedBehaviour_Register_m99D97ABEC515D00E29B7FD498FB7E6B9628A0753 (void);
// 0x0000005C System.Void Lean.Localization.LeanLocalizedBehaviour::Unregister(Lean.Localization.LeanToken)
extern void LeanLocalizedBehaviour_Unregister_mB84F628497154DC747C91A544CAC6A31D030BA41 (void);
// 0x0000005D System.Void Lean.Localization.LeanLocalizedBehaviour::UnregisterAll()
extern void LeanLocalizedBehaviour_UnregisterAll_m674A6DDD8950035D1CCFA13AE3BBF4C577BFB948 (void);
// 0x0000005E System.Void Lean.Localization.LeanLocalizedBehaviour::UpdateTranslation(Lean.Localization.LeanTranslation)
// 0x0000005F System.Void Lean.Localization.LeanLocalizedBehaviour::UpdateLocalization()
extern void LeanLocalizedBehaviour_UpdateLocalization_mD557D908401E468B3A0A16D7BC9AA0772EDA4BDB (void);
// 0x00000060 System.Void Lean.Localization.LeanLocalizedBehaviour::OnEnable()
extern void LeanLocalizedBehaviour_OnEnable_m9A83E5D5C6809B1B962FAF0F5998BEABF0A115E4 (void);
// 0x00000061 System.Void Lean.Localization.LeanLocalizedBehaviour::OnDisable()
extern void LeanLocalizedBehaviour_OnDisable_mBC512ED853DB31A92920D676B21AD53EDB0B81EC (void);
// 0x00000062 System.Void Lean.Localization.LeanLocalizedBehaviour::.ctor()
extern void LeanLocalizedBehaviour__ctor_m2D8565C35FB6B9A9AB50EC2D63CEEEFC069AA9B6 (void);
// 0x00000063 System.Void Lean.Localization.LeanPhrase::set_Data(Lean.Localization.LeanPhrase_DataType)
extern void LeanPhrase_set_Data_m6DE196AB34FEB16D7A46F8D5FE8E93AA4D677CF3 (void);
// 0x00000064 Lean.Localization.LeanPhrase_DataType Lean.Localization.LeanPhrase::get_Data()
extern void LeanPhrase_get_Data_mA130C6A1157C0385884DAE799B80EA19C0CA42BB (void);
// 0x00000065 System.Collections.Generic.List`1<Lean.Localization.LeanPhrase_Entry> Lean.Localization.LeanPhrase::get_Entries()
extern void LeanPhrase_get_Entries_m7DD29DDA0B9C7CCD209F7DC521BF10EC52F36A96 (void);
// 0x00000066 System.Void Lean.Localization.LeanPhrase::Clear()
extern void LeanPhrase_Clear_m57F5BD279BD5682560B2FA93E56ACE45B6F75B09 (void);
// 0x00000067 System.Void Lean.Localization.LeanPhrase::Compile(System.String,System.String)
extern void LeanPhrase_Compile_mB376BA309F12151403AC76B03B9992CC17295460 (void);
// 0x00000068 System.Void Lean.Localization.LeanPhrase::Compile(Lean.Localization.LeanTranslation,Lean.Localization.LeanPhrase_Entry,System.Boolean)
extern void LeanPhrase_Compile_m9DE37074D06D786B52FAE1643AC323C2B7FCC449 (void);
// 0x00000069 System.Void Lean.Localization.LeanPhrase::Compile(Lean.Localization.LeanTranslation,System.Object,System.Boolean)
extern void LeanPhrase_Compile_mF5E61689C926F73EBD033B6D18D1F135CA0DFFD9 (void);
// 0x0000006A System.Boolean Lean.Localization.LeanPhrase::TryFindTranslation(System.String,Lean.Localization.LeanPhrase_Entry&)
extern void LeanPhrase_TryFindTranslation_mBEBEBFF7FF1906F65D104B4F5C2D906254FBEE2A (void);
// 0x0000006B System.Void Lean.Localization.LeanPhrase::RemoveTranslation(System.String)
extern void LeanPhrase_RemoveTranslation_m11E8111D4D4B7B15AF882FFD2C667CBC773FECD8 (void);
// 0x0000006C Lean.Localization.LeanPhrase_Entry Lean.Localization.LeanPhrase::AddEntry(System.String,System.String,UnityEngine.Object)
extern void LeanPhrase_AddEntry_mFC451F94555BD83BFD110FEF02E8E578E2903911 (void);
// 0x0000006D System.Void Lean.Localization.LeanPhrase::.ctor()
extern void LeanPhrase__ctor_m9C14D057589FFC0995E691D466F832B20EC856B9 (void);
// 0x0000006E System.Collections.Generic.List`1<Lean.Localization.LeanSource> Lean.Localization.LeanPrefab::get_Sources()
extern void LeanPrefab_get_Sources_mA6EC3CEBF604C99B48892CED52474E3BA475AA99 (void);
// 0x0000006F System.Boolean Lean.Localization.LeanPrefab::RebuildSources()
extern void LeanPrefab_RebuildSources_m9E71B8054A5B19BA68AE2EC209B93DFC73FC7A53 (void);
// 0x00000070 System.Boolean Lean.Localization.LeanPrefab::FinalizeBuild()
extern void LeanPrefab_FinalizeBuild_m72C7E44D0D268FC77118448C311A605B76D49409 (void);
// 0x00000071 System.Void Lean.Localization.LeanPrefab::AddSource(Lean.Localization.LeanSource)
extern void LeanPrefab_AddSource_m080EEAF469E160C0FF8CC327A03ACF04051E86D6 (void);
// 0x00000072 System.Void Lean.Localization.LeanPrefab::FindFromGameObject(UnityEngine.Transform)
extern void LeanPrefab_FindFromGameObject_m0DA312D11C7FAA62D195482EDE8D2AA53404D183 (void);
// 0x00000073 System.Void Lean.Localization.LeanPrefab::.ctor()
extern void LeanPrefab__ctor_m6E3F3623E232BF943318EF7B778C1B3A01C4D0B2 (void);
// 0x00000074 System.Void Lean.Localization.LeanPrefab::.cctor()
extern void LeanPrefab__cctor_mB75E0EEACE308E7769DCB7457EF640AC286D8B02 (void);
// 0x00000075 System.Void Lean.Localization.LeanSource::Compile(System.String,System.String)
// 0x00000076 System.Void Lean.Localization.LeanSource::Register()
extern void LeanSource_Register_m9792577A20F1A250F19A7B0E9C0B4ACC9E1587C4 (void);
// 0x00000077 System.Void Lean.Localization.LeanSource::Unregister()
extern void LeanSource_Unregister_mC38CC638900D1132BBD47F60B762CE445D3F7848 (void);
// 0x00000078 System.Void Lean.Localization.LeanSource::OnEnable()
extern void LeanSource_OnEnable_m2EDDFD19F3ED02D12261BDC3D867CC0EACABD361 (void);
// 0x00000079 System.Void Lean.Localization.LeanSource::OnDisable()
extern void LeanSource_OnDisable_mFA6F7745CD407966841DF09A22A943D4FF7B6456 (void);
// 0x0000007A System.Void Lean.Localization.LeanSource::.ctor()
extern void LeanSource__ctor_mD0EEF9005656B10D9FF5B9F297711B18F306B609 (void);
// 0x0000007B System.Void Lean.Localization.LeanSource::.cctor()
extern void LeanSource__cctor_m090835FBE11288A88CAE455B762D8D665F42C6E9 (void);
// 0x0000007C System.Void Lean.Localization.LeanToken::set_Value(System.String)
extern void LeanToken_set_Value_m75542500D6C1DD802F44C465D05D64EF86A0DC97 (void);
// 0x0000007D System.String Lean.Localization.LeanToken::get_Value()
extern void LeanToken_get_Value_m1B5B223EAFAE2109B374456956E8DCFC0BAD98DE (void);
// 0x0000007E System.Void Lean.Localization.LeanToken::SetValue(System.Single)
extern void LeanToken_SetValue_m0630BBBE46DC941D4A30CF7B7B27C9E6A18A835A (void);
// 0x0000007F System.Void Lean.Localization.LeanToken::SetValue(System.String)
extern void LeanToken_SetValue_mBD3643BA50BC04AEC53EF7CA3B8EE4891E8087E2 (void);
// 0x00000080 System.Void Lean.Localization.LeanToken::SetValue(System.Int32)
extern void LeanToken_SetValue_m284DA247E7863B9E4A830D6841FA7BC21F96EE0F (void);
// 0x00000081 System.Void Lean.Localization.LeanToken::Register(Lean.Localization.ILocalizationHandler)
extern void LeanToken_Register_m83F73992ECC9024506A41298F8E62D2BC4BD37E1 (void);
// 0x00000082 System.Void Lean.Localization.LeanToken::Unregister(Lean.Localization.ILocalizationHandler)
extern void LeanToken_Unregister_m6409659BAE8707F759A756338339696C9A263A91 (void);
// 0x00000083 System.Void Lean.Localization.LeanToken::UnregisterAll()
extern void LeanToken_UnregisterAll_mEDCAE02E986F5A5AAF9AD7A8A406D99B58AAD1D7 (void);
// 0x00000084 System.Void Lean.Localization.LeanToken::Compile(System.String,System.String)
extern void LeanToken_Compile_mF8C4685DA56BBC8D4888DB571BF2A7C08FDCA82F (void);
// 0x00000085 System.Void Lean.Localization.LeanToken::OnDisable()
extern void LeanToken_OnDisable_m59DFD56899194180401D71F8A800FF23A7657851 (void);
// 0x00000086 System.Void Lean.Localization.LeanToken::.ctor()
extern void LeanToken__ctor_mBF6F28DED1F036725D572ADA122BDE78AB911AA6 (void);
// 0x00000087 System.Void Lean.Localization.LeanToken::.cctor()
extern void LeanToken__cctor_mC817DA5EE22B1AF7C1A06A85634886DB7A9EB7C5 (void);
// 0x00000088 System.String Lean.Localization.LeanTranslation::get_Name()
extern void LeanTranslation_get_Name_m6515502FAEB313CB03AD4DB1622885C34D155C02 (void);
// 0x00000089 System.Collections.Generic.List`1<Lean.Localization.LeanTranslation_Entry> Lean.Localization.LeanTranslation::get_Entries()
extern void LeanTranslation_get_Entries_m43784A8CE5B738920B7A929B5C0DE292F5CA5A4E (void);
// 0x0000008A System.Void Lean.Localization.LeanTranslation::.ctor(System.String)
extern void LeanTranslation__ctor_mD41363D9871DBBE0908EE72B573EA47D9C3D427E (void);
// 0x0000008B System.Void Lean.Localization.LeanTranslation::Register(System.String,UnityEngine.Object)
extern void LeanTranslation_Register_m1DCE13C2244B6B325639E4B485F9DA4FEA72EAF5 (void);
// 0x0000008C System.Void Lean.Localization.LeanTranslation::Clear()
extern void LeanTranslation_Clear_m8BF271653A1EC6F676CD53841944BEA978AA5EF0 (void);
// 0x0000008D System.Int32 Lean.Localization.LeanTranslation::LanguageCount(System.String)
extern void LeanTranslation_LanguageCount_m9F38563EBBF596AA6EEA63E667BDAFCE682489C9 (void);
// 0x0000008E System.String Lean.Localization.LeanTranslation::FormatText(System.String,System.String,Lean.Localization.ILocalizationHandler,UnityEngine.GameObject)
extern void LeanTranslation_FormatText_mA8BB40EC96AA7F15201955E1C2E2AA0CD818B057 (void);
// 0x0000008F System.Boolean Lean.Localization.LeanTranslation::Match(System.String,System.Text.StringBuilder)
extern void LeanTranslation_Match_m3704780F3AADC5B2A67CA3897707508979DE684F (void);
// 0x00000090 System.Void Lean.Localization.LeanTranslation::.cctor()
extern void LeanTranslation__cctor_m10E06E5DFDDE42D69C1FD699538252CF52D31BF8 (void);
// 0x00000091 System.Void Lean.Localization.LeanTranslationNameAttribute::.ctor()
extern void LeanTranslationNameAttribute__ctor_m81921D20F828AFD30DFAC7962FCE9BC7168B310B (void);
// 0x00000092 System.Void Lean.Localization.LeanLocalizedDropdown_Option::.ctor()
extern void Option__ctor_mB135F7787ADDA0D10DFB35222114F64D1CB57D2D (void);
// 0x00000093 System.Void Lean.Localization.LeanLanguageCSV_Entry::.ctor()
extern void Entry__ctor_mDD7512E04E4A2282696F4A91FFC8A7E4D6818433 (void);
// 0x00000094 System.Void Lean.Localization.LeanPhrase_Entry::.ctor()
extern void Entry__ctor_mA321792CEC80BF2B859D0D81883BEF92CBEF7FCB (void);
static Il2CppMethodPointer s_methodPointers[148] = 
{
	LeanLocalizedAudioSource_UpdateTranslation_m3D5AD2A324BF04DA42AE44BF16D833CB5882225A,
	LeanLocalizedAudioSource_Awake_m2CD9197843E56763D7B4FB5137062DD977D75C77,
	LeanLocalizedAudioSource__ctor_mC50AA6BBC75C5F3AD8C44396B76335A13DB4B9F4,
	LeanLocalizedDropdown_get_Options_m8EFBECC437CD782467065B75274CEF69E2DEECEA,
	LeanLocalizedDropdown_Register_m5FD9B89F4FE477A2BAC09463F0DF137FA5E56F14,
	LeanLocalizedDropdown_Unregister_m9FEC3B281146931C3F4A1A9F7F2B1DDAD43210CF,
	LeanLocalizedDropdown_UnregisterAll_m6143B2617C9870289E61E60874D97BE92EBB6F2F,
	LeanLocalizedDropdown_UpdateLocalization_mFA39661F7996B1300E1F054FFA33E15285144656,
	LeanLocalizedDropdown_OnEnable_m36A9E1BF86D04AFEEA8DECFD2E0E6A7BC269DC48,
	LeanLocalizedDropdown_OnDisable_m9D6596FAF435C61518AA08C6261273BB5457C0CA,
	LeanLocalizedDropdown__ctor_m284ADF4473EB1DDEDFA7AFDF31A3F66DBC81B5FA,
	LeanLocalizedImage_UpdateTranslation_mD283A5A9FEFF54D08290BB31FA3B3A5270EE091D,
	LeanLocalizedImage_Awake_mEC882AF71C47F7E7C9F4D20B8C136983FF0C1052,
	LeanLocalizedImage__ctor_mC9038611807CF10C3E08C48B2B790227428DB05F,
	LeanLocalizedRenderer_UpdateTranslation_m87869DDCEA3E79003D8C22CFDC78BE89E86FBA5B,
	LeanLocalizedRenderer_Awake_mE6E5EB98B9028DDF99F119FA535ED4D9B67E8E7B,
	LeanLocalizedRenderer__ctor_mE1A186BA45E82CE3FE2A71EB726B5B87CD3FDED8,
	LeanLocalizedSpriteRenderer_UpdateTranslation_mB940DAE92FC6B87E536D183CF7CA46BDA476AA2D,
	LeanLocalizedSpriteRenderer_Awake_mCF51A57D7D1D60955F180EBBDBB497E401E435D6,
	LeanLocalizedSpriteRenderer__ctor_m9B029B77693D2DA3A724BFB67AB51275876D110A,
	LeanLocalizedText_UpdateTranslation_mF9AA229D7EA144B08AE9D4D923E276B81D2DACF0,
	LeanLocalizedText_Awake_mB4C1661B66224B8E5C5CFFD4161023CFB1C860BA,
	LeanLocalizedText__ctor_mDCAD88AE98B43BBEA22DC0E8A1BA338843D1AB64,
	LeanLocalizedTextFont_UpdateTranslation_m401F13C1326AFCA3CE4C3C102A7E3C03C2DCCF01,
	LeanLocalizedTextFont_Awake_mF0F7F369C12BA5A57995E0819BD729413F9E6761,
	LeanLocalizedTextFont__ctor_m27891F7026C1BEA948BE443F17F5D2933F98E333,
	LeanLocalizedTextMesh_UpdateTranslation_m3DA1541B85B2E6845CB01291B4FA56AFEBF70D67,
	LeanLocalizedTextMesh_Awake_m2FBC625039996CF0E997441673982C2E1831554A,
	LeanLocalizedTextMesh__ctor_m7FAED80A469EFCBCB29CEBF01736BDC67616ED3B,
	LeanLocalizedTextMeshFont_UpdateTranslation_m4DE47C3A4D78EF74D9D7EFBA4CBE4E8C830D8A13,
	LeanLocalizedTextMeshFont_Awake_mF6E843C1ECA65ED9738A150D8C506BD4AC08F73C,
	LeanLocalizedTextMeshFont__ctor_mFB7B00933CF92021CAD34F4FD5471C8054C9F767,
	NULL,
	NULL,
	NULL,
	NULL,
	LeanLanguage_set_Name_mBC291BA04E0C372ED91CCE09FEEDB4349223825C,
	LeanLanguage_get_Name_m1CD8874A9DA7FA9351C1244A29B483B0B6429747,
	LeanLanguage_get_Cultures_m7959777C0A5F72CE1686EE625388D75844F99BAD,
	LeanLanguage__ctor_mF2943AE96D93AA0DB79FB665DA5E28D585E89D1D,
	LeanLanguageCSV_get_Entries_mD11DB073AD3BB42CF99F2F0863936F7D85A63A81,
	LeanLanguageCSV_Compile_m5EA2F3DCF489559073849B076552F82A36F41A8D,
	LeanLanguageCSV_Clear_m176C91687BAD81DC7C2861C8819F1760D1197519,
	LeanLanguageCSV_LoadFromSource_mEFED077B9EAE08DD618E8BC6F4534B1903DBFC33,
	LeanLanguageCSV__ctor_mDD24A33328C7FB36F1BD8FB778E49D8F579E3C69,
	LeanLanguageCSV__cctor_m39EBDAEBBAB1F58CF4EE97BFAF221E5FF0961CF9,
	LeanLanguageNameAttribute__ctor_m310453BE0490CE858AF56D4A7D4C033DC1A65869,
	LeanLocalToken_TryGetLocalToken_m09CD3AAA6AAAF99E435E4C4C99B7D3176A8D88A9,
	LeanLocalToken_Compile_m585B0C868CD63DBDC31E251E8EBA9BF907910C78,
	LeanLocalToken__ctor_m789C648797492C9B720459F61B688FE7088746FD,
	LeanLocalToken__cctor_mF3DCC459C118C952DDB9F6646C096F5C5B3CB02F,
	LeanLocalization_add_OnLocalizationChanged_m94C19E1856E30C503763C80CCE647150F1E993AF,
	LeanLocalization_remove_OnLocalizationChanged_m80D98D6BE071602EF82C9B511BDE6491E825B357,
	LeanLocalization_get_Languages_mA65ECCCAB0C0BA044B8B8BFE74F576E9724ED12F,
	LeanLocalization_get_Prefabs_mD90386DAA8E02B169B923AD305D7BF18784CD73B,
	LeanLocalization_get_CurrentSaveLanguage_mE1F1ED35B45A5CDD07A330D18E916A8A303BD0D6,
	LeanLocalization_set_CurrentLanguage_mFF7DE5C168273DD7B44C680024CCA616994DA95F,
	LeanLocalization_get_CurrentLanguage_mE21CEB2E374B02AD95296ECBFA3930A9F110511A,
	LeanLocalization_RegisterToken_m8FE99AA4FDF661D33AD531FB0BA2E3C8239B3232,
	LeanLocalization_RegisterTranslation_mC2AA95C83C5071E8EB670C62395772C332A81679,
	LeanLocalization_ClearSave_m3C3666DD031E70BBC321B9DEDD4DF48A5AA4571F,
	LeanLocalization_SaveNow_mBC3E848B60C3C72F3E05909D4907A5053ED3C551,
	LeanLocalization_LoadNow_m3B2319EA74AC1B7046E7198354B75182946FF043,
	LeanLocalization_SetCurrentLanguage_mFF7163299C3604A0D6EC1FB3949497630CD08FB5,
	LeanLocalization_SetCurrentLanguage_mA7EDE4BB40E2921FA24F173D51CF4829F787AD1D,
	LeanLocalization_LanguageExists_mFD4B3E1264B4483606759939C86F345449127293,
	LeanLocalization_TryGetLanguage_m8BEA90BE74F86273B5F8EE1828E268BF6AFD4FD6,
	LeanLocalization_AddPrefab_mE93415C6FCD516F9F19D1772C4435A39E99553CA,
	LeanLocalization_AddLanguage_m94033EABB6B296E7C335756E4C3D85CE8BE17511,
	LeanLocalization_AddTokenToFirst_m45F34C3AE6CB6B4A95D3DD847C853120789594F1,
	LeanLocalization_AddToken_m4B98DE704036D9FFA1B9A43924DEEEA373206CAA,
	LeanLocalization_SetToken_m8247978E3CDD219DD4EA02D72465F24D2286362A,
	LeanLocalization_GetToken_mF29621B59E1248F72D6C2BD12ED775F738BFCA79,
	LeanLocalization_AddPhraseToFirst_mDB84D9AB2165E15D57EAC2393D857FB15A50E12D,
	LeanLocalization_AddPhrase_m7D90BC01075268E09414D215FEB06F20C725A83F,
	LeanLocalization_GetTranslation_mC0C24BB93C0D0DB5479321D491B78255FFA2946A,
	LeanLocalization_GetTranslationText_m56249FE91505DD542E5B7C0529F99D7D481455A4,
	NULL,
	LeanLocalization_UpdateTranslations_m4AD9BA5429972143B16255120BE9816A5E8616DA,
	LeanLocalization_DelayUpdateTranslations_m10E7A3F98114D5B868A98B22C57DC0EC66499EC1,
	LeanLocalization_OnEnable_mC67B06812514191898CB3E9AB809790395FDEB99,
	LeanLocalization_OnDisable_m7DF614D1CAB89285B7F0A65F49033B0EF293B98B,
	LeanLocalization_Update_m51A70B02277097702F3F4A5C9C2E1DF9B126430C,
	LeanLocalization_RegisterAndBuild_mD4895D15A67EE63635837969686CD3A4964F3C68,
	LeanLocalization_UpdateCurrentLanguage_m334D7AB35432580CBA53B795562CA35EF07C561C,
	LeanLocalization_FindLanguageName_m47B960142137BB7CB354084DB0233361CE6A163A,
	LeanLocalization__ctor_m3D27A4234223C52836736630645C52A6791822A8,
	LeanLocalization__cctor_mE54F2F68558DFBD00835BCE8BD04B1EBF26F0614,
	LeanLocalizedBehaviour_set_TranslationName_m5313EA8203C958D582909C10EA71518DB5D3E450,
	LeanLocalizedBehaviour_get_TranslationName_mDF43128F5D7343BEF712A2EDF205C687FC42EABD,
	LeanLocalizedBehaviour_Register_m99D97ABEC515D00E29B7FD498FB7E6B9628A0753,
	LeanLocalizedBehaviour_Unregister_mB84F628497154DC747C91A544CAC6A31D030BA41,
	LeanLocalizedBehaviour_UnregisterAll_m674A6DDD8950035D1CCFA13AE3BBF4C577BFB948,
	NULL,
	LeanLocalizedBehaviour_UpdateLocalization_mD557D908401E468B3A0A16D7BC9AA0772EDA4BDB,
	LeanLocalizedBehaviour_OnEnable_m9A83E5D5C6809B1B962FAF0F5998BEABF0A115E4,
	LeanLocalizedBehaviour_OnDisable_mBC512ED853DB31A92920D676B21AD53EDB0B81EC,
	LeanLocalizedBehaviour__ctor_m2D8565C35FB6B9A9AB50EC2D63CEEEFC069AA9B6,
	LeanPhrase_set_Data_m6DE196AB34FEB16D7A46F8D5FE8E93AA4D677CF3,
	LeanPhrase_get_Data_mA130C6A1157C0385884DAE799B80EA19C0CA42BB,
	LeanPhrase_get_Entries_m7DD29DDA0B9C7CCD209F7DC521BF10EC52F36A96,
	LeanPhrase_Clear_m57F5BD279BD5682560B2FA93E56ACE45B6F75B09,
	LeanPhrase_Compile_mB376BA309F12151403AC76B03B9992CC17295460,
	LeanPhrase_Compile_m9DE37074D06D786B52FAE1643AC323C2B7FCC449,
	LeanPhrase_Compile_mF5E61689C926F73EBD033B6D18D1F135CA0DFFD9,
	LeanPhrase_TryFindTranslation_mBEBEBFF7FF1906F65D104B4F5C2D906254FBEE2A,
	LeanPhrase_RemoveTranslation_m11E8111D4D4B7B15AF882FFD2C667CBC773FECD8,
	LeanPhrase_AddEntry_mFC451F94555BD83BFD110FEF02E8E578E2903911,
	LeanPhrase__ctor_m9C14D057589FFC0995E691D466F832B20EC856B9,
	LeanPrefab_get_Sources_mA6EC3CEBF604C99B48892CED52474E3BA475AA99,
	LeanPrefab_RebuildSources_m9E71B8054A5B19BA68AE2EC209B93DFC73FC7A53,
	LeanPrefab_FinalizeBuild_m72C7E44D0D268FC77118448C311A605B76D49409,
	LeanPrefab_AddSource_m080EEAF469E160C0FF8CC327A03ACF04051E86D6,
	LeanPrefab_FindFromGameObject_m0DA312D11C7FAA62D195482EDE8D2AA53404D183,
	LeanPrefab__ctor_m6E3F3623E232BF943318EF7B778C1B3A01C4D0B2,
	LeanPrefab__cctor_mB75E0EEACE308E7769DCB7457EF640AC286D8B02,
	NULL,
	LeanSource_Register_m9792577A20F1A250F19A7B0E9C0B4ACC9E1587C4,
	LeanSource_Unregister_mC38CC638900D1132BBD47F60B762CE445D3F7848,
	LeanSource_OnEnable_m2EDDFD19F3ED02D12261BDC3D867CC0EACABD361,
	LeanSource_OnDisable_mFA6F7745CD407966841DF09A22A943D4FF7B6456,
	LeanSource__ctor_mD0EEF9005656B10D9FF5B9F297711B18F306B609,
	LeanSource__cctor_m090835FBE11288A88CAE455B762D8D665F42C6E9,
	LeanToken_set_Value_m75542500D6C1DD802F44C465D05D64EF86A0DC97,
	LeanToken_get_Value_m1B5B223EAFAE2109B374456956E8DCFC0BAD98DE,
	LeanToken_SetValue_m0630BBBE46DC941D4A30CF7B7B27C9E6A18A835A,
	LeanToken_SetValue_mBD3643BA50BC04AEC53EF7CA3B8EE4891E8087E2,
	LeanToken_SetValue_m284DA247E7863B9E4A830D6841FA7BC21F96EE0F,
	LeanToken_Register_m83F73992ECC9024506A41298F8E62D2BC4BD37E1,
	LeanToken_Unregister_m6409659BAE8707F759A756338339696C9A263A91,
	LeanToken_UnregisterAll_mEDCAE02E986F5A5AAF9AD7A8A406D99B58AAD1D7,
	LeanToken_Compile_mF8C4685DA56BBC8D4888DB571BF2A7C08FDCA82F,
	LeanToken_OnDisable_m59DFD56899194180401D71F8A800FF23A7657851,
	LeanToken__ctor_mBF6F28DED1F036725D572ADA122BDE78AB911AA6,
	LeanToken__cctor_mC817DA5EE22B1AF7C1A06A85634886DB7A9EB7C5,
	LeanTranslation_get_Name_m6515502FAEB313CB03AD4DB1622885C34D155C02,
	LeanTranslation_get_Entries_m43784A8CE5B738920B7A929B5C0DE292F5CA5A4E,
	LeanTranslation__ctor_mD41363D9871DBBE0908EE72B573EA47D9C3D427E,
	LeanTranslation_Register_m1DCE13C2244B6B325639E4B485F9DA4FEA72EAF5,
	LeanTranslation_Clear_m8BF271653A1EC6F676CD53841944BEA978AA5EF0,
	LeanTranslation_LanguageCount_m9F38563EBBF596AA6EEA63E667BDAFCE682489C9,
	LeanTranslation_FormatText_mA8BB40EC96AA7F15201955E1C2E2AA0CD818B057,
	LeanTranslation_Match_m3704780F3AADC5B2A67CA3897707508979DE684F,
	LeanTranslation__cctor_m10E06E5DFDDE42D69C1FD699538252CF52D31BF8,
	LeanTranslationNameAttribute__ctor_m81921D20F828AFD30DFAC7962FCE9BC7168B310B,
	Option__ctor_mB135F7787ADDA0D10DFB35222114F64D1CB57D2D,
	Entry__ctor_mDD7512E04E4A2282696F4A91FFC8A7E4D6818433,
	Entry__ctor_mA321792CEC80BF2B859D0D81883BEF92CBEF7FCB,
};
static const int32_t s_InvokerIndices[148] = 
{
	26,
	23,
	23,
	14,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	26,
	23,
	23,
	23,
	26,
	26,
	23,
	26,
	14,
	14,
	23,
	14,
	27,
	23,
	23,
	23,
	3,
	23,
	391,
	27,
	23,
	3,
	159,
	159,
	14,
	14,
	49,
	159,
	4,
	142,
	0,
	23,
	3,
	3,
	26,
	32,
	9,
	803,
	26,
	105,
	0,
	28,
	109,
	1,
	0,
	28,
	0,
	210,
	-1,
	861,
	3,
	23,
	23,
	23,
	23,
	23,
	28,
	23,
	3,
	26,
	14,
	26,
	26,
	23,
	26,
	23,
	23,
	23,
	23,
	32,
	10,
	14,
	23,
	27,
	152,
	152,
	803,
	26,
	209,
	23,
	14,
	89,
	89,
	26,
	26,
	23,
	3,
	27,
	23,
	23,
	23,
	23,
	23,
	3,
	26,
	14,
	340,
	26,
	32,
	26,
	26,
	23,
	27,
	23,
	23,
	3,
	14,
	14,
	26,
	27,
	23,
	112,
	123,
	121,
	3,
	23,
	23,
	23,
	23,
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x0600004E, { 0, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[1] = 
{
	{ (Il2CppRGCTXDataType)2, 22821 },
};
extern const Il2CppCodeGenModule g_LeanLocalizationCodeGenModule;
const Il2CppCodeGenModule g_LeanLocalizationCodeGenModule = 
{
	"LeanLocalization.dll",
	148,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	1,
	s_rgctxIndices,
	1,
	s_rgctxValues,
	NULL,
};
