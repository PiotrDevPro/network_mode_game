﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Xml.XmlNodeType System.Xml.XmlReader::get_NodeType()
// 0x00000002 System.String System.Xml.XmlReader::get_Name()
extern void XmlReader_get_Name_mD20CD40668A90CDC612E1FD58193388246CD4893 (void);
// 0x00000003 System.String System.Xml.XmlReader::get_LocalName()
// 0x00000004 System.String System.Xml.XmlReader::get_Prefix()
// 0x00000005 System.String System.Xml.XmlReader::get_Value()
// 0x00000006 System.String System.Xml.XmlReader::GetAttribute(System.String)
// 0x00000007 System.Xml.XmlNameTable System.Xml.XmlReader::get_NameTable()
// 0x00000008 System.Object System.Xml.XmlReader::get_debuggerDisplayProxy()
extern void XmlReader_get_debuggerDisplayProxy_m0E4E80BB3ECC5A994F93C06EF8826BFAA9DB9CF1 (void);
// 0x00000009 System.Void System.Xml.XmlReader::.cctor()
extern void XmlReader__cctor_m3EF2489C81E4EEF249A34242FC130A861972991E (void);
// 0x0000000A System.Void System.Xml.XmlReader_XmlReaderDebuggerDisplayProxy::.ctor(System.Xml.XmlReader)
extern void XmlReaderDebuggerDisplayProxy__ctor_mE3C1728E7BF85B9364C0F4244586C9C369F43215_AdjustorThunk (void);
// 0x0000000B System.String System.Xml.XmlReader_XmlReaderDebuggerDisplayProxy::ToString()
extern void XmlReaderDebuggerDisplayProxy_ToString_mEB54B7610A4FB6E55E154378C4CE91D73EB8D4B6_AdjustorThunk (void);
// 0x0000000C System.String System.Xml.XmlDocumentType::get_Name()
extern void XmlDocumentType_get_Name_m1AD33BED673249FB1F704F19A1A9D705ABF6FD1C (void);
// 0x0000000D System.Xml.XmlNodeType System.Xml.XmlDocumentType::get_NodeType()
extern void XmlDocumentType_get_NodeType_m3DF8ACD66E13DD9C1E9C358E0C3F148EBCE5627C (void);
// 0x0000000E System.String System.Xml.XmlDocumentType::get_PublicId()
extern void XmlDocumentType_get_PublicId_m2DDA44AD846D5D03CC3E11FF284F5C40596FC51B (void);
// 0x0000000F System.String System.Xml.XmlDocumentType::get_SystemId()
extern void XmlDocumentType_get_SystemId_m4D995F9A6F7D34E70D9C53FD99D4A6EE66B473D0 (void);
// 0x00000010 System.String System.Xml.XmlDocumentType::get_InternalSubset()
extern void XmlDocumentType_get_InternalSubset_m47C247A372247168CC1B7DFC08B27BA3663A2177 (void);
// 0x00000011 System.String System.Xml.XmlNode::get_Name()
// 0x00000012 System.String System.Xml.XmlNode::get_Value()
extern void XmlNode_get_Value_m800C60D728321E855696990CA7CF070A60710E65 (void);
// 0x00000013 System.Xml.XmlNodeType System.Xml.XmlNode::get_NodeType()
// 0x00000014 System.Object System.Xml.XmlNode::get_debuggerDisplayProxy()
extern void XmlNode_get_debuggerDisplayProxy_m0B8A99A23A898A5F4549461C021E32E84B5CEC35 (void);
// 0x00000015 System.Void System.Xml.DebuggerDisplayXmlNodeProxy::.ctor(System.Xml.XmlNode)
extern void DebuggerDisplayXmlNodeProxy__ctor_mA5D5DD4ED2B9ADDC61B2F79713FE2D56E161DEC6_AdjustorThunk (void);
// 0x00000016 System.String System.Xml.DebuggerDisplayXmlNodeProxy::ToString()
extern void DebuggerDisplayXmlNodeProxy_ToString_m7E1DD26BBDE4FD8BB63D9BFB36139D145E020F82_AdjustorThunk (void);
// 0x00000017 System.Object System.Xml.XmlCharType::get_StaticLock()
extern void XmlCharType_get_StaticLock_mE0FF2E8B12DC2AFFAFAB5718FDD49FAE726A6513 (void);
// 0x00000018 System.Void System.Xml.XmlCharType::InitInstance()
extern void XmlCharType_InitInstance_m48449C6A7516A943668D92903B5D4203DD184AC6 (void);
// 0x00000019 System.Void System.Xml.XmlCharType::SetProperties(System.String,System.Byte)
extern void XmlCharType_SetProperties_m892CAB57FF4A04EB120C6AA8D4ACA9645ED0A72C (void);
// 0x0000001A System.Void System.Xml.XmlCharType::.ctor(System.Byte[])
extern void XmlCharType__ctor_m0B65BC6BD912979FA16676884EC3120565FD6DCD_AdjustorThunk (void);
// 0x0000001B System.Xml.XmlCharType System.Xml.XmlCharType::get_Instance()
extern void XmlCharType_get_Instance_mEAAD3E43BD5AC72FA94C12096B2A9C9684557210 (void);
// 0x0000001C System.String System.Xml.XmlConvert::EscapeValueForDebuggerDisplay(System.String)
extern void XmlConvert_EscapeValueForDebuggerDisplay_mBB3CC9622F210260398750EA0E9D0D151F1DA449 (void);
// 0x0000001D System.Void System.Xml.XmlConvert::.cctor()
extern void XmlConvert__cctor_m1EE317B21041E9F0ABE85E4DB9EE427C21DB4F03 (void);
// 0x0000001E System.String System.Xml.XmlNameTable::Add(System.String)
static Il2CppMethodPointer s_methodPointers[30] = 
{
	NULL,
	XmlReader_get_Name_mD20CD40668A90CDC612E1FD58193388246CD4893,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	XmlReader_get_debuggerDisplayProxy_m0E4E80BB3ECC5A994F93C06EF8826BFAA9DB9CF1,
	XmlReader__cctor_m3EF2489C81E4EEF249A34242FC130A861972991E,
	XmlReaderDebuggerDisplayProxy__ctor_mE3C1728E7BF85B9364C0F4244586C9C369F43215_AdjustorThunk,
	XmlReaderDebuggerDisplayProxy_ToString_mEB54B7610A4FB6E55E154378C4CE91D73EB8D4B6_AdjustorThunk,
	XmlDocumentType_get_Name_m1AD33BED673249FB1F704F19A1A9D705ABF6FD1C,
	XmlDocumentType_get_NodeType_m3DF8ACD66E13DD9C1E9C358E0C3F148EBCE5627C,
	XmlDocumentType_get_PublicId_m2DDA44AD846D5D03CC3E11FF284F5C40596FC51B,
	XmlDocumentType_get_SystemId_m4D995F9A6F7D34E70D9C53FD99D4A6EE66B473D0,
	XmlDocumentType_get_InternalSubset_m47C247A372247168CC1B7DFC08B27BA3663A2177,
	NULL,
	XmlNode_get_Value_m800C60D728321E855696990CA7CF070A60710E65,
	NULL,
	XmlNode_get_debuggerDisplayProxy_m0B8A99A23A898A5F4549461C021E32E84B5CEC35,
	DebuggerDisplayXmlNodeProxy__ctor_mA5D5DD4ED2B9ADDC61B2F79713FE2D56E161DEC6_AdjustorThunk,
	DebuggerDisplayXmlNodeProxy_ToString_m7E1DD26BBDE4FD8BB63D9BFB36139D145E020F82_AdjustorThunk,
	XmlCharType_get_StaticLock_mE0FF2E8B12DC2AFFAFAB5718FDD49FAE726A6513,
	XmlCharType_InitInstance_m48449C6A7516A943668D92903B5D4203DD184AC6,
	XmlCharType_SetProperties_m892CAB57FF4A04EB120C6AA8D4ACA9645ED0A72C,
	XmlCharType__ctor_m0B65BC6BD912979FA16676884EC3120565FD6DCD_AdjustorThunk,
	XmlCharType_get_Instance_mEAAD3E43BD5AC72FA94C12096B2A9C9684557210,
	XmlConvert_EscapeValueForDebuggerDisplay_mBB3CC9622F210260398750EA0E9D0D151F1DA449,
	XmlConvert__cctor_m1EE317B21041E9F0ABE85E4DB9EE427C21DB4F03,
	NULL,
};
static const int32_t s_InvokerIndices[30] = 
{
	10,
	14,
	14,
	14,
	14,
	28,
	14,
	14,
	3,
	26,
	14,
	14,
	10,
	14,
	14,
	14,
	14,
	14,
	10,
	14,
	26,
	14,
	4,
	3,
	618,
	26,
	1064,
	0,
	3,
	28,
};
extern const Il2CppCodeGenModule g_System_XmlCodeGenModule;
const Il2CppCodeGenModule g_System_XmlCodeGenModule = 
{
	"System.Xml.dll",
	30,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
