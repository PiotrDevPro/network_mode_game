﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void System.Configuration.ConfigurationSection::DeserializeSection(System.Xml.XmlReader)
extern void ConfigurationSection_DeserializeSection_mC39769C65F7E36F2B33E155B4D8ACADB83377B5F (void);
// 0x00000002 System.Boolean System.Configuration.ConfigurationSection::IsModified()
extern void ConfigurationSection_IsModified_mDD7D74427E761D9EFAA2629FE71DD83A8B7D1785 (void);
// 0x00000003 System.Void System.Configuration.ConfigurationSection::ResetModified()
extern void ConfigurationSection_ResetModified_mCA8B3DE0DE1903CDB60E70517BEBD92A06C647E4 (void);
// 0x00000004 System.String System.Configuration.ConfigurationSection::SerializeSection(System.Configuration.ConfigurationElement,System.String,System.Configuration.ConfigurationSaveMode)
extern void ConfigurationSection_SerializeSection_m76F991963602BC728C4B22044ED618A42FA3C3E5 (void);
// 0x00000005 System.Configuration.ConfigurationPropertyCollection System.Configuration.ConfigurationElement::get_Properties()
extern void ConfigurationElement_get_Properties_mB1F40F2F14D68682556E31C36BEF7B62067C9E98 (void);
// 0x00000006 System.Void System.Configuration.ConfigurationElement::DeserializeElement(System.Xml.XmlReader,System.Boolean)
extern void ConfigurationElement_DeserializeElement_mF73F06B4B2E7710DBCA22A87271375C4D1DCF029 (void);
// 0x00000007 System.Void System.Configuration.ConfigurationElement::InitializeDefault()
extern void ConfigurationElement_InitializeDefault_m60D9D20FEFA9971FD0F37525AE1868DDDAEADD09 (void);
// 0x00000008 System.Boolean System.Configuration.ConfigurationElement::IsModified()
extern void ConfigurationElement_IsModified_mA046D03044CDCD875C22E34247CE15E7BBC883A5 (void);
// 0x00000009 System.Void System.Configuration.ConfigurationElement::PostDeserialize()
extern void ConfigurationElement_PostDeserialize_mFE4A35B759066484E42C3DE4C24F6806D0D7C7DB (void);
// 0x0000000A System.Void System.Configuration.ConfigurationElement::Reset(System.Configuration.ConfigurationElement)
extern void ConfigurationElement_Reset_m39498D76FA0912DA725E3224537BBF7FA5B0FC1A (void);
// 0x0000000B System.Void System.Configuration.ConfigurationElement::ResetModified()
extern void ConfigurationElement_ResetModified_m6AAF1F8A88CEF6F993A6666E3B4D4B2456024989 (void);
// 0x0000000C System.Int32 System.Configuration.ConfigurationElementCollection::get_Count()
extern void ConfigurationElementCollection_get_Count_m58EFBCAA164C912FEBD007AACF85784B80C54EFA (void);
// 0x0000000D System.Boolean System.Configuration.ConfigurationElementCollection::get_ThrowOnDuplicate()
extern void ConfigurationElementCollection_get_ThrowOnDuplicate_mE9A81BD23AF7A397705927E83969F28FB0352FAC (void);
// 0x0000000E System.Configuration.ConfigurationElement System.Configuration.ConfigurationElementCollection::CreateNewElement()
// 0x0000000F System.Object System.Configuration.ConfigurationElementCollection::GetElementKey(System.Configuration.ConfigurationElement)
// 0x00000010 System.Void System.Configuration.ConfigurationCollectionAttribute::.ctor(System.Type)
extern void ConfigurationCollectionAttribute__ctor_mF41393517164A49C3127C24B1CCBBA3CCBC44A65 (void);
// 0x00000011 System.Void System.Configuration.IgnoreSection::.ctor()
extern void IgnoreSection__ctor_m30C69267DD27E85879BA3AE28ABCDAE783B28350 (void);
// 0x00000012 System.Configuration.ConfigurationPropertyCollection System.Configuration.IgnoreSection::get_Properties()
extern void IgnoreSection_get_Properties_m654A228B012E724695AFD79627F13FCF739244E4 (void);
// 0x00000013 System.Void System.Configuration.IgnoreSection::DeserializeSection(System.Xml.XmlReader)
extern void IgnoreSection_DeserializeSection_mD4D92311BEF0747F961B3E11BFDC13B56052A0EC (void);
// 0x00000014 System.Boolean System.Configuration.IgnoreSection::IsModified()
extern void IgnoreSection_IsModified_m0430C7830B3A902BCAE985427CB2FCE1F15EB595 (void);
// 0x00000015 System.Void System.Configuration.IgnoreSection::Reset(System.Configuration.ConfigurationElement)
extern void IgnoreSection_Reset_m46C76CCBADF508876E17A2A59778E427E20B7628 (void);
// 0x00000016 System.Void System.Configuration.IgnoreSection::ResetModified()
extern void IgnoreSection_ResetModified_mE7AEAA166BBA055767C5AFA05C9F223E1D0FB070 (void);
// 0x00000017 System.String System.Configuration.IgnoreSection::SerializeSection(System.Configuration.ConfigurationElement,System.String,System.Configuration.ConfigurationSaveMode)
extern void IgnoreSection_SerializeSection_m03CB506F46AEA369F5FCAEC048509461D907FEE9 (void);
// 0x00000018 System.Void Unity.ThrowStub::ThrowNotSupportedException()
extern void ThrowStub_ThrowNotSupportedException_mF0DAFE591641D359313AB87E6900E4B05E42390A (void);
static Il2CppMethodPointer s_methodPointers[24] = 
{
	ConfigurationSection_DeserializeSection_mC39769C65F7E36F2B33E155B4D8ACADB83377B5F,
	ConfigurationSection_IsModified_mDD7D74427E761D9EFAA2629FE71DD83A8B7D1785,
	ConfigurationSection_ResetModified_mCA8B3DE0DE1903CDB60E70517BEBD92A06C647E4,
	ConfigurationSection_SerializeSection_m76F991963602BC728C4B22044ED618A42FA3C3E5,
	ConfigurationElement_get_Properties_mB1F40F2F14D68682556E31C36BEF7B62067C9E98,
	ConfigurationElement_DeserializeElement_mF73F06B4B2E7710DBCA22A87271375C4D1DCF029,
	ConfigurationElement_InitializeDefault_m60D9D20FEFA9971FD0F37525AE1868DDDAEADD09,
	ConfigurationElement_IsModified_mA046D03044CDCD875C22E34247CE15E7BBC883A5,
	ConfigurationElement_PostDeserialize_mFE4A35B759066484E42C3DE4C24F6806D0D7C7DB,
	ConfigurationElement_Reset_m39498D76FA0912DA725E3224537BBF7FA5B0FC1A,
	ConfigurationElement_ResetModified_m6AAF1F8A88CEF6F993A6666E3B4D4B2456024989,
	ConfigurationElementCollection_get_Count_m58EFBCAA164C912FEBD007AACF85784B80C54EFA,
	ConfigurationElementCollection_get_ThrowOnDuplicate_mE9A81BD23AF7A397705927E83969F28FB0352FAC,
	NULL,
	NULL,
	ConfigurationCollectionAttribute__ctor_mF41393517164A49C3127C24B1CCBBA3CCBC44A65,
	IgnoreSection__ctor_m30C69267DD27E85879BA3AE28ABCDAE783B28350,
	IgnoreSection_get_Properties_m654A228B012E724695AFD79627F13FCF739244E4,
	IgnoreSection_DeserializeSection_mD4D92311BEF0747F961B3E11BFDC13B56052A0EC,
	IgnoreSection_IsModified_m0430C7830B3A902BCAE985427CB2FCE1F15EB595,
	IgnoreSection_Reset_m46C76CCBADF508876E17A2A59778E427E20B7628,
	IgnoreSection_ResetModified_mE7AEAA166BBA055767C5AFA05C9F223E1D0FB070,
	IgnoreSection_SerializeSection_m03CB506F46AEA369F5FCAEC048509461D907FEE9,
	ThrowStub_ThrowNotSupportedException_mF0DAFE591641D359313AB87E6900E4B05E42390A,
};
static const int32_t s_InvokerIndices[24] = 
{
	26,
	89,
	23,
	102,
	14,
	458,
	23,
	89,
	23,
	26,
	23,
	10,
	89,
	14,
	28,
	26,
	23,
	14,
	26,
	89,
	26,
	23,
	102,
	3,
};
extern const Il2CppCodeGenModule g_System_ConfigurationCodeGenModule;
const Il2CppCodeGenModule g_System_ConfigurationCodeGenModule = 
{
	"System.Configuration.dll",
	24,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
