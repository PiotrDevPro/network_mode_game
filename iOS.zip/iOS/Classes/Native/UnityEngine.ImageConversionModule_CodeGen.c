﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Boolean UnityEngine.ImageConversion::LoadImage(UnityEngine.Texture2D,System.Byte[],System.Boolean)
extern void ImageConversion_LoadImage_mFB317291362399115F8D112D8CE9E8C1BF454C29 (void);
// 0x00000002 System.Boolean UnityEngine.ImageConversion::LoadImage(UnityEngine.Texture2D,System.Byte[])
extern void ImageConversion_LoadImage_m94295492E96C38984406A23CC2A3931758ECE86B (void);
static Il2CppMethodPointer s_methodPointers[2] = 
{
	ImageConversion_LoadImage_mFB317291362399115F8D112D8CE9E8C1BF454C29,
	ImageConversion_LoadImage_m94295492E96C38984406A23CC2A3931758ECE86B,
};
static const int32_t s_InvokerIndices[2] = 
{
	211,
	121,
};
extern const Il2CppCodeGenModule g_UnityEngine_ImageConversionModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_ImageConversionModuleCodeGenModule = 
{
	"UnityEngine.ImageConversionModule.dll",
	2,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
