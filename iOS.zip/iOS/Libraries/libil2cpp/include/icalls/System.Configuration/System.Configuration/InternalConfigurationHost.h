#pragma once

namespace il2cpp
{
namespace icalls
{
namespace System
{
namespace Configuration
{
namespace System
{
namespace Configuration
{
    class LIBIL2CPP_CODEGEN_API InternalConfigurationHost
    {
    public:
        static Il2CppString* get_bundled_app_config();
    };
} // namespace Configuration
} // namespace System
} // namespace Configuration
} // namespace System
} // namespace icalls
} // namespace il2cpp
