#pragma once

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
namespace Text
{
    class LIBIL2CPP_CODEGEN_API EncodingHelper
    {
    public:
        static Il2CppString* InternalCodePage(int32_t* code_page);
    };
} // namespace Text
} // namespace System
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
