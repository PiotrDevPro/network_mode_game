#pragma once

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
namespace Runtime
{
namespace Versioning
{
    class LIBIL2CPP_CODEGEN_API VersioningHelper
    {
    public:
        static int32_t GetRuntimeId();
    };
} // namespace Versioning
} // namespace Runtime
} // namespace System
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
