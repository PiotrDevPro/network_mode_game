#pragma once

namespace il2cpp
{
namespace os
{
namespace FileSystemWatcher
{
    int IsSupported();
}
}
}
