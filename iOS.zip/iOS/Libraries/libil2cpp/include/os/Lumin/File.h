#pragma once

#include <string>

namespace il2cpp
{
namespace os
{
namespace lumin
{
    std::string PathForErrorLog();
    std::string PathForOutputLog();
}
}
}
