#pragma once

namespace il2cpp
{
namespace os
{
namespace lumin
{
namespace automation
{
    void Bootstrap();
    void WaitForAppThread();
}
}
}
}
